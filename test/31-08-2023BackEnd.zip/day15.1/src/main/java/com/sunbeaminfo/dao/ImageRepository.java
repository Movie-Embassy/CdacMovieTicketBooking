package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunbeaminfo.entities.ImageEntity;

public interface ImageRepository extends JpaRepository<ImageEntity, Long> {

}