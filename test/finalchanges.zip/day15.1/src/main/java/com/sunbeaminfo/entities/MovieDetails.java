package com.sunbeaminfo.entities;


import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.enums.Format;
import com.sunbeaminfo.enums.Language;

@Entity
@Table(name="movie_details_tbl")	// Define the table name in the database
public class MovieDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)		// Generate unique IDs for movie details
	@Column(name="movie_details_id")
	private Long movieDetailsId  ;
	
	// Many-to-One relationship with Movie entity (lazy fetch to avoid unnecessary loading)
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore	// Ignore during JSON serialization to avoid circular references
	@JoinColumn(name="movie_id")	// Foreign key column referencing movie_id in Movie table	
	private Movie movie;
	
	// Enumerated format column indicating movie format
	@Enumerated(EnumType.STRING)
	@Column(name = "movie_format",length=20)
	private Format format;
	
	// Enumerated language column indicating movie language
	@Enumerated(EnumType.STRING)
	@Column(length=20)
	private Language language ;

	
	// Default constructor
	public MovieDetails() {
		super();
	}

	// Constructor with all fields
	public MovieDetails(long movieDetailsId) {
		super();
		this.movieDetailsId = movieDetailsId;
	}


	// Constructor with only movieDetailsId
	public MovieDetails(Movie movie, Format format, Language language) {
		super();
		this.movie = movie;
		this.format = format;
		this.language = language;
	}

	// Constructor without movieDetailsId
	public long getmovieDetailsId() {
		return movieDetailsId;
	}

	
	// Getters and Setters for all fields
	public void setmovieDetailsId(long movieDetailsId) {
		this.movieDetailsId = movieDetailsId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
	
	
	// Additional methods like hashCode, equals, etc. have been provided
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieDetailsId ^ (movieDetailsId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieDetails other = (MovieDetails) obj;
		if (movieDetailsId != other.movieDetailsId)
			return false;
		return true;
	}
	
	

	
	
	
	
}
