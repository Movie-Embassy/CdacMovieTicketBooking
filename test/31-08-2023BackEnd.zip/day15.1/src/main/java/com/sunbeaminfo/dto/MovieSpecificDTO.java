package com.sunbeaminfo.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Lob;

import com.sunbeaminfo.enums.Certificate;

public class MovieSpecificDTO {
	private Long movieId;
	
	
	private String movieName;
	
	
	private LocalDate releaseDate;
	
	
	private int runTime ;
	
	
	
	private String description;
	
	
	
	private byte[] movieTile;
	
	
	
	private byte[] movieBgImage;
	
	
	private String trailerUrl;
	
	
	
	private Certificate certificate;

	
	private String filmIndustry;
}
