package com.sunbeaminfo.entities;

import java.util.Arrays;

import javax.persistence.*;

@Entity
@Table(name = "image_table")
public class ImageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Override
	public String toString() {
		return "ImageEntity [id=" + id + ", imageData=" + Arrays.toString(imageData) + "]";
	}

	@Lob
    private byte[] imageData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public byte[] getImageData() {
		return imageData;
	}

	public void setImageData(byte[] imageData) {
		this.imageData = imageData;
	}

	public ImageEntity(Long id, byte[] imageData) {
		super();
		this.id = id;
		this.imageData = imageData;
	}

	public ImageEntity() {
		super();
	}

    
    
    // getters and setters
}