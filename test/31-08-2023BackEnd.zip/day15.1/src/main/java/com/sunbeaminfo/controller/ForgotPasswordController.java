package com.sunbeaminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dao.TokenDao;
import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.entities.PasswordResetToken;
import com.sunbeaminfo.entities.User;
import com.sunbeaminfo.service.UserService;



@RestController
@RequestMapping("/forgotpassword")
@CrossOrigin(origins = "*")
public class ForgotPasswordController {
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private UserService userService;
	
	@Autowired 
	private TokenDao tokenDao; 
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@PostMapping("/forgotpassword")
	public ResponseEntity<?> forgotPasswordProcess(@RequestParam String email) {
		User user = userDao.findByUserEmail(email).orElse(null);
		
		String output="";
		if(user!=null) {
		output = userService.sendEmail(user);
		}
		if(output.equals("success")) {
			return new ResponseEntity(HttpStatus.OK);
		}
		else {
			return new ResponseEntity(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	
	@PostMapping("/setpassword")
	public ResponseEntity<?> resetPassword(@RequestParam String tokenString ,@RequestParam String password) {
		
		PasswordResetToken token = tokenDao.findByToken(tokenString);
		if(token!=null && userService.hasExipred(token.getExpiryDateTime()) ) {
			User user = userDao.findById(token.getUser().getId()).get();
			user.setPassword(passwordEncoder.encode(password));
			userDao.save(user);
		}
		
		
		return new ResponseEntity(HttpStatus.OK);
		
	}
	
}
