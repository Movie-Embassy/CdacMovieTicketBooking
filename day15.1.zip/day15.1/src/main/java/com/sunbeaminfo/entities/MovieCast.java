package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="movie_cast_tbl")
public class MovieCast {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_cast_id", nullable = false, unique = true)
	private long  movieCastId;
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	
	@Column(name="cast", nullable = false , unique = true)
	private String cast;

	
	@Column(name = "cast_image")
	private byte[] castImg;
	
	
	
	

	public MovieCast() {
		super();
	}
	

	public MovieCast(long movieCastId, Movie movie, String cast, byte[] castImg) {
		super();
		this.movieCastId = movieCastId;
		this.movie = movie;
		this.cast = cast;
		this.castImg = castImg;
	}

	public MovieCast(Movie movie, String cast, byte[] castImg) {
		super();
		this.movie = movie;
		this.cast = cast;
		this.castImg = castImg;
	}




	public long getMovieCastId() {
		return movieCastId;
	}


	public void setMovieCastId(long movieCastId) {
		this.movieCastId = movieCastId;
	}


	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}


	public String getCast() {
		return cast;
	}


	public void setCast(String cast) {
		this.cast = cast;
	}


	public byte[] getCastImg() {
		return castImg;
	}


	public void setCastImg(byte[] castImg) {
		this.castImg = castImg;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieCastId ^ (movieCastId >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieCast other = (MovieCast) obj;
		if (movieCastId != other.movieCastId)
			return false;
		return true;
	}
	
	


	
	
	
	
	
	
	
}
