package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_certificate_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter

public class MovieCertificate {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_certificate_id", nullable = false, unique = true)
	private long  movieCertificateId;
	

	@ManyToOne
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	@Enumerated(EnumType.STRING)
	@Column(name="certificate", nullable = false , unique = true)
	private Certificate	 certificate;

	public long getMovieCertificateId() {
		return movieCertificateId;
	}

	public void setMovieCertificateId(long movieCertificateId) {
		this.movieCertificateId = movieCertificateId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Certificate getCertificate() {
		return certificate;
	}

	public void setCertificate(Certificate certificate) {
		this.certificate = certificate;
	}
	
	
	
	
	
}
