import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

function CardPayment() {
    
    const history = useHistory();
    
    const success=()=>{
        history.push('./Success')
    }


    return ( 
        <>
        <div style={{margin:20}}>
         CARD NUMBER
         <input type="text" placeholder="XXXX-XXXX-XXXX" className="form-control" minLength={12} maxLength={12} style={{width:230}}  />
        </div>
     
        <div style={{margin:20}}>
         CARD HOLDER
         <input type="text" placeholder="Enter name as seen on card" className="form-control" style={{width:230}}  />
        </div>
     
        <div style={{margin:20}}>
         EXPIRY DATE <br/> 
         <select id="month" name="month" margin="10" className="form-control" style={{width:60}}>
         <option name="1" id="1">1</option>
         <option name="2" id="2">2</option>
         <option name="3" id="3">3</option>
         <option name="4" id="4">4</option>
         <option name="5" id="5">5</option>
         <option name="6" id="6">6</option>
         <option name="7" id="7">7</option>
         <option name="8" id="8">8</option>
         <option name="9" id="9">9</option>
         <option name="10" id="10">10</option>
         <option name="11" id="11">11</option>
         <option name="12" id="12">12</option>
         </select>
         <select id="year" name="year" margin="10" className="form-control" style={{width:120,position:"relative",top:-34.5,left:80}}>
         <option name="2023" id="2023">2023</option>
         <option name="2024" id="2024">2024</option>
         <option name="2025" id="2025">2025</option>
         <option name="2026" id="2026">2026</option>
         <option name="2027" id="2027">2027</option>
         <option name="2028" id="2028">2028</option>
         <option name="2029" id="2029">2029</option>
         <option name="2030" id="2030">2030</option>
         <option name="2031" id="2031">2031</option>
         <option name="2032" id="2032">2032</option>
         </select>
        </div>
     
     
     
        <div style={{margin:20,position:"relative",top:-40}}>
         CVV
         <input type="text" placeholder="XYZ" className="form-control" minLength={3} maxLength={3} style={{width:70}}  />
        </div>
        <center>
                        <input onClick={success} type="button" name="proceed" value ="Proceed" className="btn btn-info"/>    
                    </center>
        </>
     );
}

export default CardPayment;