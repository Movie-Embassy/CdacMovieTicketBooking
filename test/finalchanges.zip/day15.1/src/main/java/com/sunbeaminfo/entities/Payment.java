package com.sunbeaminfo.entities;

import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="payment_tbl")	// Define the table name in the database
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	// Generate unique transaction IDs
	@Column(name="transaction_id")
	private Long transactionId ;
	
	// Many-to-One relationship with User entity
	@Column(name="payment_amount")
	private double paymentAmount;

	// One-to-One relationship with Booking entity
	@Column(name="payment_date_time")
	private LocalDateTime paymentDateTime;
	

    // Many-to-One relationship with User entity
	@ManyToOne
	@JoinColumn(name="user_id")	// Foreign key column referencing user_id in User table
	private User user;

	// One-to-One relationship with Booking entity
	@OneToOne
	@JoinColumn(name="booking_id")	// Foreign key column referencing booking_id in Booking table
	private Booking booking;

	
	// Default constructor
	public Payment() {
		super();
	}

	// Constructor with all fields
	public Payment(Long transactionId, double paymentAmount, LocalDateTime paymentDateTime, User user,
			Booking booking) {
		super();
		this.transactionId = transactionId;
		this.paymentAmount = paymentAmount;
		this.paymentDateTime = paymentDateTime;
		this.user = user;
		this.booking = booking;
	}


    // Constructor without transactionId
	public Payment(double paymentAmount, LocalDateTime paymentDateTime, User user, Booking booking) {
		super();
		this.paymentAmount = paymentAmount;
		this.paymentDateTime = paymentDateTime;
		this.user = user;
		this.booking = booking;
	}


    // Getters and Setters for all fields
	public Long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public double getPaymentAmount() {
		return paymentAmount;
	}


	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}


	public LocalDateTime getPaymentDateTime() {
		return paymentDateTime;
	}


	public void setPaymentDateTime(LocalDateTime paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Booking getBooking() {
		return booking;
	}


	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	

    // Override equals to compare based on transactionId
	@Override
	public int hashCode() {
		return Objects.hash(transactionId);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payment other = (Payment) obj;
		return Objects.equals(transactionId, other.transactionId);
	}
	
	
	
	
	
	
	
}
