package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.TheatreDTO;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.service.TheatreService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/theatre")
@CrossOrigin(origins = "*")
public class TheatreController {

	@Autowired
	private TheatreService theatreService;
	
	
	public TheatreController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping("/all")
	public List<Theatre> listAllTheatres(){
		
		return theatreService.getAllTheatres();
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> saveTheatreDetails(@RequestBody TheatreDTO t) {
		
		return new ResponseEntity(theatreService.addTheatre(t),HttpStatus.OK);
	}
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteTheatre(@RequestParam Long id) {
		theatreService.deleteTheatre(id);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	
	@PutMapping("/update")
	public  ResponseEntity<?> updatetheatreInfo(@RequestBody TheatreDTO m) {
		theatreService.getTheatreDetails(m.getTheaterId());
		
		theatreService.addtheatreDetails(m);
		return new ResponseEntity(HttpStatus.OK);
	}

}
