package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;


import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="movie_review_tbl")	// Define the table name in the database
public class MovieReview {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_review_id", nullable = false, unique = true)
	private long  movieReviewId;
	
	
	// Many-to-One relationship with Movie entity (lazy fetch to avoid unnecessary loading)
	/*
	 * In Bidirectional Relationship to avoid in circular referencing add @JsonIgnore annotation
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore		// Ignore during JSON serialization to avoid circular references
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	
	@Column(name="review", nullable = false , unique = true)
	private String review;
	
	@Column(name="review_rating", nullable = false , unique = true)
	@Max(value = 5)	// Maximum review rating value allowed
	@Min(value=0)	// Minimum review rating value allowed
	private int reviewRating;
	
	// Many-to-One relationship with User entity
	@ManyToOne
	@JoinColumn(name="user_id", nullable = false)
	private User user;

	
	// Default constructor
	public MovieReview() {
		super();
	}

	
																	//sets max and min limit for reviewRating		
	public MovieReview(long movieReviewId, Movie movie, String review, @Max(5) @Min(0) int reviewRating, User user) {
		super();
		this.movieReviewId = movieReviewId;
		this.movie = movie;
		this.review = review;
		this.reviewRating = reviewRating;
		this.user = user;
	}


	
	public MovieReview(Movie movie, String review, @Max(5) @Min(0) int reviewRating, User user) {
		super();
		this.movie = movie;
		this.review = review;
		this.reviewRating = reviewRating;
		this.user = user;
	}

	// Getters and Setters for all fields
	public long getMovieReviewId() {
		return movieReviewId;
	}

	public void setMovieReviewId(long movieReviewId) {
		this.movieReviewId = movieReviewId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public int getReviewRating() {
		return reviewRating;
	}

	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	 // Additional methods like hashCode, equals, etc. have been provided
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieReviewId ^ (movieReviewId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieReview other = (MovieReview) obj;
		if (movieReviewId != other.movieReviewId)
			return false;
		return true;
	}

	
	
	
	
}
