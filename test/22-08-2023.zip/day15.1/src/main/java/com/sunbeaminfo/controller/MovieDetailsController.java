package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDetailsDTO;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.service.MovieDetailsService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/MovieDetails")
@CrossOrigin(origins = "*")
public class MovieDetailsController {

	@Autowired
	private MovieDetailsService movieDetailsService;
	
	
	public MovieDetailsController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<MovieDetails> listAllMovieDetailss(){
		
		return movieDetailsService.getAllMovieDetailss();
	}
	
	@PostMapping
	public MovieDetails addMovieDetails(MovieDetailsDTO m) {
		
		return movieDetailsService.addMovieDetails(m);
	}
	
	
	@DeleteMapping
	public ApiResponse deleteMovieDetails(@RequestParam Long id) {
		return movieDetailsService.deleteMovieDetails(id);
	}
	
	
	@GetMapping("/aboutMovie")
	public List<Long> movieSpecificDetails(Long movieId){
		return movieDetailsService.movieSpecificDetails(movieId);
	}
	

}
