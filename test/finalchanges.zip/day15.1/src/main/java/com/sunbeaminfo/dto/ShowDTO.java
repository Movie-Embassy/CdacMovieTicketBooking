package com.sunbeaminfo.dto;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;

public class ShowDTO {
	
	private Long showId ;

	private LocalDateTime showDateTime;
	
	private Long theatreId;
	
	private Long screenId;
	
	private Long movieId;
	
	private Long movieDetailsId;
	
	
	

	public ShowDTO(LocalDateTime showDateTime, Long theatreId, Long screenId, Long movieId,
			Long movieDetailsId) {
		super();
		this.showDateTime = showDateTime;
		this.theatreId = theatreId;
		this.screenId = screenId;
		this.movieId = movieId;
		this.movieDetailsId = movieDetailsId;
	}

	public ShowDTO() {
		super();
	}

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(LocalDateTime showDateTime) {
		this.showDateTime = showDateTime;
	}

	public Long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}

	public Long getScreenId() {
		return screenId;
	}

	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public Long getMovieDetailsId() {
		return movieDetailsId;
	}

	public void setMovieDetailsId(Long movieDetailsId) {
		this.movieDetailsId = movieDetailsId;
	}

	@Override
	public String toString() {
		return "ShowDTO [showId=" + showId + ", showDateTime=" + showDateTime + ", theatreId=" + theatreId
				+ ", screenId=" + screenId + ", movieId=" + movieId + ", movieDetailsId=" + movieDetailsId + "]";
	}

	
	

}
