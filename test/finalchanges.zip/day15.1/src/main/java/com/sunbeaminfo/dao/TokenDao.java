package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunbeaminfo.entities.PasswordResetToken;

public interface TokenDao extends JpaRepository<PasswordResetToken, Long> {
	
	PasswordResetToken findByToken(String token); 
	
}
