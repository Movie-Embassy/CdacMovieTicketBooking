package com.sunbeaminfo.service;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.BookingDao;
import com.sunbeaminfo.dao.BookingSeatDao;
import com.sunbeaminfo.dao.ShowDao;
import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.BookingDTO;
import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.entities.BookingSeat;
import com.sunbeaminfo.entities.Seat;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.entities.Ticket;
import com.sunbeaminfo.entities.User;




class Demo implements Runnable

{
	
	@Autowired
	private BookingDao bookingDao ;
	
	int bkid;
	
	public Demo (Object parameter) {
	    bkid=(int)parameter;
		// store parameter for later user
	   }

	@Override
	public void run() {
		System.out.println("Finally!!!I am executing after 10 secs "+bkid+" is the id of booking which might get deleted from the table of status gets changed to booked");
		
		int resp = bookingDao.getTicketId(this.bkid);
		
		if (resp==0)
		{
			bookingDao.deleteById((long)bkid);
		}
		
	}
	
	
}






@Transactional
@Service
public class BookingServiceImpl implements BookingService {

//	@Autowired
//	private BookingDao bookingDao;
//	
//	@Autowired
//	private UserDao userDao;
//	
//	@Autowired
//	private ShowDao showDao;
	
	@Autowired
	private BookingDao bookingDao ;
	
	@Autowired
	private BookingSeatDao bookingSeatDao;
	
	
	@Override
	public List<Booking> getAllBookings() {
		
		return bookingDao.findAll();
	}

	@Override
	public Booking getBookingById(Long Id) {
		
		return bookingDao.findById(Id).orElseThrow(() -> new ResourceNotFoundException("booking id invalid !!!!!"));
	}

	@Override
	public Booking addBooking(BookingDTO bk) {
		
		 Booking booking = new Booking(new User(bk.getUserId()) ,  new Show(bk.getShowId()),new Ticket(0),bk.getTransactionStratTime());
		bookingDao.save(booking);
		Long latestBookingId = bookingDao.getLatestBookingID();
		
		for(int seatid : bk.getSeats())
		{
			bookingSeatDao.save( new BookingSeat( new Booking(latestBookingId),new Seat((long)seatid)     )      )  ;
		}
		 
		Runnable r1  = new Demo(latestBookingId);
		
		Thread t1=new Thread(r1);
		
			try {
				t1.sleep(60000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			t1.start();
		
		 return booking;
	}

	@Override
	public ApiResponse deleteById(Long Id) {
		bookingDao.deleteById(Id);
		return new ApiResponse("deleted the user with id "+Id);
	}
	

	
	

}


