package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Price;

public interface PriceDao extends JpaRepository<Price, Long>{

	@Query
	(value="select * from price_tbl where show_id=?1 and category=?2",nativeQuery=true)
	Price getByShowId(Long showId,String category);
	
}
