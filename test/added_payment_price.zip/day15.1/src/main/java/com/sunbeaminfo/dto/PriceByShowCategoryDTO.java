package com.sunbeaminfo.dto;

public class PriceByShowCategoryDTO {

	private Long showId;
	
	private String category;

	public PriceByShowCategoryDTO(Long showId, String category) {
		super();
		this.showId = showId;
		this.category = category;
	}
	
	public PriceByShowCategoryDTO() {
		// TODO Auto-generated constructor stub
	}

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	
}
