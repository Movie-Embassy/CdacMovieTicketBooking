package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="ticket_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Ticket {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ticket_id", nullable = false, unique = true)
	private long ticketId ;
	

	@ManyToOne
	@JoinColumn(name="user_id", nullable = false)
	private User user;
	
	

	@ManyToOne
	@JoinColumn(name="seat_id", nullable = false)
	private Seat seat;
	
	
	@ManyToOne
	@JoinColumn(name="show_id", nullable = false)
	private Show show;
	
	
	@ManyToOne
	@JoinColumn(name="payment_id", nullable = false)
	private Payment payment;

	public long getTicketId() {
		return ticketId;
	}

	public void setTicketId(long ticketId) {
		this.ticketId = ticketId;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	//payment ka datetime idhar copy hona chahie directly
	//@MapsId
	@OneToOne
	@JoinColumn(name="booking_datetime", nullable = false)
	private Payment payment1;
	
	
	
}
