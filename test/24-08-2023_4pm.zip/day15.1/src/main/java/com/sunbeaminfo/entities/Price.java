package com.sunbeaminfo.entities;


import javax.persistence.*;

import com.sunbeaminfo.emuns.Category;


@Entity
@Table(name = "price_tbl") // to specify table name
public class Price {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "price_id")
	private Long priceId;
	
	@ManyToOne
	@JoinColumn(name = "show_id")
	private Show show;
	
	@Enumerated
	@Column(name = "category")
	private Category category;
	
	@Column(name = "price")
	private double price;


	
}
