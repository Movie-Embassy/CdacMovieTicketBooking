package com.sunbeaminfo.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.User;





public interface UserDao extends JpaRepository<User, Long> {

	@Query("select new com.sunbeaminfo.entities.User(firstName, lastName) from User u where u.userEmail =?1 and u.password=?2")
	Optional<User> findByUserEmailAndPassword(String em,String pass);
}
