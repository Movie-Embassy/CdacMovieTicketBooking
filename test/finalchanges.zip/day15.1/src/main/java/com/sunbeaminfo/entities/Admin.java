package com.sunbeaminfo.entities;


import javax.persistence.*;


@Entity
@Table(name = "admin_tbl") // to specify table name
public class Admin {
	
	
	 
	//Primary Key 
		@Id 
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "user_id")
		private Long id;

		//Field for first name
		@Column(name = "first_name",length = 20,nullable = false)
		private String firstName;
		
		//Field for last name
		@Column(name = "last_name", length =20,nullable=false)
		private String lastName;
		
		//Field for password
		@Column(name = "password")
		private String password;
		
		//field for user email
		@Column(name = "user_email",unique = true,nullable = false)
		private String userEmail;

		
		
		
		public Admin(Long id, String firstName, String lastName, String password, String userEmail) {
			super();
			this.id = id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.password = password;
			this.userEmail = userEmail;
		}

		public Admin(String firstName, String lastName, String password, String userEmail) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.password = password;
			this.userEmail = userEmail;
		}

		public Admin() {
			super();
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public String getUserEmail() {
			return userEmail;
		}

		public void setUserEmail(String userEmail) {
			this.userEmail = userEmail;
		}

		public Admin(String firstName, String lastName) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
		}
		
		
		
	
	
	
	
}
