import axios from "axios";

const API_KEY = "fd247d540648d4beb60d0186b7808ca0";
const BASE_URL = "https://api.themoviedb.org/3";

export const fetchDataFromApi = async (url, params) => {
  try {
    const { data } = await axios.get(BASE_URL + url, {
      params: {
        api_key: API_KEY, // Include your API key as a query parameter
        ...params, // You can also pass any additional query parameters here
      },
    });
    return data;
  } catch (err) {
    console.log(err);
    return err;
  }
};
