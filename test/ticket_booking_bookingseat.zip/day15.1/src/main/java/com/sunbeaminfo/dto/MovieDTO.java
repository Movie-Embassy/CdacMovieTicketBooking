package com.sunbeaminfo.dto;


import java.time.LocalDate;

import com.sunbeaminfo.emuns.Certificate;


public class MovieDTO {
	
	private Long movieId;
	
	private String movieName;
	
	private LocalDate releaseDate;
	
	private int runTime ;
	
	private String description;
	
	private byte[] movieTile;
	
	private byte[] movieBgImage;
	
	private String trailerUrl;
	
	private Certificate certificate;

	private String filmIndustry;

	public MovieDTO() {
		super();
	}

	public MovieDTO(Long movieId, String movieName, LocalDate releaseDate, int runTime, String description,
			byte[] movieTile, byte[] movieBgImage, String trailerUrl, Certificate certificate, String filmIndustry) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.runTime = runTime;
		this.description = description;
		this.movieTile = movieTile;
		this.movieBgImage = movieBgImage;
		this.trailerUrl = trailerUrl;
		this.certificate = certificate;
		this.filmIndustry = filmIndustry;
	}

	public MovieDTO(String movieName, LocalDate releaseDate, int runTime, String description, byte[] movieTile,
			byte[] movieBgImage, String trailerUrl, Certificate certificate, String filmIndustry) {
		super();
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.runTime = runTime;
		this.description = description;
		this.movieTile = movieTile;
		this.movieBgImage = movieBgImage;
		this.trailerUrl = trailerUrl;
		this.certificate = certificate;
		this.filmIndustry = filmIndustry;
	}

	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getRunTime() {
		return runTime;
	}

	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public byte[] getMovieTile() {
		return movieTile;
	}

	public void setMovieTile(byte[] movieTile) {
		this.movieTile = movieTile;
	}

	public byte[] getMovieBgImage() {
		return movieBgImage;
	}

	public void setMovieBgImage(byte[] movieBgImage) {
		this.movieBgImage = movieBgImage;
	}

	public String getTrailerUrl() {
		return trailerUrl;
	}

	public void setTrailerUrl(String trailerUrl) {
		this.trailerUrl = trailerUrl;
	}

	public Certificate getCertificate() {
		return certificate;
	}

	public void setCertificate(Certificate certificate) {
		this.certificate = certificate;
	}

	public String getFilmIndustry() {
		return filmIndustry;
	}

	public void setFilmIndustry(String filmIndustry) {
		this.filmIndustry = filmIndustry;
	}
	
	
	
	
	
	
	
	
	
	
}
