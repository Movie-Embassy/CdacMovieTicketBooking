package com.sunbeaminfo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Show;


public interface ShowDao extends JpaRepository<Show, Long> {
	
	@Query(value="select * from show_tbl where movie_id=:movieId and 0<=datediff(show_datetime , curdate());", nativeQuery = true)
	List<Show> movieShowList(Long movieId);

}
