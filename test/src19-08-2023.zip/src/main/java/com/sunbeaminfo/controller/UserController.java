package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.User;
import com.sunbeaminfo.service.UserService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;
	
	
	public UserController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<User> listAllUsers(){
		
		return userService.getAllUsers();
	}
	
	@PostMapping
	public User saveUserDetails(@RequestBody User u) {
		return userService.addUser(u);
	}
	
	
	@GetMapping("/login")
	public Optional<User> logIn(@RequestParam String email,@RequestParam String password )
	{
		return userService.findByEmailandPassword(email, password);
	}
	
	@DeleteMapping
	public ApiResponse deleteUser(@RequestParam Long id) {
		return userService.deleteUser(id);
	}
}
