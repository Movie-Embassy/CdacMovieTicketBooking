import React, { useState } from 'react';
import "./style.scss"
import { useParams ,useLocation} from 'react-router-dom';
import { useSelector } from 'react-redux';
import seatSlice from '../../store/seatSlice';
import emailjs from 'emailjs-com';
// import {totalNoOfSeats} from "../../slices/seatSlice"
const OrderSummary = () => {

  
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const selectedSeatIds = searchParams.get('selectedSeats');


  const selectedSeatIdsArray = selectedSeatIds ? selectedSeatIds.split(',').map(id => parseInt(id)) : [];

  const userID = 'GcuHD-5HondqHxkaw';
  const templateID='template_u30klno';
  emailjs.init(userID);
  
  const total1 = useSelector((state) => state.seat.totalNoOfSeats);
  const Conveniencefee=30;
  const d=new Date();
  const total = parseInt(localStorage.getItem('total')) || 0; // in rduz  After refreshing this page the total no of seats are becoming 0 so to persist we have used localstorage

  

  return (
    <div>
      {console.log("total",total)};
      <section className="h-100 h-custom" style={{ backgroundColor: '#eee' }}>
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-lg-8 col-xl-6">
              <div className="card border-top border-bottom border-3" style={{ borderColor: '#f37a27 !important' }}>
                <div className="card-body p-5">
                  <p className="lead fw-bold mb-5" style={{ color: '#f37a27' }}>Booking Summary</p>

                  <div className="row">
                    <div className="col mb-5">
                      <p className="small text-muted mb-1">Date</p>
                      <p>{d.getDate()+"/"+d.getMonth()+"/"+d.getFullYear()}</p>

                    </div>
                    {/* <div className="col mb-3">
                      <p className="small text-muted mb-1">Reference No.</p>
                      <p>012j1gvs356c</p>
                    </div> */}
                  </div>

                  <div className="mx-n5 px-5 py-4" style={{ backgroundColor: '#f2f2f2' }}>
                    <div className="row">
                      <div className="col-md-8 col-lg-9">
                        <div>Seats Selected:</div>
                        <p>{total}</p>
                        <p>
        {selectedSeatIdsArray.map((seatId, index) => (
          <span key={seatId}>
            {index > 0 && ', '}
            Seat {seatId}
          </span>
        ))}
      </p>
                      </div>
                      <div className="col-md-4 col-lg-3">
                        <p>&#8377;{total*200}</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-8 col-lg-9">
                        <p className="mb-1">Convenience Fees</p>
                      </div>
                      <div className="col-md-4 col-lg-3">
                        <p className="mb-0">&#8377;{Conveniencefee}</p>
                      </div>
                    </div>
                  </div>

                  <div className="row my-4">
                    <div className="col-md-4 offset-md-8 col-lg-3 offset-lg-9">
                      <p className="lead fw-bold mb-0" style={{ color: '#f37a27' }}>Total &#8377; {total*200+Conveniencefee}</p>
                    </div>
                    <button
  type="button"
  className="btn btn-primary btn-lg btn-block"
  onClick={() => {
    // Disable the button to prevent multiple clicks
    // Add loading spinner or other feedback
    emailjs.send('service_3q5p29s',templateID,{
      Host: "smtp.gmail.com",
      Username: "sharmaharsh75282@gmail.com",
      Password: "jxdcbruisvlpfmur",
      To: 'aforother@gmail.com',
      From: "sharmaharsh75282@gmail.com",
      Subject: "Sending Email using JavaScript",
      Body: "Well that was easy!!",
    })
      .then(function (message) {
        alert("Mail has been sent successfully");
      })
      .catch(function (error) {
        console.error("Error sending email:", error);
        alert("An error occurred while sending the email.");
      });
  }}
>
  Click Here to Proceed
</button>



                  </div>

                  <p className="mt-4 pt-2 mb-0">Want any help? <a href="#!" style={{ color: '#f37a27' }}>Please contact us</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default OrderSummary;
