package com.sunbeaminfo.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.User;





public interface UserDao extends JpaRepository<User, Long> {

	@Query("select new com.sunbeaminfo.entities.User(firstName, lastName) from User u where u.userEmail =?1 and u.password=?2")
	Optional<User> findByUserEmailAndPassword(String em,String pass);
	
	
	
//	@Query("Update User u set u.firstName=?1, u.lastName=?2, u.password=?3, u.userEmail=?4, u.contactNo=?5, u.userAge=?6, u.userUpi=?7 where u.id=?8")
//	int updateUserInfo(String firstName, String lastName,String password, String userEmail, String contactNo,int userAge, String userUpi,Long id); 
	
	
}
