import React, { useState, useEffect } from 'react';
import { useNavigate, useParams,Link } from 'react-router-dom';
import axios from 'axios';
import 'react-toastify/dist/ReactToastify.css';
import './styleseat.scss';
import { Button } from 'bootstrap';

const SeatBooking = () => {
  const [totalSeats, setTotalSeats] = useState([]);
  const [selectedSeatIds, setSelectedSeatIds] = useState([]);
  const navigate = useNavigate();
  const { showId } = useParams();

  useEffect(() => {
    const url = `http://localhost:7070/show/id/${showId}`;
    axios
      .get(url)
      .then((response) => {
        setTotalSeats(response.data);
      })
      .catch((error) => {
        console.error('Error fetching seat details:', error);
      });
  }, [showId]);

 

  const handleSeatClick = (e) => {
    const clickedSeat = e.target;
    
    if (clickedSeat.classList.contains('seat')) {
      const isOccupied = clickedSeat.classList.contains('occupied');
      const isAvailable = clickedSeat.classList.contains('available');
      
      if (!isOccupied) {
        clickedSeat.classList.toggle('selected');
        
        if (isAvailable) {
          clickedSeat.classList.toggle('available-selected');
        }
        
        updateCount();
        
        const seatId = parseInt(clickedSeat.id);
        setSelectedSeatIds(prevIds => {
          if (prevIds.includes(seatId)) {
            return prevIds.filter(id => id !== seatId);
          } else {
            return [...prevIds, seatId];
          }
        });
      }
    }
  };
  

  const updateCount = () => {
    const selectedSeats = document.querySelectorAll('.row .seat.selected');
    // Calculate and update total price
    // ... (your calculation code)
  };

  useEffect(() => {
    const container = document.querySelector('.container');
    container.addEventListener('click', handleSeatClick);

    return () => {
      container.removeEventListener('click', handleSeatClick);
    };
  }, []);

  const seatsPerRow = 8; // Number of seats in one row
  const numRows = Math.ceil(totalSeats.length / seatsPerRow); // Calculate the number of rows

  // Create an array of arrays to group seats into rows
  const groupedSeats = Array.from({ length: numRows }, (_, index) =>
    totalSeats.slice(index * seatsPerRow, (index + 1) * seatsPerRow)
  );


  console.log('Selected Seat IDs:', selectedSeatIds);

  return (
    <>
      
    <div className="seatbody">
    <div className="container">
      <div className="screen"></div>
      <br /><br /><br />
  {groupedSeats.map((rowSeats, rowIndex) => (
    
    <div className="row centered-row" key={rowIndex}>
      {rowSeats.map((seat) => (
        <div
          id={seat.seatId}
          
          key={seat.seatId}
          className={`seat ${seat.status.toLowerCase()} ${seat.status === 'BOOKED' ? 'occupied' : ''}`}
        >
          
        </div>

      ))}
    </div>
  ))}
</div>
      


      <p className="text">
        You have selected <span id="count">{totalSeats.length}</span> seats.
      </p>
      
      <div>
      <Link
  to={`/ordersummary/${totalSeats.length}?selectedSeats=${selectedSeatIds.join(',')}`}
  className="btn btn-primary btn-lg btn-block"
>
    <input
      type="button"
      variant="contained"
      color="success"
      value={"Click Here to Book Tickets"}
    />
  </Link>
</div>
    </div>
    
    </>
  );
};

export default SeatBooking;
