package com.sunbeaminfo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import com.sunbeaminfo.dto.ShowDTO;
import com.sunbeaminfo.dto.ShowListDTO;
import com.sunbeaminfo.dto.ShowSeatDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dao.ShowDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.Seat;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.enums.Category;
import com.sunbeaminfo.enums.Status;
import com.sunbeaminfo.service.ShowService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/show")
@CrossOrigin(origins = "*")
public class ShowController {

	@Autowired
	private ShowService ShowService;
	
	@Autowired
	private ShowDao showDao;
	
	
	public ShowController() {
		System.out.println("in ctor of " + getClass());
	}
	
	
	@GetMapping("/id/{showId}")
	public List<ShowSeatDTO> getByShowId(@PathVariable Long showId) {
		
		List<ShowSeatDTO> showSeatDTOs = new ArrayList<ShowSeatDTO>();
		
		
	 	Show show = showDao.findById(showId).get();
		
		for(Seat s : show.getSeats()) {
			ShowSeatDTO seat = new ShowSeatDTO(s.getSeatId() ,s.getSeatNumber(), s.getShow().getShowId(), s.getCategory(), s.getStatus());
			showSeatDTOs.add(seat);
		}
		
		return showSeatDTOs;
	}
	
	@GetMapping("/all")
	public List<Show> listAllShows(){
		return ShowService.listAllShows();
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> saveShowDetails(@RequestBody ShowDTO m) {
		
		return new ResponseEntity(ShowService.addShow(m),HttpStatus.OK);
	}
	
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteShow(@RequestParam Long id) {
		ShowService.deleteShow(id);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	@GetMapping("/moive/{movieId}")
	public List<ShowListDTO> movieShowList(@PathVariable Long movieId){
		return ShowService.movieShowList(movieId);
	}
	

	
	
}
