package com.sunbeaminfo.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import lombok.*;

@Entity
@Table(name = "user_tbl") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
@ToString(exclude = "password")
public class User {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long id;

	@Column(name = "first_name",length = 20,nullable = false)
	private String firstName;
	
	@Column(name = "last_name", length =20,nullable=false)
	private String lastName;
	
	
	@Column(name = "password",length=50)
	private String password;
	
	@Column(name = "user_email",length=20,unique = true,nullable = false)
	private String userEmail;
	
	@Column(name="user_contact",length = 12,unique = true,nullable = false)
	private String contactNo;
	
	@Column(name = "user_age",length=3)
	private int userAge;

	
	
	public User() {
		super();
	}

	public User(String firstName, String lastName, String password, String userEmail, String contactNo, int userAge) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
		this.userAge = userAge;
	}

	public  User(String userEmail, String password ) {
		this.userEmail = userEmail;
		this.password = password;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	
	
//	@OneToMany
//	private Set<UserUipDetails>  userUpi=new HashSet<UserUipDetails>();
//	
//	
//	@OneToMany
//	private Set<UserCardDetails> userCard = new HashSet<UserCardDetails>();
	
}
