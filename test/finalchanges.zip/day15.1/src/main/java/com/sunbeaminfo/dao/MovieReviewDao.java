package com.sunbeaminfo.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieCast;
import com.sunbeaminfo.entities.MovieGenre;





public interface MovieReviewDao extends JpaRepository<MovieGenre, Long> {

}
