package com.sunbeaminfo.dto;

import java.time.LocalDateTime;

public class BookingDTO {
	
	private Long userId;
	
	private int[] Seats; 
		
	private Long showId;

	private LocalDateTime transactionStratTime;

	public Long getUserId() {
		return userId;
	}

	public int[] getSeats() {
		return Seats;
	}

	public void setSeats(int[] seats) {
		Seats = seats;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getTransactionStratTime() {
		return transactionStratTime;
	}

	public void setTransactionStratTime(LocalDateTime transactionStratTime) {
		this.transactionStratTime = transactionStratTime;
	}

	public BookingDTO(Long userId, Long showId, LocalDateTime transactionStratTime) {
		super();
		this.userId = userId;
		this.showId = showId;
		this.transactionStratTime = transactionStratTime;
	}

	
	
}









