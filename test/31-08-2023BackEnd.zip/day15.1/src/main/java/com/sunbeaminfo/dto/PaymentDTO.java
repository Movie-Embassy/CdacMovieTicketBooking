package com.sunbeaminfo.dto;

public class PaymentDTO {

	
	private Long userId;
	
	private Long bookingId;
	
	private double price;

	public PaymentDTO(Long userId, Long bookingId, double price) {
		super();
		this.userId = userId;
		this.bookingId = bookingId;
		this.price = price;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
