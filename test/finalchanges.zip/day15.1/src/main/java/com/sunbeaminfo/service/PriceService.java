package com.sunbeaminfo.service;

import com.sunbeaminfo.dto.PriceByShowCategoryDTO;
import com.sunbeaminfo.dto.PriceDTO;
import com.sunbeaminfo.entities.Price;

public interface PriceService {

	Price getPriceById( Long priceId);
	
	Price getPriceByShowId( PriceByShowCategoryDTO obj);
	
	Price addPrice(PriceDTO price);
	
}
