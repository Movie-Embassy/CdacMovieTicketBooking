package com.sunbeaminfo.entities;

import java.util.Objects;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.enums.Category;
import com.sunbeaminfo.enums.Status;



@Entity
@Table(name="seat_tbl")
public class Seat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="seat_id")
	private Long seatId;
	
	@Column(name="seat_number"  )
	private Long seatNumber;
	
	@ManyToOne//(fetch = FetchType.LAZY)
	@JsonIgnore	// Ignore during JSON serialization to avoid circular references
	@JoinColumn(name="show_id", nullable = false)	
	private Show show;

	@Enumerated(EnumType.STRING)
	@Column(name="category"  )
	private Category category;
	
	@Enumerated(EnumType.STRING)
	@Column(name="status"  )
	private Status status;
	
	
	
	
	
	
	
	


	public Seat(Long seatId, Long seatNumber, Show show, Category category, Status status) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.show = show;
		this.category = category;
		this.status = status;
	}


	public Seat(Long seatId) {
		super();
		this.seatId = seatId;
	}


	public Seat() {
		super();
	}

	

	public Seat(Long seatNumber, Show show, Category category, Status status) {
		super();
		this.seatNumber = seatNumber;
		this.show = show;
		this.category = category;
		this.status = status;
	}

	
	
	
	

	public Long getSeatId() {
		return seatId;
	}


	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}


	public Long getSeatNumber() {
		return seatNumber;
	}


	public void setSeatNumber(Long seatNumber) {
		this.seatNumber = seatNumber;
	}


	public Show getShow() {
		return show;
	}


	public void setShow(Show show) {
		this.show = show;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	@Override
	public int hashCode() {
		return Objects.hash(seatId);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seat other = (Seat) obj;
		return Objects.equals(seatId, other.seatId);
	}


	

	
	
	
}
