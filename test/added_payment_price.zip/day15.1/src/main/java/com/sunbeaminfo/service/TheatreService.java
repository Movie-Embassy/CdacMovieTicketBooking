package com.sunbeaminfo.service;

import java.util.List;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.TheatreDTO;

import com.sunbeaminfo.entities.Theatre;




public interface TheatreService {
	
	
	Theatre addTheatre(TheatreDTO m);
	
	Theatre getTheatre(Long id);

	ApiResponse deleteTheatre(Long id);

	Theatre getTheatreDetails(Long theaterId);

	Theatre addtheatreDetails(TheatreDTO m);

	List<Theatre> getAllTheatres();



}
