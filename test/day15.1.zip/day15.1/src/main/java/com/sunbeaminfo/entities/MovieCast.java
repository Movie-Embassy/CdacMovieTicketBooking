package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name="movie_cast_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter

public class MovieCast {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_cast_id", nullable = false, unique = true)
	private long  movieCastId;
	

	@ManyToOne
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	
	@Column(name="cast", nullable = false , unique = true)
	private String cast;


	public long getMovieCastId() {
		return movieCastId;
	}


	public void setMovieCastId(long movieCastId) {
		this.movieCastId = movieCastId;
	}


	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}


	public String getCast() {
		return cast;
	}


	public void setCast(String cast) {
		this.cast = cast;
	}
	
	
	
	
	
	
	
}
