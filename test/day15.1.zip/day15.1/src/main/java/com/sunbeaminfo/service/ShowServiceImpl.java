package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.ShowDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class ShowServiceImpl implements ShowService {

	@Autowired
	private ShowDao ShowDao;
	
	
	
	@Override
	public List<Show> getAllShows() {
		System.out.println("11111111");
		return ShowDao.findAll();
	}

	@Override
	public Show addShow(Show m) {
		// TODO Auto-generated method stub
		return ShowDao.save(m);
	}

	@Override
	public Show getShow(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteShow(Long id) {
		ShowDao.deleteById(id);
		
		return new ApiResponse("Show is deleted");
	}

	@Override
	public Show saveNewShow(Show s) {
		// TODO Auto-generated method stub
		return ShowDao.save(s);
	}

	@Override
	public List<Show> listAllShows() {
		// TODO Auto-generated method stub
		return ShowDao.findAll();
	}
	
}
