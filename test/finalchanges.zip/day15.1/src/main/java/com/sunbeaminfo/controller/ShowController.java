package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;
import com.sunbeaminfo.dto.ShowDTO;
import com.sunbeaminfo.dto.ShowListDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.service.ShowService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/Show")
@CrossOrigin(origins = "*")
public class ShowController {

	@Autowired
	private ShowService ShowService;
	
	
	public ShowController() {
		System.out.println("in ctor of " + getClass());
	}
	
	
	@GetMapping("/all")
	public List<Show> listAllShows(){
		return ShowService.listAllShows();
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> saveShowDetails(@RequestBody ShowDTO m) {
		
		return new ResponseEntity(ShowService.addShow(m),HttpStatus.OK);
	}
	
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteShow(@RequestParam Long id) {
		ShowService.deleteShow(id);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	@GetMapping("/moive")
	public List<ShowListDTO> movieShowList(@RequestParam Long id){
		return ShowService.movieShowList(id);
	}
	

	
	
}
