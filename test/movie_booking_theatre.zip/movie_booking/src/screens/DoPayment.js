import InternetBanking from "./InternetBanking";
import CardPayment from "./CardPayment";
import UPI from "./UPI";
import Wallets from "./Wallets";
import { useState } from "react";
import { Link,Switch,Route } from "react-router-dom";
function DoPayment()
{

    const[val,setval]=useState("1");

   

    return(<>

          
<div style={{width:835,height:395,position:"relative",left:250,top:75,borderRadius:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}>
           
<Link to="/internetBanking"><div style={{width:250,height:80,borderRadius:10,position:"relative",left:20,top:20}}>
               <button style={{position:"relative",width:250,height:80,borderRadius:10,fontSize:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}> Internet Banking </button>
           </div></Link>
   
           <Link to="/CardPayment">  <div style={{width:250,height:80,borderRadius:10,position:"relative",left:20,top:30}}>
               <button style={{position:"relative",width:250,height:80,borderRadius:10,fontSize:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}> Debit/Credit Card </button>
           </div></Link>
   
           <Link to="/UPI"> <div style={{width:250,height:80,borderRadius:10,position:"relative",left:20,top:40}}>
               <button style={{position:"relative",width:250,height:80,borderRadius:10,fontSize:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}> UPI </button>
           </div></Link>
   
           <Link to="/wallets"> <div style={{width:250,height:80,borderRadius:10,position:"relative",left:20,top:50}}>
               <button style={{position:"relative",width:250,height:80,borderRadius:10,fontSize:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}> Wallets </button>
           </div></Link>
                    
           <div style={{width:500,height:355,position:"relative",left:310,top:-305,borderRadius:20,borderWidth:2,borderColor:"blue",borderStyle:"solid"}}>
         <br/> <br/>
         {
            <div>
              {/* <Link to="/internetBanking"></Link>
   
              <Link to="/UPI"></Link>

              <Link to="/CardPayment"></Link>

              <Link to="/wallets"></Link> */}


    <Switch>
            <Route path="/internetBanking" exact component={InternetBanking}/>
            <Route path="/UPI" exact component={UPI}/>
            <Route path="/CardPayment" exact component={CardPayment}/>
            <Route path="/Wallets" exact component={Wallets}/>
            <Route path="/" exact component={UPI}/>
            <Route path="/*" exact component={UPI}/>

    </Switch>
            </div>
         }
           {/* {InternetBanking()} */}
           {/* {CardPayment()} */}
           {/* {UPI()}   */}
           {/* {Wallets()}   */}
            
         <br/><br/>
                  
   
   
   
           </div>         
               
           </div>
        
        
        </>)
}
export default DoPayment;