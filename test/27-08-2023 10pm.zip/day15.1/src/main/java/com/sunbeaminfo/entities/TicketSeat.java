package com.sunbeaminfo.entities;

import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="ticket_seat")
public class TicketSeat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ticket_seat_id")
	private long ticketSeatId ;
	

	@ManyToOne
	@JoinColumn(name="ticket_id", nullable = false)
	private Ticket ticket;
	
	@ManyToOne
	@JoinColumn(name="seat_id", nullable = false)
	private Seat seat;

	public long getTicketSeatId() {
		return ticketSeatId;
	}

	public void setTicketSeatId(long ticketSeatId) {
		this.ticketSeatId = ticketSeatId;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	
	@Override
	public int hashCode() {
		return Objects.hash(ticketSeatId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TicketSeat other = (TicketSeat) obj;
		return ticketSeatId == other.ticketSeatId;
	}

	
	
	
}
