package com.sunbeaminfo.service;

import java.util.List;


import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.Screen;




public interface ScreenService {
	
	List<ScreenDto> getAllScreens();
	
	Screen addScreen(ScreenDto m);
	
	Screen getScreen(Long id);

	ApiResponse deleteScreen(Long id);

	Screen getscreenDetails(Long screenId);

	Screen addscreenDetails(ScreenDto m);
	

 }
