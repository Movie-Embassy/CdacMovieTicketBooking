function UPI() {
    return ( <>
    
    <div className="input-group">
   
   <div className="input-group-prepend" style={{flexWrap:"wrap",display:"flex"}}>


         <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:15,height:60}}>
            <input type="radio" name="same" value ="value1" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/gpay.jpg" alt="gpay" style={{position:"relative",left:30,width:60,height:60}}/>     
        </div>  

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:15,height:60}}>
            <input type="radio" name="same" value ="value2" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/bhim.jpg" alt="bhim" style={{position:"relative",left:30,width:60,height:60}}/>     
        </div> 

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:15,height:60}}>
            <input type="radio" name="same" value ="value3" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/Amazonpay.jpg" alt="amazonpay" style={{position:"relative",left:30,width:60,height:60}}/>     
        </div> 

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:15,height:60}}>
            <input type="radio" name="same" value ="value4" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/paytm.jpg" alt="paytm" style={{position:"relative",left:30,width:60,height:60}}/>     
        </div> 

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:15,height:60}}>
            <input type="radio" name="same" value ="value4" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/phonepe.jpg" alt="phonepay" style={{position:"relative",left:30,width:60,height:60}}/>     
        </div> 




   </div>
   
</div>
<center>
                        <input type="button" name="proceed" value ="Proceed" className="btn btn-info"/>    
                    </center>
    </> );
}

export default UPI;