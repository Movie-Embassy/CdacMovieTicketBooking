package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDTO;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.User;



public interface MovieService {
	
	List<Movie> getAllMovies();
	
	Movie addMovie(MovieDTO m);
	
	Movie getMovie(Long id);

	ApiResponse deleteMovie(Long id);

	Movie addmovieDetails(Movie m);

	Movie getmovieDetails(Long movieId);
}
