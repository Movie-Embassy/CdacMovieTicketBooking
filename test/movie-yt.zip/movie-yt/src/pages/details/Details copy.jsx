import React from 'react'
import useFetch from '../../hooks/useFetch'
import DetailsBanner from './detailsBanner/DetailsBanner';
import Cast from './cast/Cast';
import { useParams } from "react-router-dom";

const Details = () => {
  // const [data,loading ]=useFetch(`/movie/{movieId`);

  const { mediaType, id } = useParams();
    const { data, loading } = useFetch(`/${mediaType}/${id}/videos`);
    const { data: credits, loading: creditsLoading } = useFetch(
        `/${mediaType}/${id}/credits`
    ); 
  return (
    <div>
      <DetailsBanner/>
      <Cast data={credits?.cast} loading={creditsLoading} />
          </div>
  )
}

export default Details
