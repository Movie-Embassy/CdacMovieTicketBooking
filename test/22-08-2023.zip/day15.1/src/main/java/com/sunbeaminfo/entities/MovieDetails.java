package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.emuns.Format;
import com.sunbeaminfo.emuns.Language;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_details_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class MovieDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="surrogate_id")
	private long surrogateKey ;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name="movie_id")
	private Movie movie;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "movie_format",length=20)
	private Format format;
	
	@Enumerated(EnumType.STRING)
	@Column(length=20)
	private Language language ;

	
	
	public MovieDetails() {
		super();
	}

	public MovieDetails(long surrogateKey) {
		super();
		this.surrogateKey = surrogateKey;
	}



	public MovieDetails(Movie movie, Format format, Language language) {
		super();
		this.movie = movie;
		this.format = format;
		this.language = language;
	}

	public long getSurrogateKey() {
		return surrogateKey;
	}

	public void setSurrogateKey(long surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (surrogateKey ^ (surrogateKey >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieDetails other = (MovieDetails) obj;
		if (surrogateKey != other.surrogateKey)
			return false;
		return true;
	}
	
	

	
	
	
	
}
