package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="ticket_tbl")
public class Ticket {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ticket_id", nullable = false, unique = true)
	private long ticketId ;
	

	public Ticket() {
		super();
	}


	@ManyToOne
	@JoinColumn(name="user_id", nullable = false)
	private User user;
	
	@Column(name = "booking_date_time")
	private LocalDateTime bookingDateTime;
	
	@ManyToOne
	@JoinColumn(name="show_id", nullable = false)
	private Show show;
	
	
	@ManyToOne
	@JoinColumn(name="transaction_id", nullable = false)
	private Payment payment;

	public long getTicketId() {
		return ticketId;
	}

	public void setTicketId(long ticketId) {
		this.ticketId = ticketId;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	
	public Ticket(long ticketId) {
		super();
		this.ticketId = ticketId;
	}


	public Ticket(User user) {
		super();
		this.user = user;
	}


	@OneToOne
	@JoinColumn(name="booking_datetime", nullable = false)
	private Payment payment1;
	
	
	
}
