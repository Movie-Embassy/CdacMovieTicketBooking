package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="show_tbl")
public class Show {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="show_id" , unique = true)
	private Long showId ;
	
	@Column(name="show_datetime"  )
	private LocalDateTime showDateTime;
	
	
	@ManyToOne//(targetEntity = Theatre.class,fetch = FetchType.LAZY)
	@JoinColumn(name="theatre_id" )
	@JsonIgnore
	private Theatre theatre;
	
//	@ManyToOne//(targetEntity = Screen.class,fetch = FetchType.LAZY)
//	@JoinColumn(name="screen_id" )
//	private Screen screen;
	
	@ManyToOne//(targetEntity = Movie.class,fetch = FetchType.LAZY)
	@JoinColumn(name="movie_id" )
	
	private Movie movie;
	
	@OneToOne//(fetch = FetchType.LAZY)
	@JoinColumn(name="surrogate_id" )
	private MovieDetails movieDetails;

	
	
	
	public Show() {
		super();
	}

	

	public Show(Long showId, LocalDateTime showDateTime, Theatre theatre, Movie movie,
			MovieDetails movieDetails) {
		super();
		this.showId = showId;
		this.showDateTime = showDateTime;
		this.theatre = theatre;
		this.movie = movie;
		this.movieDetails = movieDetails;
	}



	public Show(LocalDateTime showDateTime, Theatre theatre, Movie movie, MovieDetails movieDetails) {
		super();
		this.showDateTime = showDateTime;
		this.theatre = theatre;
		this.movie = movie;
		this.movieDetails = movieDetails;
	}





	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(LocalDateTime showDateTime) {
		this.showDateTime = showDateTime;
	}

	public MovieDetails getMovieDetails() {
		return movieDetails;
	}

	public void setMovieDetails(MovieDetails movieDetails) {
		this.movieDetails = movieDetails;
	}
}
