package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.TheatreDTO;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.service.TheatreService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/Theatre")
@CrossOrigin(origins = "*")
public class TheatreController {

	@Autowired
	private TheatreService theatreService;
	
	
	public TheatreController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<Theatre> listAllTheatres(){
		
		return theatreService.getAllTheatres();
	}
	
	@PostMapping
	public Theatre saveTheatreDetails(@RequestBody TheatreDTO t) {
		return theatreService.addTheatre(t);
	}
	
	@DeleteMapping
	public ApiResponse deleteTheatre(@RequestParam Long id) {
		return theatreService.deleteTheatre(id);
	}
	
	
	@PutMapping
	public  Theatre updatetheatreInfo(@RequestBody TheatreDTO m) {
		theatreService.getTheatreDetails(m.getTheaterId());
		
		return theatreService.addtheatreDetails(m);
	}

}
