package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Payment;

public interface PaymentDao extends JpaRepository<Payment, Long> {

	@Query
	(value="select * from payment_tbl where user_id=?1;",nativeQuery=true)
	Payment getByUserId(Long Id);
	
	@Query
	(value="select * from payment_tbl where user_id=?1 and booking_id=?2;",nativeQuery=true)
	Payment getByUserIdBookingId(Long uId,Long bId);
}
