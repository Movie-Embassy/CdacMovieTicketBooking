package com.sunbeaminfo.entities;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Embeddable
@Entity
@Table(name="seat_tbl")
@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Seat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="seat_id")
	private Long seatId;
	
	@Column(name="seat_number"  )
	private int seatNumber;
	
	@ManyToOne
	@JoinColumn(name="theatre_id" )
	private Theatre theatre;
	
	@ManyToOne
	@JoinColumn(name="screen_id" )
	private Screen screen;
	
	
	@Enumerated(EnumType.STRING)
	@Column(name="status"  )
	private Status status;

	@Enumerated(EnumType.STRING)
	@Column(name="category"  )
	private Category category;
	
	
	
	
	
	
	public Seat() {
		
	}

	public Seat(int seatNumber, Status status, Category category) {
		this.seatNumber = seatNumber;
		this.status = status;
		this.category = category;
	}

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	
	
}
