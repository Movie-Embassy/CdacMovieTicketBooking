package com.sunbeaminfo.entities;


import javax.persistence.*;


@Entity
@Table(name = "admin_tbl") // to specify table name
public class Images {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "admin_id")
	private Long adminId;

	@Column(name = "first_name",length = 20,nullable = false)
	private String firstName;
	
	@Column(name = "last_name", length =20,nullable=false)
	private String lastName;
	
	
	@Column(name = "password",length=50)
	private String password;
	
	@Column(name = "admin_email",length=20,unique = true,nullable = false)
	private String adminEmail;
	
	@Column(name="admin_contact",length = 12,unique = true,nullable = false)
	private String contactNo;

	public Images() {
		super();
	}

	public Images(Long adminId, String firstName, String lastName, String password, String adminEmail,
			String contactNo) {
		super();
		this.adminId = adminId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.adminEmail = adminEmail;
		this.contactNo = contactNo;
	}

	public Images(String firstName, String lastName, String password, String adminEmail, String contactNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.adminEmail = adminEmail;
		this.contactNo = contactNo;
	}

	public Images(Long adminId) {
		super();
		this.adminId = adminId;
	}

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	
	
	
	
}
