import React from 'react';
import { AppBar, Avatar, Button, Tab, Tabs, Toolbar, Typography } from '@mui/material';
import MovieIcon from '@mui/icons-material/Movie';

const Header = () => {
  return (
    <React.Fragment>
      <AppBar sx={{background:"#063970"}}>
        <Toolbar>

                 <MovieIcon></MovieIcon>
         <Tabs sx={{marginLeft:''}} textColor='inherit'>

         <Tab label="Home"></Tab>
         </Tabs>
        <Button variant='contained' sx={{marginLeft:'auto'}}>SignIn</Button>
        <Button variant='contained' sx={{margin:'10px'}}>Logout</Button>
        {/* <Button variant="contained">Contained</Button> */}
        <Avatar alt='s' src="/media/harsh/A88289188288EBDE/WEBtechnologieslab/movie-yt/src/assets/avatar.png"></Avatar>
        </Toolbar>
      </AppBar>
    </React.Fragment> 
  );
}

export default Header;
