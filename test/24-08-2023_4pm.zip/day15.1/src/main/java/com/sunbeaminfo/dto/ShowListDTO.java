package com.sunbeaminfo.dto;

import java.time.LocalDateTime;

import com.sunbeaminfo.emuns.Format;
import com.sunbeaminfo.emuns.Language;

public class ShowListDTO {

	private Long showId;
	
	private LocalDateTime showDateTime;
	
	private Long theatreId;
	
	private String theatreName;
	
	private String theatreArea;
	
//	private Long movieId;
//	
//	private String movieName;
//	
//	private String 
	
	private Long movieDetailsId;
	
	private Format format;
	
	private Language language;

	public ShowListDTO() {
		super();
	}

	public ShowListDTO(Long showId, LocalDateTime showDateTime, Long theatreId, String theatreName, String theatreArea,
			Long movieDetailsId, Format format, Language language) {
		super();
		this.showId = showId;
		this.showDateTime = showDateTime;
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.theatreArea = theatreArea;
		this.movieDetailsId = movieDetailsId;
		this.format = format;
		this.language = language;
	}

	public ShowListDTO(LocalDateTime showDateTime, Long theatreId, String theatreName, String theatreArea,
			Long movieDetailsId, Format format, Language language) {
		super();
		this.showDateTime = showDateTime;
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.theatreArea = theatreArea;
		this.movieDetailsId = movieDetailsId;
		this.format = format;
		this.language = language;
	}

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(LocalDateTime showDateTime) {
		this.showDateTime = showDateTime;
	}

	public Long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getTheatreArea() {
		return theatreArea;
	}

	public void setTheatreArea(String theatreArea) {
		this.theatreArea = theatreArea;
	}

	public Long getMovieDetailsId() {
		return movieDetailsId;
	}

	public void setMovieDetailsId(Long movieDetailsId) {
		this.movieDetailsId = movieDetailsId;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
	
	
	
}
