package com.sunbeaminfo.dto;


import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.enums.Category;
import com.sunbeaminfo.enums.Status;

public class SeatDTO {
	
	private Long seatId;
	
	private Long seatNumber;
		
	private Show show;

	private Category category;
	
	private Status status;

	public SeatDTO(Long seatId, Long seatNumber, Show show, Category category, Status status) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.show = show;
		this.category = category;
		this.status = status;
	}

	public SeatDTO() {
		super();
	}

	public SeatDTO(Long seatNumber, Show show, Category category, Status status) {
		super();
		this.seatNumber = seatNumber;
		this.show = show;
		this.category = category;
		this.status = status;
	}

	public SeatDTO(Long seatId) {
		super();
		this.seatId = seatId;
	}
	
	
	
	
	

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public Long getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(Long seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
		

	
}
