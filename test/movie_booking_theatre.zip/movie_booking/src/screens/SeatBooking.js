import React, { useState } from 'react';
import './SeatBooking.css';
import classNames from 'classnames';
import { useHistory } from 'react-router-dom';



const SeatingArrangement = () => {
  const [seats, setSeats] = useState([
    {
      id: 1,
      letter: 'A',
      number: 1,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 2,
      letter: 'A',
      number: 2,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 3,
      letter: 'A',
      number: 3,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 4,
      letter: 'A',
      number: 4,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 5,
      letter: 'A',
      number: 5,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 6,
      letter: 'A',
      number: 6,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 7,
      letter: 'A',
      number: 7,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 8,
      letter: 'A',
      number: 8,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 9,
      letter: 'A',
      number: 9,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 10,
      letter: 'A',
      number: 10,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 11,
      letter: 'A',
      number: 11,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 12,
      letter: 'A',
      number: 12,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 1,
      letter: 'A',
      number: 1,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 2,
      letter: 'A',
      number: 2,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 3,
      letter: 'A',
      number: 3,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 4,
      letter: 'A',
      number: 4,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 5,
      letter: 'A',
      number: 5,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 6,
      letter: 'A',
      number: 6,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 7,
      letter: 'A',
      number: 7,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 8,
      letter: 'A',
      number: 8,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 9,
      letter: 'A',
      number: 9,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 10,
      letter: 'A',
      number: 10,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 11,
      letter: 'A',
      number: 11,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 12,
      letter: 'A',
      number: 12,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 1,
      letter: 'A',
      number: 1,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 2,
      letter: 'A',
      number: 2,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 3,
      letter: 'A',
      number: 3,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 4,
      letter: 'A',
      number: 4,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 5,
      letter: 'A',
      number: 5,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 6,
      letter: 'A',
      number: 6,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 7,
      letter: 'A',
      number: 7,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 8,
      letter: 'A',
      number: 8,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 9,
      letter: 'A',
      number: 9,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 10,
      letter: 'A',
      number: 10,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 11,
      letter: 'A',
      number: 11,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 12,
      letter: 'A',
      number: 12,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 1,
      letter: 'A',
      number: 1,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 2,
      letter: 'A',
      number: 2,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 3,
      letter: 'A',
      number: 3,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 4,
      letter: 'A',
      number: 4,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 5,
      letter: 'A',
      number: 5,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 6,
      letter: 'A',
      number: 6,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 7,
      letter: 'A',
      number: 7,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 8,
      letter: 'A',
      number: 8,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 9,
      letter: 'A',
      number: 9,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 10,
      letter: 'A',
      number: 10,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 11,
      letter: 'A',
      number: 11,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 12,
      letter: 'A',
      number: 12,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 1,
      letter: 'A',
      number: 1,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 2,
      letter: 'A',
      number: 2,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 3,
      letter: 'A',
      number: 3,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 4,
      letter: 'A',
      number: 4,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 5,
      letter: 'A',
      number: 5,
      isOccupied: false,
      isActive: false,
    },
    {
      id: 6,
      letter: 'A',
      number: 6,
      isOccupied: true,
      isActive: false,
    },
    {
      id: 7,
      letter: 'A',
      number: 7,
      isOccupied: true,
      isActive: false,
    }
  ]);

  const history = useHistory();

  const gotoPayment=()=>{
    history.push('./DoPayment');
  }


  const handleClick = (id) => 
  {
    setSeats(seats.map(seat =>
       {
        if (seat.id == id && seat.isActive== false)
         {
          var copy = {...seat};
          copy.map((seat)=>{
           
          if(seat.id==id){
              
          return    seat.isActive=true;
            }
          })

          setSeats={copy};
          // setSeats[id-1].isActive=true;
          return {

            isActive: !seat.isActive,
          };
        }
        else{
          setSeats[id-1].isActive=false;
          return seat;
        }
      })
    );
  };

  const buttonClasses = classNames({
    seat : !seats.isActive,
    selected : seats.isActive,
  });


//   return (
//     <div className="seating-container">
//       {seats.map((seat) => (
       
//        <div
//        key={seat.id}
//        className={classNames('seat', { 'selected': seat.isActive })}
//        onClick={()=>handleClick(seat.id)}
//      >
//        {seat.letter} {seat.number}
//      </div>
//       ))}
//     </div>
//   );
// };


return (
  <div className='body1'>
    <div className='container' style={{marginLeft:530,position:'relative',top:-150}}>
    <div className='screen' style={{widows:200}}></div>
    </div>
  <div className="seating-container" style={{position:'relative',top:-150}}>
    {seats.map((seat) => 
    {  
  if(seat.isOccupied === false)
  {
    return (
        <div
          key={seat.id}
          className={classNames('seat', { 'selected': seat.isActive })}
          onClick={()=>handleClick(seat.id)}
        >
          {seat.letter} {seat.number}
        </div>
    )
  }
  else if(seat.isOccupied=== true)
  {
    return(
      
      <div
          key={seat.id}
          className='occupied'
        >
          {seat.letter} {seat.number}
        </div>
    )
  }
  else if( seat.selected === true) 
  {
    return (
      <div
        key={seat.id}
        className={classNames('seat', { 'selected': seat.isActive })}
        onClick={()=>handleClick(seat.id)}
      >
        {seat.letter} {seat.number}
      </div>
  )

  }
  else{
    return (
      <div
        key={seat.id}
        className={classNames('selected', { 'seat': !seat.isActive })}
        onClick={()=>handleClick(seat.id)}
      >
        {seat.letter} {seat.number}
      </div>
  )
  }
})}
  </div>


  <div>
    <button type="button" class="btn btn-success" onClick={gotoPayment}>Book Seats</button>
  </div>
  </div>
);
};
export default SeatingArrangement;

