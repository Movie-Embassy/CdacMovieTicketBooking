package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.MovieDetailsDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class MovieDetailsServiceImpl implements MovieDetailsService {

	@Autowired
	private MovieDetailsDao movieDetailsDao;
	
	
	
	@Override
	public List<MovieDetails> getAllMovieDetailss() {
		System.out.println("11111111");
		return movieDetailsDao.findAll();
	}

	@Override
	public MovieDetails addMovieDetails(MovieDetails m) {
		// TODO Auto-generated method stub
		return movieDetailsDao.save(m);
	}

	@Override
	public MovieDetails getMovieDetails(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteMovieDetails(Long id) {
		movieDetailsDao.deleteById(id);
		
		return new ApiResponse("MovieDetails is deleted");
	}

	@Override
	public List<Long> movieSpecificDetails(Long movieId) {
		
		return movieDetailsDao.movieSpecificDetails(movieId).stream().map(m->m.getSurrogateKey()).collect(Collectors.toList());
	}

//	@Override
//	public MovieDetails addMovieDetails(String format, String lang, Long id) {
//		
//		return movieDetailsDao.addMovieDetails(format, lang, id);
//	}
	
}
