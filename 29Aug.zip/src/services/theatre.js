import axios from 'axios'
import { createUrl, log } from '../utils copy/utils'

export async function addTheatre(
  theaterName,
  theaterBankAcNo,
  bankAcOwnerName,
  theaterContactNo,
  theaterEmail,
  theaterCity,
  theaterArea,
) {
  // debugger
  // const url = createUrl('/user/register')
  const url = createUrl('/theatre/add')
  const body = {
    theaterName,
    theaterBankAcNo,
    bankAcOwnerName,
    theaterContactNo,
    theaterEmail,
    theaterCity,
    theaterArea,
  }

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.post(url, body)
    log(response)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}


export async function getTheatreList() {
  const url = createUrl('/theatre/theatres')

  try {
   
    const response = await axios.get(url)
    log(response.data)
    return response.data
  } catch (ex) {
    log(ex)
    return null
  }
}
