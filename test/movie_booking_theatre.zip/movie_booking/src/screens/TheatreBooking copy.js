// // import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
// // import '../../node_modules/bootstrap/dist/css/bootstrap.css';

// // function TheatreBooking()
// // {
// //     console.log("theatre Booking");
// //     const history = useHistory();
// //     var bookMovie = window.sessionStorage.getItem("MovieToBEBook");
// //     var SelectShow=()=>
// //     {
// //         history.push('/SeatBooking');
// //     }
// //     return(<>
// // <nav class="navbar navbar-default">
// //         <div class="container">
// //             <div class="navbar-header">
// //                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
// //                     <span class="sr-only">Toggle navigation</span>
// //                     <span class="icon-bar"></span>
// //                     <span class="icon-bar"></span>
// //                     <span class="icon-bar"></span>
// //                 </button>
// //                 <a class="navbar-brand" href="#">Start Bootstrap</a>
// //             </div>
// //             <div id="navbar" class="navbar-collapse collapse">
// //                 <ul class="nav navbar-nav">
// //                     <li class="active"><a href="#">Home</a></li>
// //                     <li><a href="#">About</a></li>
// //                     <li class="dropdown">
// //                         <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Shop <span class="caret"></span></a>
// //                         <ul class="dropdown-menu">
// //                             <li><a href="#">All Products</a></li>
// //                             <li role="separator" class="divider"></li>
// //                             <li><a href="#">Popular Items</a></li>
// //                             <li><a href="#">New Arrivals</a></li>
// //                         </ul>
// //                     </li>
// //                 </ul>
// //                 <ul class="nav navbar-nav navbar-right">
// //                     <li><a href="#"><i class="glyphicon glyphicon-shopping-cart"></i> Cart <span class="badge">0</span></a></li>
// //                 </ul>
// //             </div>
// //         </div>
// //     </nav>

// //     <header class="bg-dark py-5">
// //         <div class="container">
// //             <div class="text-center text-white">
// //                 <h1 class="display-4 fw-bold">Shop in style</h1>
// //                 <p class="lead fw-normal text-white-50 mb-0">With this shop homepage template</p>
// //             </div>
// //         </div>
// //     </header>

// //     <section class="py-5">
// //         <div class="container">
// //             <div class="row">
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Theatre-Name1</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Fancy Product</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Fancy Product</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Fancy Product</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Fancy Product</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //                 <div class="col-sm-6 col-md-3">
// //                     <div class="thumbnail">
// //                         <img src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..."/>
// //                         <div class="caption">
// //                             <h5 class="text-center">Fancy Product</h5>
// //                             <p class="text-center">$40.00 - $80.00</p>
// //                             <p class="text-center"><a href="#" class="btn btn-default" role="button">View options</a></p>
// //                         </div>
// //                     </div>
// //                 </div>
// //             </div>
// //         </div>
// //     </section>

   
// //         </>)
// // }
// // export default TheatreBooking;

// // // function TheatreBookings()
// // // {

// // // }

// // // export default TheatreBookings;
// import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
// import '../../node_modules/bootstrap/dist/css/bootstrap.css';

// function TheatreBooking() {
//     console.log("theatre Booking");
//     const history = useHistory();
//     var bookMovie = window.sessionStorage.getItem("MovieToBEBook");
//     var SelectShow = () => {
//         history.push('/SeatBooking');
//     };

//     return (
//         <>
//             <nav className="navbar navbar-default">
//                 <div className="container">
//                     <div className="navbar-header">
//                         <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
//                             <span className="sr-only">Toggle navigation</span>
//                             <span className="icon-bar"></span>
//                             <span className="icon-bar"></span>
//                             <span className="icon-bar"></span>
//                         </button>
//                         <a className="navbar-brand" href="#">Start Bootstrap</a>
//                     </div>
//                     <div id="navbar" className="navbar-collapse collapse">
//                         <ul className="nav navbar-nav">
//                             <li className="active"><a href="#">Home</a></li>
//                             <li><a href="#">About</a></li>
//                             <li className="dropdown">
//                                 <a href="#" className="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Shop <span className="caret"></span></a>
//                                 <ul className="dropdown-menu">
//                                     <li><a href="#">All Products</a></li>
//                                     <li role="separator" className="divider"></li>
//                                     <li><a href="#">Popular Items</a></li>
//                                     <li><a href="#">New Arrivals</a></li>
//                                 </ul>
//                             </li>
//                         </ul>
//                         <ul className="nav navbar-nav navbar-right">
//                             <li><a href="#"><i className="glyphicon glyphicon-shopping-cart"></i> Cart <span className="badge">0</span></a></li>
//                         </ul>
//                     </div>
//                 </div>
//             </nav>

//             <header className="bg-dark py-5">
//                 <div className="container">
//                     <div className="text-center text-white">
//                         <h1 className="display-4 fw-bold">Shop in style</h1>
//                         <p className="lead fw-normal text-white-50 mb-0">With this shop homepage template</p>
//                     </div>
//                 </div>
//             </header>

//             <section className="py-5">
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-md-8 col-md-offset-2">
//                             <ul className="list-group" >
//                                 <li className="list-group-item" style={{display:'flex',justifycontent: 'space-between'}} >
//                                     <h5 className="text-center">Theatre-Name1</h5>
//                                     <p className="text-center">$40.00 - $80.00</p>
//                                     <p className="text-center">
//                                         <button className="btn btn-default" onClick={SelectShow}>View options</button>
//                                     </p>
//                                 </li>
//                                 <li className="list-group-item">
//                                     <h5 className="text-center">Theatre-Name2</h5>
//                                     <p className="text-center">$40.00 - $80.00</p>
//                                     <p className="text-center">
//                                         <button className="btn btn-default" onClick={SelectShow}>View options</button>
//                                     </p>
//                                 </li>
//                                 {/* Add more theatre names as list items */}
//                             </ul>
//                         </div>
//                     </div>
//                 </div>
//             </section>
//         </>
//     );
// }

// export default TheatreBooking;
import { useHistory } from "react-router-dom/cjs/react-router-dom.min";
import '../../node_modules/bootstrap/dist/css/bootstrap.css';

function TheatreBooking() {
    console.log("theatre Booking");
    const history = useHistory();
    var bookMovie = window.sessionStorage.getItem("MovieToBEBook");
    var SelectShow = () => {
        history.push('/SeatBooking');
    };

    return (
        <>
             <nav className="navbar navbar-default">
               <div className="container">
                     <div className="navbar-header">
                         <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                             <span className="sr-only">Toggle navigation</span>
                             <span className="icon-bar"></span>
                             <span className="icon-bar"></span>
                             <span className="icon-bar"></span>
                         </button>
                         <a className="navbar-brand" href="#">Start Bootstrap</a>
                     </div>
                     <div id="navbar" className="navbar-collapse collapse">
                         <ul className="nav navbar-nav">
                             <li className="active"><a href="#">Home</a></li>
                             <li><a href="#">About</a></li>
                             <li className="dropdown">
                                 <a href="#" className="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Shop <span className="caret"></span></a>
                                 <ul className="dropdown-menu">
                                     <li><a href="#">All Products</a></li>
                                     <li role="separator" className="divider"></li>
                                     <li><a href="#">Popular Items</a></li>
                                     <li><a href="#">New Arrivals</a></li>
                                 </ul>
                             </li>
                         </ul>
                         <ul className="nav navbar-nav navbar-right">
                             <li><a href="#"><i className="glyphicon glyphicon-shopping-cart"></i> Cart <span className="badge">0</span></a></li>
                         </ul>
                     </div>
                 </div>
             </nav>

             <header className="bg-dark py-5">
                 <div className="container">
                     <div className="text-center text-white">
                         <h1 className="display-4 fw-bold">Shop in style</h1>
                         <p className="lead fw-normal text-white-50 mb-0">With this shop homepage template</p>
                     </div>
                 </div>
             </header>


            <section className="py-5">
                {/* <div className="container">
                    <div className="row"> */}
                        <div className="col-md-10">

                            <table>
                                <tr>
                                    <td>
                                    Theatre-Name2
                                    </td>
                                    <td colSpan={3}>
                                    <button className=" col-md-1 ">Show1</button>
                                            <button className=" col-md-1 ">Show2</button>
                                            <button className=" col-md-1 ">Show3</button>
                                            <button className=" col-md-1 ">Show4</button>
                                            <button className=" col-md-1 ">Show5</button>
                                            <button className="col-md-1">Show6</button>
                                    </td>
                                </tr>
                            </table>






                            <ul className="list-group">
                            <li className="list-group-item">
                                    <div className="row align-items-center" style={{display:'flex',justifyContent:'space-between'}}>
                                        {/* <div className="col-md-6" > */}
                                            <h5 className=" ">Theatre-Name2</h5>
                                            <button className=" col-md-1 ">Show1</button>
                                            <button className=" col-md-1 ">Show2</button>
                                            <button className=" col-md-1 ">Show3</button>
                                            <button className=" col-md-1 ">Show4</button>
                                            <button className=" col-md-1 ">Show5</button>
                                            <button className="col-md-1">Show6</button>
                                                                                
                                    </div>
                              
                               </li>
                                
                            </ul>
                        </div>
                    {/* </div>
                </div> */}
            </section>
        </>
    );
}

export default TheatreBooking;
