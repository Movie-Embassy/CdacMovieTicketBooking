import { useState,useEffect } from 'react'
import './App.css'
import {fetchDataFromApi} from '../src/utils/api'
import { useSelector, useDispatch } from 'react-redux'
import { getApiConfiguration } from './store/homeslice'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'


import Header from './components/header/Header'
import Footer from './components/footer/Footer'
import Forgot from './components/Forgot/Forgot'
import Details from './pages/details/Details'
import Home from './pages/home/Home'
import SearchResult from './pages/searchResult/SearchResult'
import OrderSummary from './pages/orderSummary/OrderSummary'
import Seatbooking from './pages/bookTicket/seatbooking'
// import SignIn from './components/SignIn/SignIn'
import SignIn from './components/SignIn/SignIn'
import Login from './components/Login/Login'

function App() {

  const dispatch=useDispatch();
  const {url}=useSelector((state)=> state.home);
  

  useEffect(()=>{
    fetchApiConfig();
  },[])

  
  const fetchApiConfig=()=>
  {
    fetchDataFromApi('/configuration')
    .then((res)=>
    {
      console.log(res);
      const url =
      {
        backdrop: res.images.secure_base_url +
        "original",
        poster: res.images.secure_base_url +
        "original",
        profile: res.images.secure_base_url +
        "original",
      }

     dispatch(getApiConfiguration(url));
    })
  }
  
  return (
   <BrowserRouter>
   <Header/>
   <Routes>
    <Route   path="/" element={<Home/>}  />
    <Route   path="/Signin" element={<SignIn/>}  />
    <Route   path="/Forgot" element={<Forgot/>}  />
    <Route   path="/Login" element={<Login/>}  />
    <Route   path="/search/:query" element={<SearchResult/>}  />
    {/* <Route   path="/:mediaType/:id" element={<Details/>}/> */}
    <Route   path="/details/:id" element={<Details/>}/>
    <Route   path="/ordersummary" element={<OrderSummary/>}/>
    <Route   path="/bookticket" element={<Seatbooking/>}/>
    <Route   path="/ordersummary/:count" element={<OrderSummary/>}/>
    <Route   path="*" element={<Home/>}/>

    
   </Routes>
   {/* <Footer/> */}
   <ToastContainer />
   </BrowserRouter>


  )
}

export default App
