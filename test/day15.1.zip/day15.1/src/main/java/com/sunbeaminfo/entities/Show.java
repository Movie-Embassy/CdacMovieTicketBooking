package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="show_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Show {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="show_id", nullable = false, unique = true)
	private Long showId ;
	
	@Column(name="show_datetime" , nullable = false)
	private LocalDateTime showDateTime;
	

	@ManyToOne
	@JoinColumn(name="theatre_id", nullable = false)
    private Theatre theatre;
	

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	@ManyToOne
	@JoinColumn(name="screen_id", nullable = false)
	private Screen screen;
	
	
	@ManyToOne
	@JoinColumn(name="surrogate_id", nullable = false)
	private MovieDetails movieDetails;

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(LocalDateTime showDateTime) {
		this.showDateTime = showDateTime;
	}

	public Screen getScreen() {
		return screen;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	public MovieDetails getMovieDetails() {
		return movieDetails;
	}

	public void setMovieDetails(MovieDetails movieDetails) {
		this.movieDetails = movieDetails;
	}
}
