package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDetailsDTO;
import com.sunbeaminfo.entities.MovieDetails;



public interface MovieRelatedService {
	
	
	
}
