package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Table(name="screen_format_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class ScreenFormat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="screen_format_id", nullable = false, unique = true)
	private long  screenFormatId;
	
	public long getScreenFormatId() {
		return screenFormatId;
	}

	public void setScreenFormatId(long screenFormatId) {
		this.screenFormatId = screenFormatId;
	}

	public Screen getScreen() {
		return screen;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	
	@ManyToOne
	@JoinColumn(name="screen_id", nullable = false)
	private Screen screen;
	
	
	@ManyToOne
	@JoinColumn(name="format", nullable = false)
	private Movie movie;
}
