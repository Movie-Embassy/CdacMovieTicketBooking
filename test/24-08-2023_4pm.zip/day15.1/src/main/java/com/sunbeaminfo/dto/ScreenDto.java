package com.sunbeaminfo.dto;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.sunbeaminfo.entities.Theatre;

public class ScreenDto {
	
	private Long screenId;
	
	private int screenNumber;
	
	private Long theatreId;
	
	public ScreenDto() {
	
	}

	public ScreenDto(Long screenId, int screenNumber, Long theatreId) {
		super();
		this.screenId = screenId;
		this.screenNumber = screenNumber;
		this.theatreId = theatreId;
	}

	public Long getScreenId() {
		return screenId;
	}

	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public int getScreenNumber() {
		return screenNumber;
	}

	public void setScreenNumber(int screenNumber) {
		this.screenNumber = screenNumber;
	}

	public Long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}
	
	
}
