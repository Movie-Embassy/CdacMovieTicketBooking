package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.ScreenDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class ScreenServiceImpl implements ScreenService {

	@Autowired
	private ScreenDao screenDao;
	
	
	
	@Override
	public List<Screen> getAllScreens() {
		System.out.println("11111111");
		return screenDao.findAll();
	}

	@Override
	public Screen addScreen(Screen m) {
		// TODO Auto-generated method stub
		return screenDao.save(m);
	}

	@Override
	public Screen getScreen(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteScreen(Long id) {
		screenDao.deleteById(id);
		
		return new ApiResponse("Screen is deleted");
	}

	
	
}
