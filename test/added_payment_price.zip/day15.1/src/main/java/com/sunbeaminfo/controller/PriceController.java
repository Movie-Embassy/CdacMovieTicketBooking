package com.sunbeaminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.PriceByShowCategoryDTO;
import com.sunbeaminfo.dto.PriceDTO;
import com.sunbeaminfo.entities.Price;
import com.sunbeaminfo.service.PriceService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping
public class PriceController {

	@Autowired
	private PriceService priceService;

	public PriceController() {
		super();
	}
	
	@GetMapping("/priceid")
	Price getPriceById(@RequestParam Long Id)
	{
		return priceService.getPriceById(Id);
	}
	
	@GetMapping("/showid")
	Price getPriceByShowAndCategory(@RequestBody PriceByShowCategoryDTO obj)
	{
		return priceService.getPriceByShowId(obj);
	}
	
	@PostMapping("/price")
	Price addPrice(@RequestBody PriceDTO pricedto)
	{
	return priceService.addPrice(pricedto);
	}
}
