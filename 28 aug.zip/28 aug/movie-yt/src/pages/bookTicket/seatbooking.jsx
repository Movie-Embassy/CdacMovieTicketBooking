import React, { useState, useEffect } from 'react';
import "./styleseat.scss";
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addSeats } from '../../store/seatSlice';
import { ToastContainer, toast } from 'react-toastify';
import Button from '@mui/material/Button';

import 'react-toastify/dist/ReactToastify.css';

const SeatBooking = () => {
  const [totalSeats,setTotalSeats]=useState(null);
  const Navigate = useNavigate();
  const dispatch = useDispatch();


  useEffect(()=>
  {
    dispatch(addSeats(totalSeats));
    localStorage.setItem('total', totalSeats);
  },[totalSeats])
  

  
  // Initialize state variables
  const [ticketPrice, setTicketPrice] = useState(10);
  const [selectedSeats, setSelectedSeats] = useState([]);

  // Handle movie select change
  // const handleMovieChange = (e) => {
  //   setTicketPrice(+e.target.value);
  // };

  // Handle seat click
  const handleSeatClick = (e) => {
    if (e.target.classList.contains('seat') && !e.target.classList.contains('occupied')) {
      e.target.classList.toggle('selected');
      updateCount();
    }
  };
  
  // Update count and total
  const updateCount = () => {
    const selectedSeats = document.querySelectorAll('.row .seat.selected');
    
    setTotalSeats(selectedSeats.length);
    
    setSelectedSeats(selectedSeats);
    

    // Calculate and update total price
    const totalPrice = totalSeats * ticketPrice;
    document.getElementById('count').innerText = totalSeats;
    document.getElementById('total').innerText = totalPrice;
  };

  useEffect(() => {
    
    // Set up event listeners when the component mounts
    const container = document.querySelector('.container');
    const movieSelect = document.getElementById('movie');

    // movieSelect.addEventListener('change', handleMovieChange);
    container.addEventListener('click', handleSeatClick);

    // Clean up the event listeners when the component unmounts
    return () => {
      // movieSelect.removeEventListener('change', handleMovieChange);
      container.removeEventListener('click', handleSeatClick);
    };
  }, [ticketPrice]);
  return (
    <div className="seatbody">
      <div className="movie-container">
        {/* <label>Pick a movie:</label> */}
        {/* <select id="movie">
          <option value="10">Avengers: Endgame ($10)</option>
          <option value="12">Joker ($12)</option>
          <option value="8">Toy Story 4 ($8)</option>
          <option value="9">The Lion King ($9)</option>
        </select> */}
      </div>


    <ul className="showcase">
      <li>
        <div className="seat"></div>
        <small>Available Seat</small>
      </li>

      <li>
        <div className="seat selected"></div>
        <small>Selected</small>
      </li>

      <li>
        <div className="seat occupied"></div>
        <small>Occupied</small>
      </li>
    </ul>

    <div className="container" >
      <div className="screen"></div>
      <br/>
      <br/>
      <br/>
        <div style={{paddingLeft:'465px'}}>
        <center>
        <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
      </div>
      <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat "></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
      </div>

      <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat occupied"></div>
        <div className="seat occupied"></div>
      </div>

      <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
      </div>

      <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat occupied"></div>
        <div className="seat occupied"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
      </div>

      <div className="row">
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat"></div>
        <div className="seat occupied"></div>
        <div className="seat occupied"></div>
        <div className="seat occupied"></div>
        <div classNames="seat"></div>
      </div>
        </center>
        </div>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>

    <p className="text">
      You have selected <span id="count">{totalSeats}</span> seats for a price of $<span id="total">0</span>
    </p>
    <div>

        < Button variant="contained" color="success"onClick={(e)=>{
          if(totalSeats>0)
          {

            Navigate(`/ordersummary/${totalSeats}`)
          }
          else
           {
            toast.error("Choose Atleast 1 Ticket", {
            position: toast.POSITION.TOP_CENTER,
          });
         
         
        }
        }}>Click Here to Book tickets</Button>
    </div>

    </div>


  );
}

export default SeatBooking;