package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Show;



public interface ScreenService {
	
	List<Screen> getAllScreens();
	
	Screen addScreen(Screen m);
	
	Screen getScreen(Long id);

	ApiResponse deleteScreen(Long id);
	

 }
