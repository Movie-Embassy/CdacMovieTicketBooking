package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="screen_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Screen {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="screen_id", nullable = false, unique = true)
	private Long screenId;
	
	@Column(name="screen_number" , nullable = false)
	private int screenNumber;

	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public void setScreenNumber(int screenNumber) {
		this.screenNumber = screenNumber;
	}

	public Long getScreenId() {
		return screenId;
	}

	public int getScreenNumber() {
		return screenNumber;
	}
	
	
	@ManyToOne
	@JoinColumn(name="theatre_id", nullable = false)
	private Theatre theatre;

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	} 
	
}
