//package com.sunbeaminfo.controller;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//
//
//import com.sunbeaminfo.entities.MovieCast;
//import com.sunbeaminfo.service.MovieRelatedService;
//
//import io.swagger.v3.oas.annotations.parameters.RequestBody;
//
//
//
//@RestController // mandatory class level anno , consists of =@Controller : cls level
//// +@ResponseBody : ret type of req handling
//// methods(@RequestMapping/@GetMapping...)
//@RequestMapping("/MovieInfo")
//@CrossOrigin(origins = "*")
//public class MovieRelatedController {
//
//	@Autowired
//	private MovieRelatedService movieRelatedService;
//	
//	
//	public MovieRelatedController() {
//		System.out.println("in ctor of " + getClass());
//	}
//	
//	@PostMapping("/MovieCast/{moiveId}")
//	public MovieCast addMovieCast(@RequestBody mc,@PathVariable Long moiveId) {
//		return movieRelatedService.addNewCast(mc,moiveId);
//	}
//	
//
//}
