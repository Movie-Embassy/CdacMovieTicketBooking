const container = document.querySelector('.container');
const showcase = document.querySelector('.showcase');
const seats = document.querySelectorAll('.row .seat:not(.occupied)'); // Fix the selector
const count = document.getElementById('count');
const total = document.getElementById('total');
const movieSelect = document.getElementById('movie');

let ticketPrice = +movieSelect.value;

function updateCount() {
  const selectedSeats = document.querySelectorAll('.row .seat.selected');
  const totalSeats = selectedSeats.length;

  count.innerText = totalSeats;
  total.innerText = totalSeats * ticketPrice;
}

// Initial count and total set
updateCount();

// Movie select event
movieSelect.addEventListener('change', (e) => {
  ticketPrice = +e.target.value;
  updateCount();
});

// Seat click event
container.addEventListener('click', (e) => {
  if (e.target.classList.contains('seat') && !e.target.classList.contains('occupied')) {
    e.target.classList.toggle('selected');
    updateCount();
  }
});
