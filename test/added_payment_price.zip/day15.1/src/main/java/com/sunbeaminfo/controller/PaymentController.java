package com.sunbeaminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.PaymentByUidBidDTO;
import com.sunbeaminfo.dto.PaymentDTO;
import com.sunbeaminfo.entities.Payment;
import com.sunbeaminfo.service.PaymentService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	public PaymentController() {
		super();
	}
	
	//getByUserId(Long id)
	
	@GetMapping("/id")
	Payment getByUserId(@RequestParam Long Id)
	{
	   return paymentService.getByUserId(Id);	
	}
	
	
	//getByUserIdAndBookingId(
	@GetMapping
	Payment getByUserIdandBookingId(@RequestBody PaymentByUidBidDTO obj)
	{
	   return paymentService.getByUserIdAndBookingId(obj);	
	}
	
	//addPayment(PaymentDTO pdto)
	@PostMapping("/payment")
	Payment addPayment(@RequestBody PaymentDTO obj)
	{
	   return paymentService.addPayment(obj);	
	}
}
