package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="payment_tbl")
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="transaction_id")
	private Long transactionId ;

	@Column(name="payment_amount")
	private double paymentAmount;

	@Column(name="payment_date_time")
	private LocalDateTime paymentDateTime;
	

	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;

	
	@OneToOne
	@JoinColumn(name="booking_id")
	private Booking booking;


	public Payment(double paymentAmount, LocalDateTime paymentDateTime, User user, Booking booking) {
		super();
		this.paymentAmount = paymentAmount;
		this.paymentDateTime = paymentDateTime;
		this.user = user;
		this.booking = booking;
	}


	public Long getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}


	public double getPaymentAmount() {
		return paymentAmount;
	}


	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}


	public LocalDateTime getPaymentDateTime() {
		return paymentDateTime;
	}


	public void setPaymentDateTime(LocalDateTime paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Booking getBooking() {
		return booking;
	}


	public void setBooking(Booking booking) {
		this.booking = booking;
	}
	
	
	
	
	
	
}
