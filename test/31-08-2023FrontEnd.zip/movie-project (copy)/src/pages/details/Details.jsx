// import React, { useEffect,useState } from 'react';
// import useFetch from '../../hooks/useFetch';
// import DetailsBanner from './detailsBanner/DetailsBanner';
// import Cast from './cast/Cast';
// import { useParams } from 'react-router-dom';

// const Details = () => {
//   const { id } = useParams();
//   console.log(id);
//   // const { data, loading, error } = useFetch(`/Movie/${id}`);
//   const [movie, setMovie] = useState();

//   useEffect(() => {
//     // Fetch movie details by ID from your Spring Boot API using the relative path
//     const url=`http://localhost:7070/Movie/${id}`
//     fetch(url)
//       .then((response) => response.json())
//       .then((data) => setMovie(data))
//       .catch((error) => console.error('Error fetching movie details:', error));
     
//   }, [id]);

//   return (
//     <div>
//       <DetailsBanner  />
//       {console.log(data)}
//       {loading ? (
//         <p>Loading...</p>
//       ) : error ? (
//         <p>{error}</p>
//       ) : (
//         <Cast data={data?.movieCast} />
//       )}
//     </div>
//   );
// };

// export default Details;


import React, { useEffect, useState } from 'react';
import useFetch from '../../hooks/useFetch';
import DetailsBanner from './detailsBanner/DetailsBanner';
import Cast from './cast/Cast';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { Navigate } from 'react-router-dom';

const Details = () => {
  const Navigate=useNavigate();
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [imageData, setImageData] = useState('');

  // useEffect(() => {
  //   // Fetch movie details by ID from your Spring Boot API using the relative path
  //   const url = `http://localhost:7070/Movie/${id}`;
  //   fetch(url)
  //     .then((response) => response.json())
  //     .then((data) => setMovie(data))
  //     .catch((error) => console.error('Error fetching movie details:', error));
{/*  this above code is working and displaying cast name but not photos*/}

      // const url = `http://localhost:7070/Movie/${id}`;
      // const config = { responseType: 'arraybuffer' };
      // const response =  axios.get(urlimage, config);
      // const blob = new Blob([response.data], { type: 'image/jpeg' });
      
          // const imageUrl = URL.createObjectURL(blob);

      // const urlimage = `http://localhost:7070/Movie/${id}`;
      // const config = { responseType: 'arraybuffer' };
  
      // axios.get(urlimage, config)
      //   .then(response => {
      //     console.log("response:", response);
      //     console.log("response data:", response.data);
  
      //     const blob = new Blob([response.data], { type: 'image/jpeg' });
      //     const imageUrl = URL.createObjectURL(blob);
      //     setImageData(imageUrl);
      //   })
      //   .catch(ex => {
      //     console.log(ex);
      //   });

  // }, [id]);
  useEffect(() => {
    // Fetch movie details by ID from your Spring Boot API using the relative path
    const url = `http://localhost:7070/movie/${id}`;
    axios
      .get(url)
      .then((response) => {
        setMovie(response.data);
      })
      .catch((error) => {
        console.error('Error fetching movie details:', error);
      });
  
    const fetchImages = async () => {
      const url = `http://localhost:7070/images/${id}`;
      console.log('urlimage:', url);
      const config = { responseType: 'arraybuffer' };
  
      try {
        const response = await axios.get(url, config);
        const blob = new Blob([response.data], { type: 'image/jpeg' });
        const imageUrl = URL.createObjectURL(blob);
        setImageData(imageUrl); // Set imageUrl as state
        console.log('harsh', imageUrl);
      } catch (ex) {
        console.log(ex);
      }
    };
  
    fetchImages();
  }, [id]);
  

  // const [imageData, setImageData] = useState([]);
  // useEffect(() => {
  //   const url = `http://localhost:7070/Movie/${id}`;
  //   const config = { responseType: 'arraybuffer' };

  //   axios.get(url, config)
  //     .then(response => {
  //       console.log("response:", response);
  //       console.log("response data:", response.data);

  //       const blob = new Blob([response.data], { type: 'image/jpeg' });
  //       const imageUrl = URL.createObjectURL(blob);
  //       setImageData(imageUrl);
  //     })
  //     .catch(ex => {
  //       console.log(ex);
  //     });
  // }, []); // You don't need [imageData] as a dependency here

  // const data = imageData;
  // console.log("data", data);
  // console.log(data)
    console.log("imagedata",imageData);
  return (
    <div>
      {/* {console.log("details about:",movie.movieCast)} */}
      {
      console.log("mov",movie)}
      <DetailsBanner  data1={imageData} />
      
      {movie ? (
        <Cast data={movie.movieCast} />
        
      ) : (
        <p>Loading...</p>
      )}
      <div>
        
        <button type="button" class="btn btn-success" onClick={(e)=>{
         Navigate(`/showlist/${id}`)
        }}>Book Ticket</button>
        

      </div>
    </div>
  );
};

export default Details;
