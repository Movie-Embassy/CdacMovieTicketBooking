package com.sunbeaminfo.service;

import com.sunbeaminfo.dto.PaymentByUidBidDTO;
import com.sunbeaminfo.dto.PaymentDTO;
import com.sunbeaminfo.entities.Payment;

public interface PaymentService {

	Payment getByUserId(Long id);
	
	Payment getByUserIdAndBookingId(PaymentByUidBidDTO obj );
	
	Payment addPayment (PaymentDTO pdto);
	
	
	
}
