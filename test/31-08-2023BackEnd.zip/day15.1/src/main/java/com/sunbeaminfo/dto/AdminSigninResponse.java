package com.sunbeaminfo.dto;

import java.util.Optional;

import com.sunbeaminfo.entities.Admin;

public class AdminSigninResponse {
	public AdminSigninResponse(String token, String message, Admin admin) {
		super();
		this.token = token;
		this.message = message;
		this.admin = admin;
	}	


	private String token;
	private String message;
	private Admin admin;
	
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Admin getadmin() {
		return admin;
	}
	public void setadmin(Admin admin) {
		this.admin = admin;
	}

	

}
