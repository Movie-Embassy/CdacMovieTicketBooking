package com.sunbeaminfo.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.User;



public interface UserService {
	
	List<User> getAllUsers();
	
	User addUser(User u);
	
	User getUser(Long id);
	
	Optional<User> findByEmailandPassword(String e,String p);
	
	ApiResponse deleteUser(Long id);


	User getuserDetails(Long userId);

	String sendEmail(User user);

	User updateUser(User u);
	
	boolean hasExipred(LocalDateTime expiryDateTime); 
	
}
