package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name="movie_cast_tbl")		// Define the table name in the database
public class MovieCast {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	 // Generate unique IDs for movie casts
	@Column(name="movie_cast_id", nullable = false, unique = true)
	private long  movieCastId;
	

    // Many-to-One relationship with Movie entity (lazy fetch to avoid unnecessary loading)
	@ManyToOne//(fetch = FetchType.LAZY)
	@JsonIgnore	// Ignore during JSON serialization to avoid circular references
	@JoinColumn(name="movie_id", nullable = false)	// Foreign key column referencing movie_id in Movie table
	private Movie movie;
	
	
	@Column(name="cast", nullable = false , unique = true)
	private String cast;

	@Lob
	@Column(name = "cast_image")
	private byte[] castImg;
	
	
	
	

    // Default constructor
	public MovieCast() {
		super();
	}
	

    // Constructor with all fields
	public MovieCast(long movieCastId, Movie movie, String cast, byte[] castImg) {
		super();
		this.movieCastId = movieCastId;
		this.movie = movie;
		this.cast = cast;
		this.castImg = castImg;
	}


    // Constructor without movieCastId
	public MovieCast(Movie movie, String cast, byte[] castImg) {
		super();
		this.movie = movie;
		this.cast = cast;
		this.castImg = castImg;
	}


    // Getters and Setters for all fields
	public long getMovieCastId() {
		return movieCastId;
	}


	public void setMovieCastId(long movieCastId) {
		this.movieCastId = movieCastId;
	}


	public Movie getMovie() {
		return movie;
	}


	public void setMovie(Movie movie) {
		this.movie = movie;
	}


	public String getCast() {
		return cast;
	}


	public void setCast(String cast) {
		this.cast = cast;
	}


	public byte[] getCastImg() {
		return castImg;
	}


	public void setCastImg(byte[] castImg) {
		this.castImg = castImg;
	}


	
	 // Additional methods like hashCode, equals, etc. have been provided
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieCastId ^ (movieCastId >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieCast other = (MovieCast) obj;
		if (movieCastId != other.movieCastId)
			return false;
		return true;
	}
	
	


	
	
	
	
	
	
	
}
