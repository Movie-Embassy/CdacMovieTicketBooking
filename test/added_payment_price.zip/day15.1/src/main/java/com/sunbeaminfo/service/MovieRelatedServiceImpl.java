package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.MovieCastDao;
import com.sunbeaminfo.dao.MovieDetailsDao;
import com.sunbeaminfo.dao.MovieGenreDao;
import com.sunbeaminfo.dao.MovieReviewDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDetailsDTO;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class MovieRelatedServiceImpl implements MovieRelatedService {

	@Autowired
	private MovieDetailsDao movieDetailsDao;
	
	@Autowired
	private MovieCastDao movieCastDao; 
	
	@Autowired
	private MovieGenreDao movieGenreDao;
	
	@Autowired
	private MovieReviewDao movieReviewDao;

	
	

}


