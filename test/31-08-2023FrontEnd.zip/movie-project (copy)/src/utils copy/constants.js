export const constants = {
  serverUrl: 'http://localhost:7070',
}
