package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.entities.ImageEntity;
import com.sunbeaminfo.entities.ImageRepository;

@Service
public class ImageService {

    @Autowired
    private ImageRepository imageRepository;

    public List<byte[]> getAllImages() {
        List<byte[]> listImageEntity = imageRepository.findAll()
            .stream()
            .map(e -> e.getImageData())
            .collect(Collectors.toList());

        if (!listImageEntity.isEmpty()) {
            return listImageEntity;
        } else {
            throw new RuntimeException("Image not found");
        }
    }
}
