package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_details_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class MovieDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="surrogate_id", nullable = false, unique = true)
	private long surrogateKey ;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "movie_format",length=20)
	private Format format;
	
	@Enumerated(EnumType.STRING)
	@Column(length=20)
	private Language language ;

	
	
	public MovieDetails() {
		super();
	}


	public MovieDetails(Movie movie, Format format, Language language) {
		super();
		this.movie = movie;
		this.format = format;
		this.language = language;
	}

	public long getSurrogateKey() {
		return surrogateKey;
	}

	public void setSurrogateKey(long surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}
	
	
	
	
	
	
	
	//@ManyToOne
	//@JoinColumn(name="theatre_id", nullable = false)
	//private Theatre theatre; 
}
