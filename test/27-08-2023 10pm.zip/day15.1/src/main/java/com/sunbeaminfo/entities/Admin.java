package com.sunbeaminfo.entities;


import javax.persistence.*;


@Entity
@Table(name = "image_tbl") // to specify table name
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "image_id")
	private Long imageId;
	
	
	@Lob
	@Column(name = "image")
	private byte[] image;

	
	public Admin(Long imageId, byte[] image) {
		super();
		this.imageId = imageId;
		this.image = image;
	}

	public Admin() {
		super();
	}

	public Long getImageId() {
		return imageId;
	}

	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}
	
	 
	
	
	
	
	
}
