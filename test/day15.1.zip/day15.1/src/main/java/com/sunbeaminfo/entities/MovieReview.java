package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.type.TrueFalseType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_review_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class MovieReview {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_review_id", nullable = false, unique = true)
	private long  movieReviewId;
	
	
	@ManyToOne
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	
	@Column(name="review", nullable = false , unique = true)
	private String review;
	
	@Column(name="review_rating", nullable = false , unique = true)
	@Max(value = 5)
	@Min(value=0)
	private int reviewRating;
	
	

	
	@ManyToOne
	@JoinColumn(name="user_id", nullable = false)
	private User user;

	public MovieReview() {
		super();
	}

	public MovieReview(Movie movie, String review, @Max(5) @Min(0) int reviewRating, User user) {
		super();
		this.movie = movie;
		this.review = review;
		this.reviewRating = reviewRating;
		this.user = user;
	}

	public long getMovieReviewId() {
		return movieReviewId;
	}

	public void setMovieReviewId(long movieReviewId) {
		this.movieReviewId = movieReviewId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public int getReviewRating() {
		return reviewRating;
	}

	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
}
