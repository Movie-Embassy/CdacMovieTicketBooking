package com.sunbeaminfo.dto;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.sunbeaminfo.emuns.Category;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;

public class SeatDTO {
	
	private Long seatId;
	
	private int seatNumber;

	private Long screenId;
	
	private Category category;

	public SeatDTO() {
		super();
	}

	public SeatDTO(Long seatId, int seatNumber, Long screenId, Category category) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.screenId = screenId;
		this.category = category;
	}

	public SeatDTO(int seatNumber, Long screenId, Category category) {
		super();
		this.seatNumber = seatNumber;
		this.screenId = screenId;
		this.category = category;
	}

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Long getScreenId() {
		return screenId;
	}

	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	

}
