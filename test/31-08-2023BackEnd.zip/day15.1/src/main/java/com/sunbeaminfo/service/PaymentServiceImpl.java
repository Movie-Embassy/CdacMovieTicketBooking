package com.sunbeaminfo.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.PaymentDao;
import com.sunbeaminfo.dto.PaymentByUidBidDTO;
import com.sunbeaminfo.dto.PaymentDTO;
import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.entities.Payment;
import com.sunbeaminfo.entities.User;

@Service
@Transactional

public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentDao paymentDao;
	
	@Override
	public Payment getByUserId(Long id) {
		return paymentDao.getByUserId(id);
		
	}

	@Override
	public Payment getByUserIdAndBookingId(PaymentByUidBidDTO obj) {
	//	getByUserIdBookingId(Long uId,Long bId);
		return paymentDao.getByUserIdBookingId(obj.getUserId(),obj.getBookingId());
	
	}

	@Override
	public Payment addPayment(PaymentDTO pdto) {
		
		//public Payment(double paymentAmount, LocalDateTime paymentDateTime, User user, Booking booking)
		return paymentDao.save(new Payment(pdto.getPrice(),LocalDateTime.now(), new User(pdto.getUserId()), new Booking(pdto.getBookingId()) )) ;
		
	}

}
