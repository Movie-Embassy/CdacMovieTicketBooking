package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.TheatreDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class TheatreServiceImpl implements TheatreService {

	@Autowired
	private TheatreDao theatreDao;
	
	
	@Override
	public List<Theatre> getAllTheatres() {
		// TODO Auto-generated method stub
		return theatreDao.findAll();
	}


	@Override
	public Theatre addTheatre(Theatre t) {
		// TODO Auto-generated method stub
		return theatreDao.save(t);
	}

	@Override
	public Theatre getTheatre(Long id) {
		
		return null;
	}
	
	@Override
	public ApiResponse deleteTheatre(Long id) {
		theatreDao.deleteById(id);
		
		return new ApiResponse("Theatre is deleted");
	}
	
	@Override
	public Theatre addtheatreDetails(Theatre theatre) {
		
		return theatreDao.save(theatre);
	}

	@Override
	public Theatre getTheatreDetails(Long theatreId) {
		
		return theatreDao.findById(theatreId).orElseThrow(() -> new ResourceNotFoundException("theatre id invalid !!!!!"));
	}

	@Override
	public Screen addScreen(ScreenDto m) {
		Optional<Theatre> t = theatreDao.findById(m.getTheatreId());
		Theatre th = t.get();
		
//		th.screen.add(new Screen(m.getScreenNumber(), th));
		
		return new Screen(m.getScreenNumber(), th);
	}


	
}
