package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Show;



public interface ScreenService {
	
	List<ScreenDto> getAllScreens();
	
	Screen addScreen(ScreenDto m);
	
	Screen getScreen(Long id);

	ApiResponse deleteScreen(Long id);

	Screen getscreenDetails(Long screenId);

	Screen addscreenDetails(ScreenDto m);
	

 }
