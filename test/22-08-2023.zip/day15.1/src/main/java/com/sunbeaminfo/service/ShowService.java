package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ShowDTO;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.entities.User;



public interface ShowService {
	
	List<com.sunbeaminfo.entities.Show> getAllShows();
	
	Show addShow(ShowDTO m);
	
	Show getShow(Long id);

	ApiResponse deleteShow(Long id);
	
	List<Show> listAllShows();
}
