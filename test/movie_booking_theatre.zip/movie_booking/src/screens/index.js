import { BrowserRouter as Router, Route, Switch} from "react-router-dom"; // alias
import Home from '../Home'
import Details from "./Details";
import TheatreBooking from "./TheatreBooking";
import ProtectedRoute from "./protectedRoute";
import DoPayment from "./DoPayment";
import SeatBooking from "./SeatBooking";
import Success from "./Success";
// import Header from "./header";
// import Footer from "./Footer";
function Controller()
{
    return(
        <>
        {/* <Header/> */}
        <Router>
            <Switch>
            <Route path="/" exact component={Home}/>
            <Route path="/Details/:id" exact component={Details}/>
            
            <ProtectedRoute exact path="/TheatreBooking" component={TheatreBooking}/>
            <Route path="/SeatBooking" exact component={SeatBooking}/>
            <Route path="/DoPayment" exact component={DoPayment}/>
            <Route path="/internetBanking" exact component={DoPayment}/>
            <Route path="/CardPayment" exact component={DoPayment}/>
            <Route path="/UPI" exact component={DoPayment}/>
            <Route path="/wallets" exact component={DoPayment}/>
            <Route path="/Success" exact component={Success}/>


            </Switch>   
        </Router>
        {/* <Footer/> */}
        </>
    )
}
export default Controller;