package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sunbeaminfo.entities.MovieCast;





public interface MovieCastDao extends JpaRepository<MovieCast, Long> {

}
