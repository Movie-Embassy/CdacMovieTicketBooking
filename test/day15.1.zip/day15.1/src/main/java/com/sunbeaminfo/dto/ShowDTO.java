package com.sunbeaminfo.dto;


import java.time.LocalDateTime;

public class ShowDTO {
    private Long showId;
    private LocalDateTime showDateTime; // Change this to LocalDateTime
    private String screenName;
    private String movieTitle;

    // Constructors, getters, and setters

    public ShowDTO(Long showId, LocalDateTime showDateTime, String screenName, String movieTitle) {
        this.showId = showId;
        this.showDateTime = showDateTime;
        this.screenName = screenName;
        this.movieTitle = movieTitle;
    }

    // Getters and setters

    public Long getShowId() {
        return showId;
    }

    public void setShowId(Long showId) {
        this.showId = showId;
    }

    public LocalDateTime getShowDateTime() {
        return showDateTime;
    }

    public void setShowDateTime(LocalDateTime showDateTime) { // Change the parameter type here
        this.showDateTime = showDateTime;
    }

    public String getScreenName() {
        return screenName;
    }

    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }
}
