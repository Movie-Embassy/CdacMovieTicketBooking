// import React from "react"; // Don't forget to import React
// // import ShowListPage from "../../pages/showListPage/ShowListPage"
// import dayjs from "dayjs";
// function showContainer(props) {
//   return ( <>
//   <div  style={{width:120,height:45,backgroundColor:"darkblue",opacity:0.6,borderRadius:22.5,paddingTop:7,margin:10}}>
//             {console.log("props",props)}
        
          
//          <center style={{color:"white",fontSize:19 }}> {
//            dayjs(
//             props.show
//         ).format("MMM D, YYYY") 
//            } </center> 
//   </div>
//   </> );
// }
// export default showContainer;

import React from "react";
import dayjs from "dayjs";
import {  useNavigate } from "react-router-dom";

const containerStyle = {
  backgroundColor: "darkblue",
  color: "white",
  padding: "5px 10px",
  borderRadius: "5px",
  margin: "5px",
};

function ShowContainer(props) {

const navigate=useNavigate();


  return (
    <>
    {console.log(props.show.showId)}
    <div style={containerStyle}  onClick={()=>{navigate(`/seatbooking/${props.show.showId}`)}}>
      {dayjs(props.show.showDateTime).format("MMM D, YYYY")}
     
          </div>
</>
  );
}

export default ShowContainer;