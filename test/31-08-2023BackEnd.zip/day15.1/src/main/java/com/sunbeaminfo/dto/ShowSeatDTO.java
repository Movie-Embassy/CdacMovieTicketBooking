package com.sunbeaminfo.dto;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.enums.Category;
import com.sunbeaminfo.enums.Status;

public class ShowSeatDTO {

	
	private Long seatId;
	
	private Long seatNumber;
	
	private Long showId;

	private Category category;
	
	private Status status;

	public ShowSeatDTO(Long seatId, Long seatNumber, Long showId, Category category, Status status) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.showId = showId;
		this.category = category;
		this.status = status;
	}

	public ShowSeatDTO() {
		super();
	}

	public ShowSeatDTO(Long seatNumber, Long showId, Category category, Status status) {
		super();
		this.seatNumber = seatNumber;
		this.showId = showId;
		this.category = category;
		this.status = status;
	}

	public ShowSeatDTO(Long seatId) {
		super();
		this.seatId = seatId;
	}

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public Long getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(Long seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	
	
	
	
}
