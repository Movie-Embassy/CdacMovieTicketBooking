import {Route} from "react-router-dom";
import Login from "./Login";
function ProtectedRoute(props)
{
    var isLoggedin=false;
    var isUserLoggedIn=window.sessionStorage.getItem("isLoggedIn");
    if(isUserLoggedIn !=null && isUserLoggedIn =='true')
    {
        isLoggedin= true;
        // return <Route exact path={props.path} component={props.component}/>
    }
    else
    {
         isLoggedin = false;
        // return <Login></Login>
    }


    if(isLoggedin)
    {
        // var isLoggedin = true;
        return <Route exact path={props.path} component={props.component}/>
    }
    else
    {
        // var isLoggedin = false;
        return <Login></Login>
    }

}
export default ProtectedRoute;