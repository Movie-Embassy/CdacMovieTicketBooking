package com.sunbeaminfo.dto;

import java.time.LocalDate;




public class AuthResp {	
	private Long id;
	private String firstName;	
	private String lastName;		
	private LocalDate joinDate;
	private double salary;	
	private String location;	
	private String department;
	
	public AuthResp() {
		super();
	}

	public AuthResp(Long id, String firstName, String lastName, LocalDate joinDate, double salary, String location,
			String department) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.joinDate = joinDate;
		this.salary = salary;
		this.location = location;
		this.department = department;
	}

	public AuthResp(String firstName, String lastName, LocalDate joinDate, double salary, String location,
			String department) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.joinDate = joinDate;
		this.salary = salary;
		this.location = location;
		this.department = department;
	}

	public AuthResp(Long id) {
		super();
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}	
	
	
	
	
	
}
