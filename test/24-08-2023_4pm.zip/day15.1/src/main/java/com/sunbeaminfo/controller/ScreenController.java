package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.service.ScreenService;
import com.sunbeaminfo.service.TheatreService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/Screen")
@CrossOrigin(origins = "*")
public class ScreenController {

	@Autowired
	private ScreenService screenService;
	@Autowired
	private TheatreService theatreService;
	
	
	public ScreenController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<ScreenDto> listAllScreens(){
		return screenService.getAllScreens();
	}
	
	@PostMapping
	public Screen saveScreenDetails(@RequestBody ScreenDto m) {
		return screenService.addScreen(m);
	}
	
	@DeleteMapping
	public ApiResponse deleteScreen(@RequestParam Long id) {
		return screenService.deleteScreen(id);
	}
	
	
	@PutMapping
	public  Screen updatescreenInfo(@RequestBody ScreenDto m) {
		screenService.getscreenDetails(m.getScreenId());
		
		return screenService.addscreenDetails(m);
	}

}
