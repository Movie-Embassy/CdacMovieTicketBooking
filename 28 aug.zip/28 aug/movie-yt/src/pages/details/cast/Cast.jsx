import React from "react";
import { useSelector } from "react-redux";

import "./style.scss";

import ContentWrapper from "../../../components/contentWrapper/ContentWrapper";
import Img from "../../../components/lazyLoadImage/img.jsx";
import avatar from "../../../assets/avatar.png";
import { useNavigate } from "react-router-dom";

const imageprofile = "/media/harsh/A88289188288EBDE/WEBtechnologieslab/movie-yt/src/assets/avatar.png";

const Cast = ({ data, loading }) => {
    const { url } = useSelector((state) => state.home);
    const Navigate = useNavigate();

    const skeleton = () => {
        return (
            <div className="skItem">
                <div className="circle skeleton"></div>
                <div className="row skeleton"></div>
                <div className="row2 skeleton"></div>
            </div>
        );
    };

    return (
        <div className="castSection">
            <ContentWrapper>
                <div className="sectionHeading">Top Cast</div>
                {!loading ? (
                    <div className="listItems">
                        {data?.map((item, index) => (
                            <div key={index} className="listItem">
                                {item.castImg ? (
                                    <div className="profileImg">
                                        <img src={`data:image/jpeg;base64,${item.castImg}`} alt={item.cast} />
                                    </div>
                                ) : (
                                    <div className="profileImg">
                                        <img src={imageprofile} alt="Default Avatar" />
                                    </div>
                                )}
                                <div className="name">{item.cast}</div>
                                <div className="character">{item.cast}</div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="castSkeleton">
                        {skeleton()}
                        {skeleton()}
                        {skeleton()}
                        {skeleton()}
                        {skeleton()}
                        {skeleton()}
                    </div>
                )}
            </ContentWrapper>
        </div>
    );
};

export default Cast;
