package com.sunbeaminfo.dto;

public class PaymentByUidBidDTO {

	private Long userId ;
	
	private Long bookingId ;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public PaymentByUidBidDTO(Long userId, Long bookingId) {
		super();
		this.userId = userId;
		this.bookingId = bookingId;
	}
	
	
}
