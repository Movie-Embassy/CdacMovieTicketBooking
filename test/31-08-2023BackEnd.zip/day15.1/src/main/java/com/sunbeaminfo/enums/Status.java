package com.sunbeaminfo.enums;

public enum Status {

	BOOKED,AVAILABLE,BLOCKED
}
