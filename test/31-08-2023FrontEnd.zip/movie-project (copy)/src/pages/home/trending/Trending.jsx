// import React,{useEffect, useState} from 'react'
// import ContentWrapper from '../../../components/contentWrapper/ContentWrapper'
// import "../style.scss"
// import axios from 'axios'

// import SwitchTabs from '../../../components/switchTabs/SwitchTabs'
// import useFetch from '../../../hooks/useFetch'
// import Carousel from '../../../components/Carousel/Carousel'
// import movieData from "../../../movies.json"

// const Trending = () => {
//   // const [endPoint,setEndPoint]=useState("day");
//   const [imageData, setImageData] = useState([]);
  
//   const id=1;
//   useEffect(()=>
//   {
//     const url=`http://localhost:7070/images/all`
//     const type={responseType:'arraybuffer'};
//     // try
//     // {
//     //   const response=axios.get(url,type)
//     //   const blob=new Blob([response.data],{type:'image/jpeg'});
//     //   const imageUrl=URL.createObjectURL(blob);
//     //   setImageData(imageUrl);
  //     //   console.log("repsonse:",response);
  //     //   console.log("repsonse data:",response.data);
//     // }catch(ex)
//     // {
//     //   console.log(ex);
//     // }


//     const response=axios.get(url,{responseType:'arraybuffer'})
//     .then(response=>{
//       console.log(response);
//       const blob=new Blob([response.data],{type:'image/jpeg'});

//       const imageUrl=URL.createObjectURL(blob);
//       setImageData(imageUrl);

//     })
//     .catch(error => {
//       console.error('Error fetching image:', error);
//     });
//   },[]);

//   // const {data,loading}=useFetch(`/trending/movie/${endPoint}`);
//   const data=imageData; 
//   console.log("data", data)
//   const onTabChange=(tab)=>
//   {
//     setEndPoint(tab==="Day"?"day":"week")
//   }

//   return (
//     <div className='carouselSection'>
//       <ContentWrapper>
//          <span className="carouselTitle">Trending</span>
//          <SwitchTabs data={["Day","Week"]} onTabChange={onTabChange}></SwitchTabs>  
//           {/* change this to hindi and english movie !> */}
//       </ContentWrapper>
//     <Carousel data={data} loading={false} />
      
//     </div>
//   )
// }

// export default Trending



{/*THIS IS THE CODE WHICH IS WORKING TILL TODAY'S NIGHT   */}


// import React,{useState} from 'react'
// import ContentWrapper from '../../../components/contentWrapper/ContentWrapper'
// import "../style.scss"

// import SwitchTabs from '../../../components/switchTabs/SwitchTabs'
// import useFetch from '../../../hooks/useFetch'
// import Carousel from '../../../components/Carousel/Carousel'
// import movieData from "../../../movies.json"

// const Trending = () => {
//   const [endPoint,setEndPoint]=useState("day");
  
//   const {data,loading}=useFetch(`/trending/movie/${endPoint}`);
//   // const data=movieData; 
//   const onTabChange=(tab)=>
//   {
//     setEndPoint(tab==="Day"?"day":"week")
//   }

//   return (
//     <div className='carouselSection'>
//       <ContentWrapper>
//          <span className="carouselTitle">Trending</span>
//          <SwitchTabs data={["Day","Week"]} onTabChange={onTabChange}></SwitchTabs>  
//           {/* change this to hindi and english movie !> */}
//       </ContentWrapper>
//     <Carousel data={data?.results} loading={false} />
      
//     </div>
//   )
// }

// export default Trending

{/*THIS IS THE CODE WHICH IS WORKING TILL TODAY'S NIGHT   */}





{/*AFTER THIS IT IS TO ET SINGLE IMAGE   */}

// import React, { useEffect, useState } from 'react';
// import ContentWrapper from '../../../components/contentWrapper/ContentWrapper';
// import "../style.scss";
// import axios from 'axios';
// import SwitchTabs from '../../../components/switchTabs/SwitchTabs';
// import Carousel from '../../../components/Carousel/Carousel';
// import movieData from "../../../movies.json";

// const Trending = () => {
//   const [imageData, setImageData] = useState([]);
//   // const id = 1;
//   var imageArray = [];
//   useEffect(() => {
//   for(var id = 1; id <= 5; id++)
//   {
//     const url = `http://localhost:7070/images/${id}`;
//     const config = { responseType: 'arraybuffer' };

//     axios.get(url, config)
//       .then(response => {
//         console.log("response:", response);
//         console.log("response data:", response.data);

//         const blob = new Blob([response.data], { type: 'image/jpeg' });
//         const imageUrl = URL.createObjectURL(blob);
//         setImageData(imageUrl);
//         // imageArray[id-1] = imageUrl;
//       })
//       .catch(ex => {
//         console.log(ex);
//       });
//   }
    


//   }, []); // You don't need [imageData] as a dependency here

//   // const data = imageData;
//   var data = [...imageData];

//   // var data =imageArray;
//   // console.log("data", data);

//   // Rest of your component code...

//   return (
//     <div className='carouselSection'>
//       {/* ... */}
//       <ContentWrapper>
//          <span className="carouselTitle">Trending</span>
//          {/* <SwitchTabs data={["Day","Week"]} onTabChange={onTabChange}></SwitchTabs>   */}
//           {/* change this to hindi and english movie !> */}
//       </ContentWrapper>
//     <Carousel data={data} loading={false} />
//     </div>
//   );
// }

// export default Trending;


{/*This is ur code which was running but overriding single image  */}


import React, { useEffect, useState } from 'react';
import ContentWrapper from '../../../components/contentWrapper/ContentWrapper';
import "../style.scss";
import axios from 'axios';
import SwitchTabs from '../../../components/switchTabs/SwitchTabs';
import Carousel from '../../../components/Carousel/Carousel';
import movieData from "../../../movies.json";

const Trending = () => {
  const [imageData, setImageData] = useState([]);
  
  useEffect(() => {
    const fetchImages = async () => {
      const imageArray = [];

      for (let id = 1; id <= 5; id++) {
        const url = `http://localhost:7070/images/${id}`;
        const config = { responseType: 'arraybuffer' };

        try {
          const response = await axios.get(url, config);
          const blob = new Blob([response.data], { type: 'image/jpeg' });
          const imageUrl = URL.createObjectURL(blob);
          imageArray.push(imageUrl);
        } catch (ex) {
          console.log(ex);
        }
      }

      setImageData(imageArray);
    };

    fetchImages();
  }, []);

  return (
    <div className='carouselSection'>
      <ContentWrapper>
         <span className="carouselTitle">Trending</span>
      </ContentWrapper>
      <Carousel data={imageData} loading={false} />
    </div>
  );
}

export default Trending;
