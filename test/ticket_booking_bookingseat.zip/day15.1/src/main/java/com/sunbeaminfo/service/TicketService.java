package com.sunbeaminfo.service;

import java.util.List;

import com.sunbeaminfo.entities.Ticket;

public interface TicketService {

	List<Ticket> getAllTickets ();
	
	Ticket getTicketsById (Long ticketId);
	
	List<Ticket> getAllTicketsByUser (Long userId);
	
	Ticket getTicketByUserForShow (Long userId,Long showId );
}
