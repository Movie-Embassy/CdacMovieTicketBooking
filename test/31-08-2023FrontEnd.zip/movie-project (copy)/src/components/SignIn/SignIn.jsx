import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Form, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
// import { registerUser as registerUserApi } from "./services/user";
// import validation from "./services/validation";
import "./SignIn.css"
import { toast } from 'react-toastify'
//import { registerUser as registerUserApi } from '../services/user'
<link rel="stylesheet" href="./SignIn.css" />
// import user from "./user"

function SignIn() {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [userEmail, setUserEmail] = useState('')
  const [contactNo, setContactNo] = useState('')
  const [userAge, setUserAge] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  

  const navigate=useNavigate();

  const registerUser = async () => {
    
    if(password !== confirmPassword) {
      toast.error('Password does not match')
    }
     else {
      // call register api
      const response = await registerUserApi(
        firstName,
        lastName,
        password,
        userEmail,
        contactNo,
        userAge,
      )

      // parse the response
      // if (response.data.firstName === 'firstName' && response.data.password == password)
      if (response['status'] == 200) 
        {

          toast.success('User registration successful')
          
          // go back to login
          navigate('/')
      } else {
        toast.error('Error while registering a new user, please try again')
      }
    }
  }

  return (
    <Container className="signup-container">
     
      <div className="signup-box" style={{ width: "450px" }} >

        <h2>Register New User</h2>

       <form >
        <label>First Name</label>
        <input type="text" className="form-control" id="fname" required onChange={(e) => {
                  setFirstName(e.target.value)
                }}/>
        
        <label>Last Name</label>
        <input type="text" className="form-control" id="lname" required onChange={(e) => {
                  setLastName(e.target.value)
                }}/>

        <label>Phone Number</label>
        <input type="text" className="form-control" id="phn" required minLength={"10"} maxLength={"13"} onChange={(e) => {
                  setContactNo(e.target.value)
                }}/>

        <label>Email</label>
        <input type="email" className="form-control" id="email" required onChange={(e) => {
                  setUserEmail(e.target.value)
                }}/>

        <label>Age</label>
        <input type="number" className="form-control" id="age" required min={"18"} onChange={(e) => {
                  setUserAge(e.target.value)
                }}/>

        <label>Password</label>
        <input type="password" className="form-control" id="pwd" required  onChange={(e) => {
                  setPassword(e.target.value)
                }}/>

        <label>Confirm Password</label>
        <input type="password" className="form-control" id="conpwd" required onChange={(e) => {
                  setConfirmPassword(e.target.value)
                }}/>
        <br/>
        <center><input type="submit" className="btn btn-primary form-control" value="Register" id="btn" onClick={registerUser}/></center>
        </form>


       
        <p className="already-have-account">
          {/* Already have an account? <Link to="/signin">Log in</Link> */}
        </p>
      </div>
      
    </Container>
  );
}

export default SignIn;