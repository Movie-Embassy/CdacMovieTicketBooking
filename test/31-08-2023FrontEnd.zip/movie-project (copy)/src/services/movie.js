import axios from 'axios'
import { createUrl, log } from '../utils copy/utils'

export async function addMovie(
  movieName,
  releaseDate,
  runTime,
  description,
  movieTile,
  movieBgImage,
  trailerUrl,
  certificate
) {
  // debugger
  // const url = createUrl('/user/register')
  const url = createUrl('/movie/add')
  const body = {
  movieName,
  releaseDate,
  runTime,
  description,
  movieTile,
  movieBgImage,
  trailerUrl,
  certificate
  }
  
  try {
    const response = await axios.post(url, body)
    log(response)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}


export async function getMovieList() {
  // debugger
  const url = createUrl('/movie/movies')

  try {
   
    const response = await axios.get(url)
    console.log( "response-------" , response.data)
    return response.data
  } catch (ex) {
    log(ex)
    return null
  }
}
 
export async function deleteMovie(
  movieId,
  movieName,
  releaseDate,
  runTime,
  description,
  movieTile,
  movieBgImage,
  trailerUrl,
  certificate
)
 {
  const url = createUrl('/movie/delete')
  const body = {
    movieId,
    movieName,
    releaseDate,
    runTime,
    description,
    movieTile,
    movieBgImage,
    trailerUrl,
    certificate
  }
  // const url = createUrl(`/user/delete/${id}`)
  console.log(url)
  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.put(url, body)
    log(response)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}


export async function updateMovieApi(
  movieId,
  movieName,
  releaseDate,
  runTime,
  description,
  movieTile,
  movieBgImage,
  trailerUrl,
  certificate
) {
  // debugger
  // const url = createUrl('/user/register')
  const url = createUrl('/movie/update')
  const body = {
    movieId,
    movieName,
    releaseDate,
    runTime,
    description,
    movieTile,
    movieBgImage,
    trailerUrl,
    certificate
  }

  // wait till axios is making the api call and getting response from server
  try {
    const response = await axios.put(url, body)
    log(response)
    return response
  } catch (ex) {
    log(ex)
    return null
  }
}
