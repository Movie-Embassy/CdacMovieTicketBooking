package com.sunbeaminfo.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sunbeaminfo.enums.Status;


@Entity
@Table(name="book_seat_tbl")  // Define the table name in the database
public class BookingSeat {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	// Generate unique IDs for booking seats
	@Column(name = "booking_seat_id")
	private Long bookingSeatId;
	

    // Many-to-One relationship with Booking entity
	@ManyToOne
	@JoinColumn(name = "booking_id")  	// Foreign key column in book_seat_tbl referencing booking_id in Booking table
	private Booking booking;
	

    // One-to-One relationship with Seat entity
	@OneToOne
	@JoinColumn(name = "seat_id") // Foreign key column in book_seat_tbl referencing seat_id in Seat table
	private Seat seat;
	

    // Enumerated status column indicating seat status
	@Enumerated(EnumType.STRING)
	@Column(name = "status")
	private Status status;

	
    // Constructor with all fields
    public BookingSeat(Long bookingSeatId, Booking booking, Seat seat, Status status) {
        super();
        this.bookingSeatId = bookingSeatId;
        this.booking = booking;
        this.seat = seat;
        this.status = status;
    }

    // Constructor without bookingSeatId
    public BookingSeat(Booking booking, Seat seat, Status status) {
        super();
        this.booking = booking;
        this.seat = seat;
        this.status = status;
    }

    // Constructor with only bookingSeatId
    public BookingSeat(Long bookingSeatId) {
        super();
        this.bookingSeatId = bookingSeatId;
    }
    
    public BookingSeat(Booking booking, Seat seat) {
		super();
		this.booking = booking;
		this.seat = seat;
	}
    

    
    
	public Long getBookingSeatId() {
		return bookingSeatId;
	}

	public void setBookingSeatId(Long bookingSeatId) {
		this.bookingSeatId = bookingSeatId;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
    
    
	
	
	
	
}
