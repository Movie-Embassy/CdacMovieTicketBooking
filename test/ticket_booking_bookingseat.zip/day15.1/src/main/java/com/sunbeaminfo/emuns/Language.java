package com.sunbeaminfo.emuns;

public enum Language {
ENGLISH,HINDI,MARATHI,TELUGU,TAMIL,KANNADA
}
