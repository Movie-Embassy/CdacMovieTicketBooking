package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.emuns.Genre;

@Entity
@Table(name="movie_genre_tbl")	// Define the table name in the database
public class MovieGenre {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	// Generate unique IDs for movie genres
	@Column(name="movie_genre_id", nullable = false, unique = true)
	private long  movieGenreId;
	
	 // Many-to-One relationship with Movie entity (lazy fetch to avoid unnecessary loading)
	 /*
	  * In Bidirectional Relationship to avoid in loop referencing add @JsonIgnore annotation
	  */
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	

    // Enumerated genre column indicating movie genre
	@Enumerated(EnumType.STRING)
	@Column(name="genre", nullable = false , unique = true)
	private Genre genre;


	
	
	
    public MovieGenre(long movieGenreId) {
		super();
		this.movieGenreId = movieGenreId;
	}

	public MovieGenre(Movie movie, Genre genre) {
		super();
		this.movie = movie;
		this.genre = genre;
	}

	public MovieGenre(long movieGenreId, Movie movie, Genre genre) {
		super();
		this.movieGenreId = movieGenreId;
		this.movie = movie;
		this.genre = genre;
	}

	public MovieGenre() {
		super();
	}

	// Getters and Setters for all fields
	public long getMovieGenreId() {
		return movieGenreId;
	}

	public void setMovieGenreId(long movieGenreId) {
		this.movieGenreId = movieGenreId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}

	
	
	// Additional methods like hashCode, equals, etc. have been provided
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieGenreId ^ (movieGenreId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieGenre other = (MovieGenre) obj;
		if (movieGenreId != other.movieGenreId)
			return false;
		return true;
	}

	
	
	
	
	
	
	
	
}
