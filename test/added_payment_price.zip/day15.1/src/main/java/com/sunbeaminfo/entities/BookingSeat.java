package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sunbeaminfo.emuns.Status;

import net.bytebuddy.utility.nullability.MaybeNull;

@Entity
@Table(name="book_seat_tbl")
public class BookingSeat {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_seat_id")
	private Long bookingSeatId;
	
	@ManyToOne
	@JoinColumn(name = "booking_id")
	private Booking booking;
	
	@OneToOne
	@JoinColumn(name = "seat_id")
	private Seat seat;
	
	@Enumerated
	//@Column(name = "status")
	@Column(name = "status" , columnDefinition = "varchar(25) default 'BlOCKED'" )
	private Status status;

	

	public BookingSeat(Long bookingSeatId, Booking booking, Seat seat, Status status) {
		super();
		this.bookingSeatId = bookingSeatId;
		this.booking = booking;
		this.seat = seat;
		this.status = status;
	}



	public BookingSeat(Booking booking, Seat seat) {
		super();
		this.booking = booking;
		this.seat = seat;
	}


	



	
	
	
	
	
}
