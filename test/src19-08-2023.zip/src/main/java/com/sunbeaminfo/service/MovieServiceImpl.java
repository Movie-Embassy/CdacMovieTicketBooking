package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.MovieDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDao movieDao;
	
	
	
	@Override
	public List<Movie> getAllMovies() {
		System.out.println("11111111");
		return movieDao.findAll();
	}

	@Override
	public Movie addMovie(Movie m) {
		// TODO Auto-generated method stub
		return movieDao.save(m);
	}

	@Override
	public Movie getMovie(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteMovie(Long id) {
		movieDao.deleteById(id);
		
		return new ApiResponse("Movie is deleted");
	}
	
}
