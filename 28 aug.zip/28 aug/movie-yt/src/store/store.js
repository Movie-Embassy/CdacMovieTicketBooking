import { configureStore } from '@reduxjs/toolkit'
import homeSlice from './homeslice'
import seatSlice from './seatSlice'


export const store = configureStore({
  reducer: {
    home:homeSlice,
    seat:seatSlice
  },
})  