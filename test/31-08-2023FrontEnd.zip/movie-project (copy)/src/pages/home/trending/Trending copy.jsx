import React,{useState} from 'react'
import ContentWrapper from '../../../components/contentWrapper/ContentWrapper'
import "../style.scss"

import SwitchTabs from '../../../components/switchTabs/SwitchTabs'
import useFetch from '../../../hooks/useFetch'
import Carousel from '../../../components/Carousel/Carousel'
import movieData from "../../../movies.json"

const Trending = () => {
  const [endPoint,setEndPoint]=useState("day");

  // const {data,loading}=useFetch(`/trending/movie/${endPoint}`);
  const data=movieData; 
  const onTabChange=(tab)=>
  {
    setEndPoint(tab==="Day"?"day":"week")
  }

  return (
    <div className='carouselSection'>
      <ContentWrapper>
         <span className="carouselTitle">Trending</span>
         <SwitchTabs data={["Day","Week"]} onTabChange={onTabChange}></SwitchTabs>  
          {/* change this to hindi and english movie !> */}
      </ContentWrapper>
    <Carousel data={data?.results} loading={false} />
      
    </div>
  )
}

export default Trending
