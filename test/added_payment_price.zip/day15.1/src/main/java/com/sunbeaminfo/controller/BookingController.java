package com.sunbeaminfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.BookingDTO;
import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.service.BookingService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/Booking")
public class BookingController {

	
	
	public BookingController() {
		
	}

	@Autowired
	private BookingService bookingService;
	
	@GetMapping
	public List<Booking> getAllBookings()
	{
	return bookingService.getAllBookings();
	}
	
	@GetMapping("/id")
	public Booking getAllBookingById(@RequestParam Long id)
	{
	return bookingService.getBookingById(id);
	}
	
	@DeleteMapping
	public ApiResponse deleteBookingById(@RequestParam Long id)
	{
	return bookingService.deleteById(id);
	}
	
	@PostMapping
	public Booking addBooking(@RequestBody BookingDTO bk)
	{
	return bookingService.addBooking(bk);
	}
	
	
	
	
	
}
