package com.sunbeaminfo.service;

import java.util.ArrayList;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.ShowDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ShowDTO;
import com.sunbeaminfo.dto.ShowListDTO;
import com.sunbeaminfo.entities.*;


@Transactional
@Service
public class ShowServiceImpl implements ShowService {

	@Autowired
	private ShowDao ShowDao;
	
	
	
	@Override
	public List<Show> getAllShows() {
		return ShowDao.findAll();
	}

	@Override
	public Show addShow(ShowDTO m) {		
		Show s= new Show(m.getShowDateTime(), new Theatre(m.getTheatreId()), new Movie(m.getMovieId()), new MovieDetails(m.getMovieDetailsId()));
		
		return ShowDao.save(s);
	}

	

	
	@Override
	public ApiResponse deleteShow(Long id) {
		ShowDao.deleteById(id);
		
		return new ApiResponse("Show is deleted");
	}


	@Override
	public List<Show> listAllShows() {

		return ShowDao.findAll();
	}

	
	
	@Override
	public List<ShowListDTO> movieShowList(Long movieId) {
		List<ShowListDTO> showList = new ArrayList<ShowListDTO>();
		
		for(Show s :ShowDao.movieShowList(movieId)) {
			ShowListDTO showListDto = new ShowListDTO();
				
			showListDto.setShowId(s.getShowId());
			showListDto.setShowDateTime(s.getShowDateTime());
			showListDto.setTheatreId(s.getTheatre().getTheaterId());
			showListDto.setTheatreName(s.getTheatre().getTheaterName());
			showListDto.setTheatreArea(s.getTheatre().getTheaterArea());
			showListDto.setMovieDetailsId(s.getMovieDetails().getmovieDetailsId());
			showListDto.setFormat(s.getMovieDetails().getFormat());
			showListDto.setLanguage(s.getMovieDetails().getLanguage());
			
			showList.add(showListDto);
			
		}
		
		return showList;
	}
	
}
