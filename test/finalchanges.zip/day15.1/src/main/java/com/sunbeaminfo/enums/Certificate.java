package com.sunbeaminfo.enums;

public enum Certificate {
U,UA,A
}
