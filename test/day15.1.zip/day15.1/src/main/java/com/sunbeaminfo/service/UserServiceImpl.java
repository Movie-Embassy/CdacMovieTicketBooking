package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	
	
	@Override
	public List<User> getAllUsers() {
		System.out.println("11111111");
		return userDao.findAll();
	}

	@Override
	public User addUser(User u) {
		// TODO Auto-generated method stub
		return userDao.save(u);
	}

	@Override
	public User getUser(Long id) {
		
		return null;
	}

	@Override
	public Optional<User> findByEmailandPassword(String e, String p) {
		
		return userDao.findByUserEmailAndPassword(e, p);
	}

	@Override
	public ApiResponse deleteUser(Long id) {
		userDao.deleteById(id);
		
		return new ApiResponse("User is deleted");
	}
	
	

}
