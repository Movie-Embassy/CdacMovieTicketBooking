package com.sunbeaminfo.entities;

public enum Genre {
COMEDY,ACTION,SUSPENSE,THRILLER,HORROR,ADULT,ADULT_COMEDY,DRAMA
}
