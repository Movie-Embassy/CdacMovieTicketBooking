package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="screen_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Screen {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="screen_id", nullable = false, unique = true)
	private Long screenId;
	
	@Column(name="screen_number" , nullable = false)
	private int screenNumber;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="theatre_id", nullable = false)
	private Theatre theatre;
	
	
	
	
	
	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public Screen() {
	super();
}

	public Screen(int screenNumber, Theatre theatre) {
		super();
		this.screenNumber = screenNumber;
		this.theatre = theatre;
	}
	
	

	public void setScreenNumber(int screenNumber) {
		this.screenNumber = screenNumber;
	}

	public Long getScreenId() {
		return screenId;
	}

	public int getScreenNumber() {
		return screenNumber;
	}

	public Theatre getTheatre() {
		return theatre;
	}
	

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((screenId == null) ? 0 : screenId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Screen other = (Screen) obj;
		if (screenId == null) {
			if (other.screenId != null)
				return false;
		} else if (!screenId.equals(other.screenId))
			return false;
		return true;
	}

	public Screen(Long screenId, int screenNumber, Theatre theatre) {
		super();
		this.screenId = screenId;
		this.screenNumber = screenNumber;
		this.theatre = theatre;
	} 
	
	
	
	
}
