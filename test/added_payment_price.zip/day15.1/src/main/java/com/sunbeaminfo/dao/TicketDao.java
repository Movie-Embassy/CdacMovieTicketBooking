package com.sunbeaminfo.dao;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.entities.Ticket;
import com.sunbeaminfo.entities.User;

public interface TicketDao extends JpaRepository<Ticket, Long> {

//	@Query("select new com.sunbeaminfo.entities.Ticket(userId) from Ticket t where t.userId =?1")
//	List<Ticket> findByUser(Long userId);
	
	@Query(value="select * from ticket_tbl where user_id =?1;",nativeQuery = true)
	List<Ticket> findByUser(Long userId);
	
	
	@Query(value="select * from ticket_tbl where user_id=:userId and show_id=:showId);", nativeQuery = true)
	Ticket findByUserIdShow(Long userId,Long showId);
	
}
