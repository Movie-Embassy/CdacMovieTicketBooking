package com.sunbeaminfo.entities;

public enum Certificate {
U,UA,A
}
