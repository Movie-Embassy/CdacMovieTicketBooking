const container=document.querySelector('.container')
const showcase=document.querySelector('.showcase')
const seats=document.querySelectorAll('.row .seats:not(.occupied')
const count=document.getElementById('count')
const total=document.getElementById('total')
const movieselect=document.getElementById('movie');

let ticketprice=+movieselect.value;
console.log(ticketprice);

function updatecount()
{

    const selectedseats=document.querySelectorAll('.row .selected')

        const totalseats=selectedseats.length;
        console.log(totalseats);

    count.innerText=totalseats;
    total.innerText=totalseats*ticketprice;    

}


container.addEventListener('click',(e)=>
{
    if(e.target.classList.contains('seat')&&!e.target.classList.contains('.occupied'))
    {
        e.target.classList.toggle('selected')
    }
    updatecount();
})



total=ticketprice*count;
