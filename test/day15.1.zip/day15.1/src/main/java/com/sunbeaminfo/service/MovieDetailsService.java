package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.MovieDetails;



public interface MovieDetailsService {
	
	List<MovieDetails> getAllMovieDetailss();
	
	MovieDetails addMovieDetails(MovieDetails m);
	
	MovieDetails getMovieDetails(Long id);

	ApiResponse deleteMovieDetails(Long id);
	
	List<Long> movieSpecificDetails(Long movieId);
	
//	MovieDetails addMovieDetails(String format, String lang, Long id);
}
