package com.sunbeaminfo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.emuns.Category;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Seat;

public interface SeatDao extends JpaRepository<Seat, Long> {

//	@Query("select new com.sunbeaminfo.entities.Seat(seatId,seatNumber,screen,category) from Seat s where s.screen.screenId=?1 ")
	@Query("select s from Seat s where s.screen.screenId=:id")
	List<Seat> allSeatsOfScreen(Long id);
}
