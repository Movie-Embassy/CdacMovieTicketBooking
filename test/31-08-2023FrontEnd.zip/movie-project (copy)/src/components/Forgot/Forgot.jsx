import React from 'react';
import './Forgot.css'
const Forgot = () => {
  return (
    <>
      <div className="containers">
        <div className={param.success ? 'success-container' : 'error-container'}>
          <div className="alert alert-info text-white">
            {param.success
              ? 'Email sent to you to Reset Password. Please check Spam folder if mail not visible!'
              : 'Token Expired. Please click on Forgot Password again.'}
          </div>
        </div>
        <h2>Forgot Password</h2>
        <form action="/forgotPassword" method="post">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" required />
          </div>
          <button type="submit" className="btn-submit">
            Submit
          </button>
        </form>
      </div>
    </>
  );
};

export default Forgot;