package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.Password;
import com.sunbeaminfo.entities.User;
import com.sunbeaminfo.service.UserService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;
	
	
	public UserController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping
	public List<User> listAllUsers(){
		
		return userService.getAllUsers();
	}
	
	@PostMapping
	public User saveUserDetails(@RequestBody User u) {
		return userService.addUser(u);
	}
	
	
	@PostMapping("/login")
	public Optional<User> logIn(@RequestBody Password password)
	{
		return userService.findByEmailandPassword(password.getEmail(), password.getPassword());
	}
	
	@DeleteMapping
	public ApiResponse deleteUser(@RequestParam Long id) {
		return userService.deleteUser(id);
	}
	
	@PutMapping
	public  User updateUserInfo(@RequestBody User u) {
		userService.getuserDetails(u.getId());
		
		return userService.adduserDetails(u);
	}
}
