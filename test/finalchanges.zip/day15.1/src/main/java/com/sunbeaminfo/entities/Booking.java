package com.sunbeaminfo.entities;



import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "booking_tbl")	// Define the table name in the database
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	 // Generate unique IDs for bookings and auto increment
	@Column(name = "booking_id")
	private Long BookingId;
	
	// Many-to-One relationship with User entity
	@ManyToOne
	@JoinColumn(name = "user_id")	// Foreign key column in booking_tbl referencing user_id in User table
	private User user;
	
	// Many-to-One relationship with Show entity
	@ManyToOne
	@JoinColumn(name = "show_id")	 // Foreign key column in booking_tbl referencing show_id in Show table
	private Show show;
	

    // One-to-One relationship with Ticket entity
	@OneToOne
	@JoinColumn(name = "ticket_id")	// Foreign key column in booking_tbl referencing ticket_id in Ticket table
	private Ticket ticket;
	
	@Column(name = "transaction_start_time_id")
	private LocalDateTime transactionStratTime;

	
	
	@OneToMany(mappedBy = "booking", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private Set<BookingSeat> bookingSeat = new HashSet<BookingSeat>();
	
	
	
	public Set<BookingSeat> getBookingSeat() {
		return bookingSeat;
	}

	public void setBookingSeat(Set<BookingSeat> bookingSeat) {
		this.bookingSeat = bookingSeat;
	}

	
	
	
	
	// Default constructor
	public Booking() {
		super();
	}

    // Constructor with all fields
	public Booking(Long bookingId, User user, Show show, Ticket ticket, LocalDateTime transactionStratTime) {
		super();
		BookingId = bookingId;
		this.user = user;
		this.show = show;
		this.ticket = ticket;
		this.transactionStratTime = transactionStratTime;
	}

    // Constructor without bookingId
	public Booking(User user, Show show, Ticket ticket, LocalDateTime transactionStratTime) {
		super();
		this.user = user;
		this.show = show;
		this.ticket = ticket;
		this.transactionStratTime = transactionStratTime;
	}

	

    // Constructor without ticket
	public Booking(User user, Show show, LocalDateTime transactionStratTime) {
		super();
		this.user = user;
		this.show = show;
		this.transactionStratTime = transactionStratTime;
	}


    // Constructor with only bookingId
	public Booking(Long bookingId) {
		super();
		BookingId = bookingId;
	}

	

    // Getters and Setters for all fields
	public Long getBookingId() {
		return BookingId;
	}

	public void setBookingId(Long bookingId) {
		BookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public LocalDateTime getTransactionStratTime() {
		return transactionStratTime;
	}

	public void setTransactionStratTime(LocalDateTime transactionStratTime) {
		this.transactionStratTime = transactionStratTime;
	}
	
	
	
	
	
	
}
