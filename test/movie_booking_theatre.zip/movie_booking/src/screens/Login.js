// import { Button } from "bootstrap";  
import { useHistory} from 'react-router-dom';
function Login()
{
    const history = useHistory();
    const SignIn=()=>
    {
        window.sessionStorage.setItem("isLoggedIn", 'true');
        history.push('/TheatreBooking');
    }

    return(
        // <h2> Welcome to Login</h2>
        <div className="container table-responsive jumbotron text-justify" >
            <table className="table table-bordered"></table>
            <tbody >
                <tr>
                    <td >
                        UserName :
                    </td>
                    <td>
                        <input className="form-control"></input>
                    </td>
                </tr>
                <tr>
                    <td>
                        Password :
                    </td>
                    <td>
                        <input className="form-control"></input>
                    </td>
                </tr>
                <tr>
                <button className='btn btn-success' onClick={SignIn}>SignIn</button>
                </tr>
            </tbody>
        </div>
    )
}
export default Login;