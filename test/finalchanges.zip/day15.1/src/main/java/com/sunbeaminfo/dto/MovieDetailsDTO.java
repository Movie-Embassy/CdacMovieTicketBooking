package com.sunbeaminfo.dto;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.enums.Format;
import com.sunbeaminfo.enums.Language;

public class MovieDetailsDTO {
	
	private long surrogateKey ;

	private Long movieId;
	
	private Format format;
	
	private Language language ;

	public MovieDetailsDTO() {
		super();
	}

	public MovieDetailsDTO(long surrogateKey, Long movieId, Format format, Language language) {
		super();
		this.surrogateKey = surrogateKey;
		this.movieId = movieId;
		this.format = format;
		this.language = language;
	}

	public MovieDetailsDTO(Long movieId, Format format, Language language) {
		super();
		this.movieId = movieId;
		this.format = format;
		this.language = language;
	}

	public long getSurrogateKey() {
		return surrogateKey;
	}

	public void setSurrogateKey(long surrogateKey) {
		this.surrogateKey = surrogateKey;
	}

	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	
	
}
