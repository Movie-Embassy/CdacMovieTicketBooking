package com.sunbeaminfo.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user_card_tbl") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class UserCardDetails implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@ManyToOne
	@JoinColumn(name = "user_id",nullable = false)
	private User user;
	
	@Column(name = "card_number", length=15,unique = true,nullable = false)
	private String cardNumber;
	
	@Column(name = "card_expiry")
	private LocalDate cardExpiry;
	
	@Column(name="card_holder_name")
	private String cardHolderName;

	
	
}
