package com.sunbeaminfo.dto;




public class UserDTO {

	private Long id;
	
	private String firstName;
	
	private String lastName;
	
	private String userEmail;
	
	private String contactNo;
	
	private int userAge;

	private String userUip;

	public UserDTO(Long id, String firstName, String lastName, String userEmail, String contactNo, int userAge,
			String userUip) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
		this.userAge = userAge;
		this.userUip = userUip;
	}

	public UserDTO() {
		super();
	}

	public UserDTO(String firstName, String lastName, String userEmail, String contactNo, int userAge, String userUip) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
		this.userAge = userAge;
		this.userUip = userUip;
	}
	
	
	
	
	
	
	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}

	public String getUserUip() {
		return userUip;
	}

	public void setUserUip(String userUip) {
		this.userUip = userUip;
	}

	
	
	
	
	
	
}
