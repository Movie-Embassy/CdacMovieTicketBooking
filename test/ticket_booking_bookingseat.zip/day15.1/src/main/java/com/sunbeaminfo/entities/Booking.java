package com.sunbeaminfo.entities;



import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="booking_tbl")
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_id")
	private Long BookingId;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	
	@ManyToOne
	@JoinColumn(name = "show_id")
	private Show show;
	
	@OneToOne
	@JoinColumn(name = "ticket_id")
	
	private Ticket ticket;
	
	@Column(name = "transaction_start_time_id")
	private LocalDateTime transactionStratTime;
	

	
	@OneToMany(mappedBy = "booking", cascade = CascadeType.REMOVE)
	@JsonIgnore
	private Set<BookingSeat> bookingSeat = new HashSet<BookingSeat>();
	
	
	public Booking(User user, Show show, LocalDateTime transactionStratTime) {
		super();
		this.user = user;
		this.show = show;
		this.transactionStratTime = transactionStratTime;
	}
	public Booking(Long bookingId) {
		super();
		BookingId = bookingId;
	}
	public Booking(User user, Show show, Ticket ticket, LocalDateTime transactionStratTime) {
		super();
		this.user = user;
		this.show = show;
		this.ticket = ticket;
		this.transactionStratTime = transactionStratTime;
	}
	public Booking(Long bookingId, User user, Show show, Ticket ticket, LocalDateTime transactionStratTime) {
		super();
		BookingId = bookingId;
		this.user = user;
		this.show = show;
		this.ticket = ticket;
		this.transactionStratTime = transactionStratTime;
	}
	public Long getBookingId() {
		return BookingId;
	}
	public void setBookingId(Long bookingId) {
		BookingId = bookingId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public LocalDateTime getTransactionStratTime() {
		return transactionStratTime;
	}
	public void setTransactionStratTime(LocalDateTime transactionStratTime) {
		this.transactionStratTime = transactionStratTime;
	}
	
	
	
	
	
	
}
