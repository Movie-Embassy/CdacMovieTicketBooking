package com.sunbeaminfo.emuns;

public enum Certificate {
U,UA,A
}
