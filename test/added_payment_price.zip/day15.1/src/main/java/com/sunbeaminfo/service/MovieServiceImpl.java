package com.sunbeaminfo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.MovieDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDTO;
import com.sunbeaminfo.dto.MovieListDto;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDao movieDao;
	
	
	
	@Override
	public List<MovieListDto> getAllMovies() {
		
		List<MovieListDto> movieList = new ArrayList<MovieListDto>(); 
		for(Movie m:movieDao.findAll()) {
			int rating = 0;
			for(MovieReview r : m.getMovieReviews()) {
				rating =rating + r.getReviewRating();
			}
			
			 MovieListDto movieDto = new MovieListDto(m.getMovieId(), m.getMovieName(), m.getReleaseDate(), m.getMovieTile(), m.getMovieBgImage(),rating);
			 movieList.add(movieDto);
		}
		return movieList;
	}

	
	
	@Override
	public Movie addMovie(MovieDTO m) {
		// TODO Auto-generated method stub
		
		Movie movie = new Movie(m.getMovieName(), m.getReleaseDate(), m.getRunTime(), m.getDescription(), m.getMovieTile(), m.getMovieBgImage(), m.getTrailerUrl(), m.getCertificate(),m.getFilmIndustry());
		
		return movieDao.save(movie);
	}

	@Override
	public Movie getMovie(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteMovie(Long id) {
		movieDao.deleteById(id);
		
		return new ApiResponse("Movie is deleted");
	}
	
	@Override
	public Movie addmovieDetails(MovieDTO m) {
		
		Movie movie = new Movie(m.getMovieId(), m.getMovieName(), m.getReleaseDate(), m.getRunTime(), m.getDescription(), m.getMovieTile(), m.getMovieBgImage(), m.getTrailerUrl(), m.getCertificate(), m.getFilmIndustry());
		
		return movieDao.save(movie);
	}

	@Override
	public Movie getmovieDetails(Long movieId) {
		
		return movieDao.findById(movieId).orElseThrow(() -> new ResourceNotFoundException("movie id invalid !!!!!"));
	}
	
}
