import React from 'react'

const SearchResult = () => {
  return (
    <div>
      
    </div>
  )
}

export default SearchResult
