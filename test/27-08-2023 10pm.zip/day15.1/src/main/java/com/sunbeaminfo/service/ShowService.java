package com.sunbeaminfo.service;

import java.util.List;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ShowDTO;
import com.sunbeaminfo.dto.ShowListDTO;
import com.sunbeaminfo.entities.Show;



public interface ShowService {
	
	List<com.sunbeaminfo.entities.Show> getAllShows();
	
	Show addShow(ShowDTO m);
	
	List<ShowListDTO> movieShowList(Long movieId);

	ApiResponse deleteShow(Long id);
	
	List<Show> listAllShows();
}
