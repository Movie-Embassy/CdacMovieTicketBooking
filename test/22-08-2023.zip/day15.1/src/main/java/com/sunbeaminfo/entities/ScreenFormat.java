package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import com.sunbeaminfo.emuns.Format;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Table(name="screen_format_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class ScreenFormat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="screen_format_id", nullable = false, unique = true)
	private long  screenFormatId;
	
	
	@ManyToOne
	@JoinColumn(name="screen_id", nullable = false)
	private Screen screen;
	
	@Enumerated(EnumType.STRING)
	private Format format;
	
	
	public ScreenFormat() {
		super();
	}

	public ScreenFormat(Screen screen, Format format) {
		super();
		this.screen = screen;
		this.format = format;
	}

	public Format getFormat() {
		return format;
	}

	public void setFormat(Format format) {
		this.format = format;
	}

	public long getScreenFormatId() {
		return screenFormatId;
	}

	public void setScreenFormatId(long screenFormatId) {
		this.screenFormatId = screenFormatId;
	}

	public Screen getScreen() {
		return screen;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	

	
	
}
