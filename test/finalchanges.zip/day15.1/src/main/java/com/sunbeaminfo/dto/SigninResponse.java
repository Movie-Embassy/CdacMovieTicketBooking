package com.sunbeaminfo.dto;

import java.util.Optional;

import com.sunbeaminfo.entities.Admin;
import com.sunbeaminfo.entities.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class SigninResponse {
	public SigninResponse(String token, String message, User user) {
		super();
		this.token = token;
		this.message = message;
		this.user = user;
	}	

	

	private String token;
	private String message;
	private User user;
	
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	

}
