package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="show_tbl")
public class Show {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="show_id" , unique = true)
	private Long showId ;
	
	@Column(name="show_datetime"  )
	private LocalDateTime showDateTime;
	
	
	@ManyToOne
	@JoinColumn(name="theatre_id" )
	private Theatre theatre;
	

	

	@ManyToOne
	@JoinColumn(name="movie_id" )
	private Movie movie;
	
	@OneToOne
	@JoinColumn(name="movie_details_id" )
	private MovieDetails movieDetails;

	public Show() {
		super();
	}

	public Show(Long showId, LocalDateTime showDateTime, Theatre theatre, Movie movie, MovieDetails movieDetails) {
		super();
		this.showId = showId;
		this.showDateTime = showDateTime;
		this.theatre = theatre;
		this.movie = movie;
		this.movieDetails = movieDetails;
	}

	public Show(LocalDateTime showDateTime, Theatre theatre, Movie movie, MovieDetails movieDetails) {
		super();
		this.showDateTime = showDateTime;
		this.theatre = theatre;
		this.movie = movie;
		this.movieDetails = movieDetails;
	}

	public Show(Long showId) {
		super();
		this.showId = showId;
	}

	
	
	public Long getShowId() {
		return showId;
	}

	public void setShowId(Long showId) {
		this.showId = showId;
	}

	public LocalDateTime getShowDateTime() {
		return showDateTime;
	}

	public void setShowDateTime(LocalDateTime showDateTime) {
		this.showDateTime = showDateTime;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public MovieDetails getMovieDetails() {
		return movieDetails;
	}

	public void setMovieDetails(MovieDetails movieDetails) {
		this.movieDetails = movieDetails;
	}

	
	
	
	
}
