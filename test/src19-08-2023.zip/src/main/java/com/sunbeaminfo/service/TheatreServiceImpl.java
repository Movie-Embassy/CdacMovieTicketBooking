package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.TheatreDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class TheatreServiceImpl implements TheatreService {

	@Autowired
	private TheatreDao theatreDao;
	
	
	
	@Override
	public List<Theatre> getAllTheatres() {
		System.out.println("11111111");
		return theatreDao.findAll();
	}

	@Override
	public Theatre addTheatre(Theatre t) {
		// TODO Auto-generated method stub
		return theatreDao.save(t);
	}

	@Override
	public Theatre getTheatre(Long id) {
		
		return null;
	}
	
	@Override
	public ApiResponse deleteTheatre(Long id) {
		theatreDao.deleteById(id);
		
		return new ApiResponse("Theatre is deleted");
	}

	
}
