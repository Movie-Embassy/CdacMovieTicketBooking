package com.sunbeaminfo.controller;

import java.util.List;
import java.util.Optional;
import com.sunbeaminfo.dto.ShowDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.service.ShowService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/Show")
@CrossOrigin(origins = "*")
public class ShowController {

	@Autowired
	private ShowService ShowService;
	
	
	public ShowController() {
		System.out.println("in ctor of " + getClass());
	}
	
//	@GetMapping
//	public List<Show> listAllShows(){
//		
//		return ShowService.getAllShows();
//	}
	
	@GetMapping
	public List<Show> listAllShows(){
		return ShowService.listAllShows();
	}
	
	@PostMapping
	public Show saveShowDetails(@RequestBody Show m) {
		return ShowService.addShow(m);
	}
	
	@DeleteMapping
	public ApiResponse deleteShow(@RequestParam Long id) {
		return ShowService.deleteShow(id);
	}
	
	@PostMapping("/addNewShow")
	public Show saveNewShow(@RequestBody Show s) {
		return ShowService.saveNewShow(s);
	}
//
//	@GetMapping("/shows/{id}")
//	public ResponseEntity<ShowDTO> getShowById(@PathVariable Long id) {
//	    Show show = ShowService.getShow(id); // Use ShowService instead of showService
//
//	    // Map the Show entity to ShowDTO
//	    ShowDTO showDTO = mapToShowDTO(show);
//
//	    return ResponseEntity.ok(showDTO);
//	}
//
//	private ShowDTO mapToShowDTO(Show show) {
//	    return new ShowDTO(
//	        show.getShowId(),
//	        show.getShowDateTime(),
//	        show.getTheatre().getScreenNameForNumber(show.getScreen().getScreenNumber()),
//	        show.getMovie().getTitle()
//	    );
//	}


	
	
}
