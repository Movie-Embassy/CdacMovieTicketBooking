package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_genre_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class MovieGenre {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_genre_id", nullable = false, unique = true)
	private long  movieGenreId;
	
	
	@ManyToOne
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	@Enumerated(EnumType.STRING)
	@Column(name="genre", nullable = false , unique = true)
	private Genre genre;

	public long getMovieGenreId() {
		return movieGenreId;
	}

	public void setMovieGenreId(long movieGenreId) {
		this.movieGenreId = movieGenreId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setGenre(Genre genre) {
		this.genre = genre;
	}
	
	
	
	
	
	
	
}
