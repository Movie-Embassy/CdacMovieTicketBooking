import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Form, Button } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { loginUser as loginUserApi } from "../../../src/services/user";
//import { FaFacebook, FaGoogle } from "react-icons/fa";
import "./Login.css";
import { toast } from 'react-toastify'
//import userService from "./services/user";
// import validation from "./services/validation";


function Login() {

  const [userEmail, setUserEmail] = useState('')
  const [password, setPassword] = useState('')

  const navigate=useNavigate();

  const loginUser = async () => {
    
    
     
      // call register api
      const response = await loginUserApi(
        password,
        userEmail,
      )

      // parse the response
      // if (response.data.firstName === 'firstName' && response.data.password == password)
      if (response['status'] == 200) 
        {

          toast.success('User login successful')
          
          // go back to login
          navigate('/')
      } else {
        toast.error('Error in logging in...please re-check credentials')
      }
    
  }

  return (
    <Container className="login-container">

      <div className="login-box">
        <h2>Login</h2>
        <form>
        <label>Email</label>
        <input type="email" className="form-control" id="email" required onChange={(e) => {
                  setUserEmail(e.target.value)
                }}/>

        <label>Password</label>
        <input type="password" className="form-control" id="pwd" required  onChange={(e) => {
                  setPassword(e.target.value)
                }}/>

          <br/>
            <center><input type="submit" className="btn btn-primary" value="Log in" id="loginbtn" color="red" onClick={loginUser}/> </center> 
           
             {/* <center><button type="submit" className="btn" value="Log in" id="loginbtn" color="blue" onClick={loginUser}/>Log In<button/> </center> */}
            </form>
    
        <p className="no-account">
          Don't have an account? <Link to="/signup" text="blue">Sign up</Link>
        </p>
      </div>
    </Container>
  );
}

export default Login;