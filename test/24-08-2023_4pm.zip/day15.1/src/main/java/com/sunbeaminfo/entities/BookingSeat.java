package com.sunbeaminfo.entities;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.sunbeaminfo.emuns.Status;

import net.bytebuddy.utility.nullability.MaybeNull;

@Entity
@Table(name="book_seat_tbl")
public class BookingSeat {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_seat_id")
	private Long bookingSeatId;
	
	@ManyToOne
	@JoinColumn(name = "booking_id")
	private Booking booking;
	
	@OneToOne
	@JoinColumn(name = "seat_id")
	private Seat seat;
	
	@Enumerated
	@Column(name = "status")
	private Status status;

	
	
	
	
	
}
