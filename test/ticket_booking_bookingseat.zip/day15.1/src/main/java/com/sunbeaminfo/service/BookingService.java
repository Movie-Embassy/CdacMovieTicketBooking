package com.sunbeaminfo.service;

import java.util.List;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.BookingDTO;
import com.sunbeaminfo.entities.Booking;

public interface BookingService {

	List<Booking> getAllBookings ();
	
	Booking getBookingById(Long Id);
	
	Booking addBooking(BookingDTO bk);
	
	ApiResponse deleteById(Long Id);
}
