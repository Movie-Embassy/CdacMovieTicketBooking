package com.sunbeaminfo.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.TicketDao;
import com.sunbeaminfo.entities.Ticket;

@Transactional
@Service
public class TicketServiceImpl implements TicketService{

	@Autowired
	private TicketDao ticketDao ;
	
	@Override
	public List<Ticket> getAllTickets() {
		
		return ticketDao.findAll();
		
	}

	@Override
	public Ticket getTicketsById(Long ticketId) {

		return ticketDao.findById(ticketId).orElseThrow(() -> new ResourceNotFoundException("ticket id invalid !!!!!"));
	}

	@Override
	public List<Ticket> getAllTicketsByUser(Long userId) {
	
		return ticketDao.findByUser(userId);	
	}

	@Override
	public Ticket getTicketByUserForShow(Long userId, Long showId) {
		
		return ticketDao.findByUserIdShow(userId, showId);
	}

}
