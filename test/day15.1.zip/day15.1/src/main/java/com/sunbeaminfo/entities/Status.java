package com.sunbeaminfo.entities;

public enum Status {

	BOOKED,AVAILABLE,BLOCKED
}
