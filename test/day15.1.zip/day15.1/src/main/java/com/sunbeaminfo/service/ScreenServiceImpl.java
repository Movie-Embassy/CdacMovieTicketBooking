package com.sunbeaminfo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.ScreenDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class ScreenServiceImpl implements ScreenService {

	@Autowired
	private ScreenDao screenDao;
	
	
	
	@Override
	public List<ScreenDto> getAllScreens() {
		List<ScreenDto> screenDto = new ArrayList<ScreenDto>();
		for(Screen s : screenDao.findAll()) {
			ScreenDto sdto = new ScreenDto(s.getScreenId(), s.getScreenNumber(), s.getTheatre().getTheaterId());
			screenDto.add(sdto);
		}
		return screenDto;
	}

	@Override
	public Screen addScreen(ScreenDto m) {
		// TODO Auto-generated method stub
		Screen screen =  new Screen(m.getScreenNumber(), new Theatre(m.getTheatreId()));
		
		return screenDao.save(screen);
	}

	@Override
	public Screen getScreen(Long id) {
		
		return null;
	}

	
	@Override
	public ApiResponse deleteScreen(Long id) {
		screenDao.deleteById(id);
		
		return new ApiResponse("Screen is deleted");
	}
	
	@Override
	public Screen addscreenDetails(ScreenDto s) {
		// API of CrudRepository : T save(T entity)
		
		Screen screen = new Screen(s.getScreenNumber(), new Theatre(s.getTheatreId()));
		
		
		return screenDao.save(screen);
	}// auto dirty chking --> insert --> sesison closed --> rets detached screen to the
		// caller

	@Override
	public Screen getscreenDetails(Long screenId) {
		// TODO Auto-generated method stub
		return screenDao.findById(screenId).orElseThrow(() -> new ResourceNotFoundException("screen id invalid !!!!!"));
	}
	
	
}
