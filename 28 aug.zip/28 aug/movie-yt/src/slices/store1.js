import { configureStore } from "@reduxjs/toolkit";
import seatSlice from "../store/seatSlice";
export const store = configureStore({
    reducer:{
        seat: seatSlice
    }
})