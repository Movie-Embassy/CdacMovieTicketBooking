import { useEffect, useState } from 'react';
import {useParams, useHistory} from 'react-router-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

function Details()
{
    const history = useHistory();
    const [movieDetails, setMovieDetails] = useState({
        id : 0,
        Title: "",
        Desc : "",
        cast : [],
        Cast : [],
        Format : [],
        Language : [],
        Crew : [],
        Reviews:[],
        genre : "",
        tile : "",
        imdb:"",
        rating:"",
        runtime : "",
        certificate : "",
        backgroundimage : "",
        url : ""
       
    });
    var{id} = useParams();// id will be in string
    useEffect(()=>{
        var helper = new XMLHttpRequest();
        helper.onreadystatechange=()=>{
            if(helper.readyState ==4 && helper.status==200)
            {
                var dataReceived =  JSON.parse(helper.responseText);
                console.log(dataReceived);
                setMovieDetails(dataReceived);
            }
        }
    helper.open("GET",`http://localhost:3000/Data/${id}.json`);
        helper.setRequestHeader("Content-Type","application/json");
        helper.send();
    },[]);
  const gotoBook=()=>{
    console.log("you are about to book");
    console.log(movieDetails);
    window.sessionStorage.setItem("MovieToBEBook", movieDetails.Title)
    history.push('/TheatreBooking');
    
  }
    return (
    // <h1> Movie No {id} Details Here..</h1>
  <>
    <div style={{width:"100%",height:"400px",position:"relative"}} >
        <img src={movieDetails.backgroundimage} alt='Adipurush' style={{width:"100%",height:"400px",opacity:1, position:"relative",top:0,left:0}}></img>
<div style={{width:"100%",height:"400px",backgroundColor:"black",position:"relative",top:-400,opacity:0.5}}></div>

<div style={{width:"100%",height:"400px",position:"relative",top:-1300}}><center><h2 style={{fontFamily:"initial",color:"white",opacity:0.8}}><b>{movieDetails.runtime}</b>  <b>{movieDetails.genre}</b><b>{movieDetails.certificate}</b></h2></center></div>

<div style={{position:"relative",top:-1180,left:40}}><iframe width="560" height="315" 
                    src={movieDetails.url} title="YouTube video player" 
                    frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe></div>
                    <div style={{width:"100%",height:"400px",position:"relative",top:-1550,left:350}}><center><h2 style={{fontFamily:"initial",color:"white",opacity:0.8}}><b>{movieDetails.runtime}</b>  <b>{movieDetails.genre}</b><b> {movieDetails.certificate}</b></h2></center></div>
                    <button className='btn btn-success' onClick={gotoBook} style={{position:"relative",top:-1650,left:650}} >Book Tickets</button>
  <div style={{width:490,height:70,position:"relative",top:-1750,left:780,display:"flex",flexWrap:"wrap"}}>
    {
        movieDetails.Language.map((lang)=>{
        return    <div style={{width:100,height:50,borderRadius:25,backgroundColor:"white",opacity:0.5,marginLeft:10,marginTop:10}}><center style={{position:"relative",top:8,color:"black"}}><h4>{lang}</h4></center></div>
        })

    }
  </div>
  <div style={{width:490,height:70,position:"relative",top:-1750,left:780,display:"flex",flexWrap:"wrap"}}>
  {
        movieDetails.Format.map((form)=>{
        return    <div style={{width:80,height:50,borderRadius:25,backgroundColor:"white",opacity:0.5,marginLeft:10,marginTop:10}}><center style={{position:"relative",top:8,color:"black"}}><h4>{form}</h4></center></div>
        })

  }
 
  </div>
    </div>
    
        
        
    <br/> 
    <center><h1>{movieDetails.Title}</h1></center>
    <br/> <br/> <br/> 

    <div style={{display:'flex',flexWrap:"wrap",width:"100%"}} >
    {/* <div style={{display:'flex',flexWrap:"wrap",width:"1080px",,overflow:"scroll"}} > */}
    


    <div style={{height:250,width:250,marginLeft:60}}>
        
        
    <center><img src={movieDetails.tile} alt='adipurush_tile' style={{width:"250px",height:"320px",borderRadius:"15px"}}></img></center>
        <div width="250px"><img src={movieDetails.imdb} alt='IMDb' style={{width:"100px",height:"40px",position:"relative",left:45}}></img></div><h4 style={{position:"relative",top:-40,left:155}}><b>{movieDetails.rating}</b></h4>

</div>


<div style={{height:250,width:250,marginLeft:180}}>
        
        <h3><center><b>CAST</b></center></h3>
        <br/> 
<Carousel showThumbs={false}> 


{
    movieDetails.Cast.map((actor)=>{
        
    return    <div style={{height:300}}>
        <img className="img-circle" src={actor.imageurl} style={{width:190,height:190}}/>
        <div style={{height:190,width:190}}> <p className="legend">{actor.name}<br/>as {actor.role}</p></div>
      </div>

    })
}
       
</Carousel>

</div>

<div style={{height:250,width:250,marginLeft:180}}>
        
        <h3><center><b>CREW</b></center></h3>
        <br/> 
<Carousel showThumbs={false}> 
                
{
    movieDetails.Crew.map((crew)=>{
        
    return    <div style={{height:300}}>
        <img className="img-circle" src={crew.imageurl} style={{width:190,height:190}}/>
        <div style={{height:190,width:190}}> <p className="legend">{crew.name}<br/>{crew.role}</p></div>
      </div>

    })
}

</Carousel>

</div>

</div>



<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<div style={{display:'flex',flexWrap:"wrap",width:"100%",height:"500px"}} >
    {/* <div style={{display:'flex',flexWrap:"wrap",width:"1080px",,overflow:"scroll"}} > */}
    


    <div style={{height:250,width:230,marginLeft:60}}>
        
        
   <h2>Description</h2>
    <p style={{textAlign:"justify",fontSize:15}}>
      {movieDetails.Desc}
    </p>
    <br/><br/><br/>
   
   
</div>


<div style={{width:"700px",height:"400px",overflow:"scroll",marginLeft:225,}}>
<center><h2>Reviews</h2>  </center>


{
movieDetails.Reviews.map((review)=>{
return <div style={{width:"600px",height:"125px",marginLeft:50,marginBottom:20,borderRadius:10,borderBlockColor:"blue",borderWidth:1,borderStyle:"solid",fontSize:20}}>
    {review.review}<br/>
    ~<mahesh style={{fontSize:15}}>{review.name}</mahesh>
    <br/>
    <img src="/images/star.jpg" alt='star' style={{width:30,height:30}}></img>
    {review.rating}
</div>
})
}
</div>

</div> 
        <div className='table-responsive'>
          
                {/* <tr>
                    <td>
                     <div >
                        <h3 > {movieDetails.Title}</h3>
                    </div>
                    </td>
                </tr>
                <tr>
                    <td className='text-justify'>
                        <p>
                            {movieDetails.Desc}
                        </p>
                    </td>
                </tr>
                <tr>
                    <td className='text-justify'>
                        Genre : {movieDetails.Genre}<br></br><br></br>
                        Actors : <ul>
                            {
                                movieDetails.cast.map((actor)=>{
                                    return <li>
                                        {actor}
                                        </li>
                                })
                            }
                        </ul>
                    </td>
                </tr> */}
                
                    
           
                  
                   
               
                
                        
                        
               
           
            
        </div>
    </>
    )
        }
export default Details;