package com.sunbeaminfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.SeatDTO;
import com.sunbeaminfo.entities.Seat;
import com.sunbeaminfo.service.SeatService;
import com.sunbeaminfo.service.TheatreService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/seat")
@CrossOrigin(origins = "*")
public class SeatController {

	@Autowired
	private SeatService SeatService;
	
	
	
	public SeatController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping("/all")
	public List<Seat> listAllSeats(){
		return SeatService.getAllSeats();
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> saveSeatDetails(@RequestBody SeatDTO m) {
		
		return new ResponseEntity(SeatService.addSeatDetails(m),HttpStatus.OK);
	}
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteSeat(@RequestParam Long id) {
		SeatService.deleteSeat(id);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	@GetMapping("/screen")
	public List<Seat> seatsByScreen(@RequestParam Long id){
		return SeatService.getScreenSeats(id);
	}
	
	
	
}
