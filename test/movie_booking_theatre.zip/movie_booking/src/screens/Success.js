import React from 'react'
import './Success.css'
const Success = () => {
  return (
    <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">Ticket Confirmation Success</h3>
          </div>
          <div class="panel-body">
            <div class="success-message">
              <p>Your ticket has been confirmed!</p>
              <p>Enjoy the movie!</p>
              <span>Your ticket Ref.NO is:712312nasd221</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Success
