// import './index.css';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import { useHistory } from 'react-router-dom';
function Home() {
  const history = useHistory();
   const MovieDetails=(args)=>
  {
    var id = args.target.id;
    // console.log(id);
    history.push('Details/'+id);
  }
  return (<>
    <div className="container marketing">
       <div className="row">
           <div className="col-lg-4">
       <img className="img-circle" src="http://localhost:3000/images/movie-1.png" alt="Generic placeholder image" width="140" height="140"
       id="1"
       onClick={MovieDetails}/>
       <h2>ZARA HATKE ZARA BACHKE</h2>
       <p>Kapil and Somya are a happily married couple from Indore who live in a joint family and decide to get a divorce one fine day. Things don`t go as planned as their family gets to know of it, and thus begins a comedy of errors.</p>
       <p><a className="btn btn-default" href="#" role="button">View details &raquo;</a></p>
       </div>
       <div className="col-lg-4">
       <img className="img-circle" src="http://localhost:3000/images/movie-2.png" alt="Generic placeholder image" width="140" height="140"
       id="2"
       onClick={MovieDetails}
       />
       <h2>TRANSFORMERS-Rise of the Beasts</h2>
       <p>Transformers: Rise of the Beasts will take audiences on a `90s globetrotting adventure and introduce the Maximals, Predacons, and Terrorcons to the existing battle on earth between Autobots and Decepticons..</p>
       <p><a className="btn btn-default" href="#" role="button">View details &raquo;</a></p>
       </div>
       <div className="col-lg-4">
       <img className="img-circle" src="http://localhost:3000/images/movie-3.png" alt="Generic placeholder image" width="140" height="140"
       id="3"
       onClick={MovieDetails}
       />
       <h2>ADIPURUSH</h2>
       <p>Adipurush is an adaptation of Indian mythology that depicts the victory of good over evil..</p>
       <p><a className="btn btn-default" href="#" role="button">View details &raquo;</a></p>
       </div>
   </div>
  </div>
  </> );
}

export default Home;
