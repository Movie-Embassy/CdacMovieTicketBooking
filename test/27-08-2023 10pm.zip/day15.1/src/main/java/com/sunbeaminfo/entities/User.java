package com.sunbeaminfo.entities;


import javax.persistence.*;

/*
 * 1)Table made for user entity which is stand alone entity
 */


@Entity
@Table(name = "user_tbl") // to specify table name
public class User {
	
	//Primary Key 
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long id;

	//Field for first name
	@Column(name = "first_name",length = 20,nullable = false)
	private String firstName;
	
	//Field for last name
	@Column(name = "last_name", length =20,nullable=false)
	private String lastName;
	
	//Field for password
	@Column(name = "password",length=50)
	private String password;
	
	//field for user email
	@Column(name = "user_email",length=20,unique = true,nullable = false)
	private String userEmail;
	
	//filed for contact number (stored in string because int or long is not able to store 10 digit no)
	@Column(name="user_contact",length = 12,unique = true,nullable = false)
	private String contactNo;
	
	//field for use age
	@Column(name = "user_age",length=3)
	private int userAge;

	//field for user upi id
	@Column(name = "user_upi")
	private String userUip;
	
	//default constructor 
	public User() {
		super();
	}
	
	
	//constructor (all fields except id)
	public User(String firstName, String lastName, String password, String userEmail, String contactNo, int userAge,
			String userUip) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.userEmail = userEmail;
		this.contactNo = contactNo;
		this.userAge = userAge;
		this.userUip = userUip;
	}

	
	//constructor using only id ***MAINLY USED IN DTO's
	public User(Long id) {
		super();
		this.id = id;
	}

	
	//constructor made for checking password and email ***USER AUTHENTICATION
	public  User(String userEmail, String password ) {
		this.userEmail = userEmail;
		this.password = password;
	}
	
	
	
	//Getters and Setter for all fields
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}

	public String getUserUip() {
		return userUip;
	}

	public void setUserUip(String userUip) {
		this.userUip = userUip;
	}
	
	
}
