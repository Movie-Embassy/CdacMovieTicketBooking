package com.sunbeaminfo.enums;

public enum Category {
SILVER,GOLD,PLATINUM,PREMIUM_SILVER,PREMIUM_GOLD,PREMIUM_PLATINUM
}
