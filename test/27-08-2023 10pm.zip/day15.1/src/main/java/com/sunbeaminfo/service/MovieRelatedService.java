//package com.sunbeaminfo.service;
//
//
//
//
//public interface MovieRelatedService {
//	
//
//	
//
//	
//}
