package com.sunbeaminfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.MovieDTO;
import com.sunbeaminfo.dto.MovieListDto;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.service.MovieService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/Movie")
@CrossOrigin(origins = "*")
public class MovieController {

	@Autowired
	private MovieService movieService;
	
	
	public MovieController() {
		System.out.println("in ctor of " + getClass());
	}
	
	
	//Need to change Movie to MovieListDTO
	
	@GetMapping
	public List<MovieListDto> listAllMovies(){
		
		return movieService.getAllMovies();
	}
	
	@PostMapping
	public Movie saveMovieDetails(@RequestBody MovieDTO m) {
		return movieService.addMovie(m);
	}
	
	@DeleteMapping
	public ApiResponse deleteMovie(@RequestParam Long id) {
		return movieService.deleteMovie(id);
	}
	
	@PutMapping
	public  Movie updatemovieInfo(@RequestBody MovieDTO m) {
		movieService.getmovieDetails(m.getMovieId());
		
		return movieService.addmovieDetails(m);
	}
	

}
