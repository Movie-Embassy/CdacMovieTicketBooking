package com.sunbeaminfo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.service.ScreenService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/screen")
@CrossOrigin(origins = "*")
public class ScreenController {

	@Autowired
	private ScreenService screenService;
	
	
	public ScreenController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping("/all")
	public List<ScreenDto> listAllScreens(){
		return screenService.getAllScreens();
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> saveScreenDetails(@RequestBody ScreenDto m) {
		
		return new ResponseEntity(screenService.addScreen(m),HttpStatus.OK);
	}
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteScreen(@RequestParam Long id) {
		screenService.deleteScreen(id);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	
	@PutMapping("/update")
	public  ResponseEntity<?> updatescreenInfo(@RequestBody ScreenDto m) {
		screenService.getscreenDetails(m.getScreenId());
		
		screenService.addscreenDetails(m);
		return new ResponseEntity(HttpStatus.OK);
	}

}
