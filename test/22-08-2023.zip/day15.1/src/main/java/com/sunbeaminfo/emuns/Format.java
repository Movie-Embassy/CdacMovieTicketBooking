package com.sunbeaminfo.emuns;

public enum Format {
	D2,D3,IMAX,DX4,IMAX2D,IMAX3D
	
}
