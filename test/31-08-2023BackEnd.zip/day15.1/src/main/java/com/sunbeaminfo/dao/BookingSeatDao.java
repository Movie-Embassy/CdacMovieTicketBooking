package com.sunbeaminfo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.BookingSeat;

public interface BookingSeatDao extends JpaRepository<BookingSeat, Long>{
	
//	@Query(value = "select seat_id from book_seat_tbl where  booking_tbl.booking_id=booking_seat_tbl.booking_id and booking_tbl.show_id=:showId;", nativeQuery = true)
	@Query("select new com.sunbeaminfo.entities.BookingSeat(seat) from BookingSeat b where b.booking.BookingId=b.bookingSeatId and b.booking.show.showId=?1")
	List<BookingSeat> showSeatsList(Long showId);

	
}
