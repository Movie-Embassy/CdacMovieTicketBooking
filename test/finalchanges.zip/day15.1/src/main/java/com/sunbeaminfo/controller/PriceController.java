package com.sunbeaminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.PriceByShowCategoryDTO;
import com.sunbeaminfo.dto.PriceDTO;
import com.sunbeaminfo.entities.Price;
import com.sunbeaminfo.service.PriceService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/price")
@CrossOrigin(origins = "*")
public class PriceController {

	@Autowired
	private PriceService priceService;

	public PriceController() {
		super();
	}
	
	@GetMapping("/priceid")
	public Price getPriceById(@RequestParam Long Id)
	{
		return priceService.getPriceById(Id);
	}
	
	@GetMapping("/showid")
	public Price getPriceByShowAndCategory(@RequestBody PriceByShowCategoryDTO obj)
	{
		return priceService.getPriceByShowId(obj);
	}
	
	@PostMapping("/price")
	public ResponseEntity<?> addPrice(@RequestBody PriceDTO pricedto)
	{
	  
	  return new ResponseEntity(priceService.addPrice(pricedto),HttpStatus.OK);
	}
}
