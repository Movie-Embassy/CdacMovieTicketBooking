package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.jbosslog.JBossLog;


@Entity
@Table(name="movie_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_id", nullable = false, unique = true)
	private Long movieId;
	
	@Column(name="movie_name",length=50, nullable = false, unique = true)
	private String movieName;
	
	@Column(name="release_date", nullable = false)
	private LocalDate releaseDate;
	
	@Column(name="run_time" , nullable = false)
	private int runTime ;
	
//	@Lob
	@Column(name="description", length = 500, columnDefinition ="TEXT", nullable = false)// CHECK THIS
	private String description;
	
	@Column(name="movie_title", length =50, nullable = false , unique = true)
	private String movieTitle;
	
	@Column(name="movie_Bg_Image", length =50 , nullable = false , unique = true)
	private byte[] movieBgImage;
	
	@Column(name="trailer_url", length =500 , nullable = false , unique = true)
	private String trailerUrl;
	
	
	public Movie( String movieName, LocalDate releaseDate, int runTime, String description,
			String movieTitle, byte[] movieBgImage, String trailerUrl) {
		super();
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.runTime = runTime;
		this.description = description;
		this.movieTitle = movieTitle;
		this.movieBgImage = movieBgImage;
		this.trailerUrl = trailerUrl;
	}

	public Movie() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((movieId == null) ? 0 : movieId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (movieId == null) {
			if (other.movieId != null)
				return false;
		} else if (!movieId.equals(other.movieId))
			return false;
		return true;
	}

	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getRunTime() {
		return runTime;
	}

	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public byte[] getMovieBgImage() {
		return movieBgImage;
	}

	public void setMovieBgImage(byte[] movieBgImage) {
		this.movieBgImage = movieBgImage;
	}

	public String getTrailerUrl() {
		return trailerUrl;
	}

	public void setTrailerUrl(String trailerUrl) {
		this.trailerUrl = trailerUrl;
	}
	
	
	
	
	
	
	
}
