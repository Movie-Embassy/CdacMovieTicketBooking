package com.sunbeaminfo.dto;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.entities.Ticket;
import com.sunbeaminfo.entities.User;

public class BookingDTO {

	private Long BookingId;
	
	
	private Long userId;
	
	
	private Long showId;
	
	
	private LocalDateTime transactionStratTime;


	public BookingDTO() {
		super();
	}


	public BookingDTO(Long bookingId, Long userId, Long showId, LocalDateTime transactionStratTime) {
		super();
		BookingId = bookingId;
		this.userId = userId;
		this.showId = showId;
		this.transactionStratTime = transactionStratTime;
	}


	public Long getBookingId() {
		return BookingId;
	}


	public void setBookingId(Long bookingId) {
		BookingId = bookingId;
	}


	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public Long getShowId() {
		return showId;
	}


	public void setShowId(Long showId) {
		this.showId = showId;
	}


	public LocalDateTime getTransactionStratTime() {
		return transactionStratTime;
	}


	public void setTransactionStratTime(LocalDateTime transactionStratTime) {
		this.transactionStratTime = transactionStratTime;
	}


	@Override
	public String toString() {
		return "BookingDTO [BookingId=" + BookingId + ", userId=" + userId + ", showId=" + showId
				+ ", transactionStratTime=" + transactionStratTime + "]";
	}
	
	
	
	
	
	
	
}
