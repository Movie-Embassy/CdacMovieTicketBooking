package com.sunbeaminfo.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Admin;
import com.sunbeaminfo.entities.User;





public interface AdminDao extends JpaRepository<Admin, Long> {

	@Query("select new com.sunbeaminfo.entities.Admin(firstName, lastName) from Admin u where u.userEmail =?1 and u.password=?2")
	Optional<Admin> findByUserEmailAndPassword(String em,String pass);
	
	Optional<Admin> findByUserEmail(String email);
	
	@Query("select u from Admin u where u.userEmail=:email")
	Admin validLogin(String email);
	
//	@Query("Update User u set u.firstName=?1, u.lastName=?2, u.password=?3, u.userEmail=?4, u.contactNo=?5, u.userAge=?6, u.userUpi=?7 where u.id=?8")
//	int updateUserInfo(String firstName, String lastName,String password, String userEmail, String contactNo,int userAge, String userUpi,Long id); 
	
	
}
