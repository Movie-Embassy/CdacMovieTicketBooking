package com.sunbeaminfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.BookingDTO;
import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.service.BookingService;



@RestController
@RequestMapping("/booking")
@CrossOrigin(origins = "*")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	public BookingController() {
		System.out.println("in ctor of "+getClass());
	}
	
	@GetMapping("/all")
	public List<Booking> getAllBookings()
	{
	return bookingService.getAllBookings();
	}
	
	@GetMapping("/id")
	public Booking getAllBookingById(@RequestParam Long id)
	{
	return bookingService.getBookingById(id);
	}
	
	@PutMapping("/delete")
	public ResponseEntity<?> deleteBookingById(@RequestParam Long id)
	{
	 bookingService.deleteById(id);
	 return new ResponseEntity(HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addBooking(@RequestBody BookingDTO bk)
	{
		bookingService.addBooking(bk);
		return new ResponseEntity(HttpStatus.OK);
	}
	
//	public List<E>
	
	
}
