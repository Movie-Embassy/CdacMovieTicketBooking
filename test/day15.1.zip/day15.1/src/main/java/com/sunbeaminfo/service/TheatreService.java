package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.entities.User;



public interface TheatreService {
	
	
	Theatre addTheatre(Theatre m);
	
	Theatre getTheatre(Long id);

	ApiResponse deleteTheatre(Long id);

	Theatre getTheatreDetails(Long theaterId);

	Theatre addtheatreDetails(Theatre m);

	Screen addScreen(ScreenDto m);

	List<Theatre> getAllTheatres();



}
