package com.sunbeaminfo.emuns;

public enum Genre {
COMEDY,ACTION,SUSPENSE,THRILLER,HORROR,ADULT,ADULT_COMEDY,DRAMA
}
