package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.ScreenDto;
import com.sunbeaminfo.dto.TheatreDTO;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.entities.User;



public interface TheatreService {
	
	
	Theatre addTheatre(TheatreDTO m);
	
	Theatre getTheatre(Long id);

	ApiResponse deleteTheatre(Long id);

	Theatre getTheatreDetails(Long theaterId);

	Theatre addtheatreDetails(Theatre m);

	List<Theatre> getAllTheatres();



}
