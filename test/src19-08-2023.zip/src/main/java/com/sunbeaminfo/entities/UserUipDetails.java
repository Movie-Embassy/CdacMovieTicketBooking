package com.sunbeaminfo.entities;

import java.io.Serializable;

import javax.persistence.*;

import lombok.*;

@Entity
@Table(name = "user_upi_tbl") // to specify table name
@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class UserUipDetails implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "user_id",nullable = false)
	private User user;
	
	
	@Column(name = "user_upi_id",unique = true,nullable = false)
	private String userUpiId;
	

}
