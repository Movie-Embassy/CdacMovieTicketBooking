package com.sunbeaminfo.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sunbeaminfo.emuns.Category;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Embeddable
@Entity
@Table(name="seat_tbl")
public class Seat {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="seat_id")
	private Long seatId;
	
	@Column(name="seat_number"  )
	private int seatNumber;
	
	public Seat(Long seatId) {
		super();
		this.seatId = seatId;
	}





	@ManyToOne
	@JoinColumn(name="screen_id" )
	//@JsonIgnore
	private Screen screen;

	@Enumerated(EnumType.STRING)
	@Column(name="category"  )
	private Category category;
	
	
	
	
	
	
	public Seat() {
		
	}
	

	public Seat(Long seatId, int seatNumber, Screen screen, Category category) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.screen = screen;
		this.category = category;
	}


	public Seat(int seatNumber, Screen screen, Category category) {
		super();
		this.seatNumber = seatNumber;
		this.screen = screen;
		this.category = category;
	}
		
	public Seat(int seatNumber, Category category) {
		this.seatNumber = seatNumber;
		this.category = category;
	}

	
	
	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	public Screen getScreen() {
		return screen;
	}
	
	
	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	
	
}
