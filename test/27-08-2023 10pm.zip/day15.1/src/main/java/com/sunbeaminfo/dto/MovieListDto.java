package com.sunbeaminfo.dto;

import java.time.LocalDate;


public class MovieListDto {
	
	private Long movieId;
		
	private String movieName;
	
	private LocalDate releaseDate;
	
	private byte[] movieTile;
	
	private byte[] movieBgImage;
	
	private int movieRating;
	
	public MovieListDto() {
		super();
	}

	public MovieListDto(Long movieId, String movieName, LocalDate releaseDate, byte[] movieTile, byte[] movieBgImage,
			int movieRating) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.movieTile = movieTile;
		this.movieBgImage = movieBgImage;
		this.movieRating = movieRating;
	}

	public MovieListDto(String movieName, LocalDate releaseDate, byte[] movieTile, byte[] movieBgImage,
			int movieRating) {
		super();
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.movieTile = movieTile;
		this.movieBgImage = movieBgImage;
		this.movieRating = movieRating;
	}

	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	public byte[] getMovieTile() {
		return movieTile;
	}

	public void setMovieTile(byte[] movieTile) {
		this.movieTile = movieTile;
	}

	public byte[] getMovieBgImage() {
		return movieBgImage;
	}

	public void setMovieBgImage(byte[] movieBgImage) {
		this.movieBgImage = movieBgImage;
	}

	public int getMovieRating() {
		return movieRating;
	}

	public void setMovieRating(int movieRating) {
		this.movieRating = movieRating;
	}
	
	
}
