package com.sunbeaminfo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.Password;
import com.sunbeaminfo.dto.SigninResponse;
import com.sunbeaminfo.dto.UserDTO;
import com.sunbeaminfo.entities.User;
import com.sunbeaminfo.jwt_utils.JwtUtils;
import com.sunbeaminfo.service.UserService;



@RestController // mandatory class level anno , consists of =@Controller : cls level
// +@ResponseBody : ret type of req handling
// methods(@RequestMapping/@GetMapping...)
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;
	@Autowired
	private UserDao loginDao;


	@Autowired
	private AuthenticationManager mgr;
	@Autowired
	private JwtUtils utils;	
	
	
	public UserController() {
		System.out.println("in ctor of " + getClass());
	}
	
	@GetMapping("/users")
	public List<UserDTO> listAllUsers(){
		List<UserDTO> userDto = new ArrayList<>();
		
		for(User u:userService.getAllUsers()) {
			UserDTO user = new UserDTO(u.getId(), u.getFirstName(), u.getLastName(), u.getUserEmail(), u.getContactNo(), u.getUserAge(), u.getuserUpi());
			userDto.add(user);
		}
		
		return userDto;
		
	}
	
	@PostMapping("/register")
	public User saveUserDetails(@RequestBody User u) {
		return userService.addUser(u);
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> logIn(@RequestBody Password password)
	{
		System.out.println(password.getEmail()+" "+password.getPassword());
		Authentication principal = mgr
				.authenticate(new UsernamePasswordAuthenticationToken(password.getEmail(), password.getPassword()));

		String jwtToken = utils.generateJwtToken(principal);
		System.out.println("================="+jwtToken);
		return ResponseEntity.ok(new SigninResponse(jwtToken, "User authentication success!!!", loginDao.validLogin(password.getEmail())));
	}
	
	@PutMapping("/update")
	public  ResponseEntity<?> updateUserInfo(@RequestBody User u) {
		System.out.println(u);
		
		userService.getuserDetails(u.getId());
		userService.updateUser(u);
		
		return new ResponseEntity(HttpStatus.OK);	
	}
	@PutMapping("/delete")
	public  ResponseEntity<?> deleteUser(@RequestBody User u) {
		Long id = u.getId();
		System.out.println(id);
		userService.deleteUser(id);
		return new ResponseEntity(HttpStatus.OK);	
	}
}
