package com.sunbeaminfo.service;



import java.util.Locale.Category;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.PriceDao;
import com.sunbeaminfo.dto.PriceByShowCategoryDTO;
import com.sunbeaminfo.dto.PriceDTO;
import com.sunbeaminfo.entities.Price;
import com.sunbeaminfo.entities.Show;

@Service
@Transactional
public class PriceServiceImpl implements PriceService {

	@Autowired
	private PriceDao priceDao;
	
	@Override
	public Price getPriceById(Long priceId) {
		return priceDao.findById(priceId).orElseThrow(()-> new ResourceNotFoundException("Invalid priceId"));
	
	}

	@Override
	public Price getPriceByShowId(PriceByShowCategoryDTO obj) {
		return priceDao.getByShowId(obj.getShowId(),obj.getCategory());
		
	}

	@Override
	public Price addPrice(PriceDTO price) {
		
		return priceDao.save(new Price( new Show(price.getShowId() ) , com.sunbeaminfo.emuns.Category.valueOf(price.getCategory()),price.getPrice()) );
	}

}
