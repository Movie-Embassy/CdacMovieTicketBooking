package com.sunbeaminfo.enums;

public enum Language {
ENGLISH,HINDI,MARATHI,TELUGU,TAMIL,KANNADA
}
