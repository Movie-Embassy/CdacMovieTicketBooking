package com.sunbeaminfo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.type.TrueFalseType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="movie_review_tbl")
public class MovieReview {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_review_id", nullable = false, unique = true)
	private long  movieReviewId;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name="movie_id", nullable = false)
	private Movie movie;
	
	
	@Column(name="review", nullable = false , unique = true)
	private String review;
	
	@Column(name="review_rating", nullable = false , unique = true)
	@Max(value = 5)
	@Min(value=0)
	private int reviewRating;
	
	

	
	@ManyToOne
	@JoinColumn(name="user_id", nullable = false)
	private User user;

	public MovieReview() {
		super();
	}

	public MovieReview(Movie movie, String review, @Max(5) @Min(0) int reviewRating, User user) {
		super();
		this.movie = movie;
		this.review = review;
		this.reviewRating = reviewRating;
		this.user = user;
	}

	public long getMovieReviewId() {
		return movieReviewId;
	}

	public void setMovieReviewId(long movieReviewId) {
		this.movieReviewId = movieReviewId;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public int getReviewRating() {
		return reviewRating;
	}

	public void setReviewRating(int reviewRating) {
		this.reviewRating = reviewRating;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (movieReviewId ^ (movieReviewId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MovieReview other = (MovieReview) obj;
		if (movieReviewId != other.movieReviewId)
			return false;
		return true;
	}

	
	
	
	
}
