package com.sunbeaminfo.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "theater_tbl") // to specify table name
public class Theatre {
	
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "theater_id")
	private Long theaterId;

	@Column(name = "theater_name", nullable=false, unique=true, length=50 )
	private String theaterName;
	
	@Column(name= "theater_bank_ac_no",nullable=false, unique=true,length=15)
	private String theaterBankAcNo;
	
	@Column(name = "bank_ifsc",nullable=false, unique=true,length=15)
	private String bankIFSC;
	
	@Column(name = "bank_ac_owner_name",nullable=false, unique=true,length=50)
	private String bankAcOwnerName;
	
	@Column(name = "theater_contact_no",nullable=false, unique=true,length=15)
	private String theaterContactNo;
	
	@Column(name = "theater_email",nullable=false, unique=true,length = 20)
	private String theaterEmail;
	
	@Column(name = "theater_city",nullable=false, unique=false,length=20)
	private String theaterCity;
	
	@Column(name = "theater_area",nullable=false, unique=false,length=20)
	private String theaterArea;
	

	
//	@OneToMany(mappedBy = "screenId")
//	@JsonIgnore	private Set<Screen> screen = new HashSet<Screen>();
//	public Set<Screen> getScreen() {
//		return screen;
//	}
//	public void setScreen(Set<Screen> shows) {
//		this.screen = shows;
//	}

	@OneToMany(mappedBy = "showId")
	private Set<Show> shows = new HashSet<Show>();
	
	public Set<Show> getShows() {
		return shows;
	}

	public void setShows(Set<Show> shows) {
		this.shows = shows;
	}

	
	
	public Theatre() {
		super();
	}

	public Theatre(String theaterName, String theaterBankAcNo, String bankIFSC, String bankAcOwnerName,
			String theaterContactNo, String theaterEmail, String theaterCity, String theaterArea) {
		super();
		this.theaterName = theaterName;
		this.theaterBankAcNo = theaterBankAcNo;
		this.bankIFSC = bankIFSC;
		this.bankAcOwnerName = bankAcOwnerName;
		this.theaterContactNo = theaterContactNo;
		this.theaterEmail = theaterEmail;
		this.theaterCity = theaterCity;
		this.theaterArea = theaterArea;
	}

	
	//constructor for creating object which is need for dependent class
	public Theatre(Long theaterId) {
		super();
		this.theaterId = theaterId;
	}

	public Long getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(Long theaterId) {
		this.theaterId = theaterId;
	}

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getTheaterBankAcNo() {
		return theaterBankAcNo;
	}

	public void setTheaterBankAcNo(String theaterBankAcNo) {
		this.theaterBankAcNo = theaterBankAcNo;
	}

	public String getBankIFSC() {
		return bankIFSC;
	}

	public void setBankIFSC(String bankIFSC) {
		this.bankIFSC = bankIFSC;
	}

	public String getBankAcOwnerName() {
		return bankAcOwnerName;
	}

	public void setBankAcOwnerName(String bankAcOwnerName) {
		this.bankAcOwnerName = bankAcOwnerName;
	}

	public String getTheaterContactNo() {
		return theaterContactNo;
	}

	public void setTheaterContactNo(String theaterContactNo) {
		this.theaterContactNo = theaterContactNo;
	}

	public String getTheaterEmail() {
		return theaterEmail;
	}

	public void setTheaterEmail(String theaterEmail) {
		this.theaterEmail = theaterEmail;
	}

	public String getTheaterCity() {
		return theaterCity;
	}

	public void setTheaterCity(String theaterCity) {
		this.theaterCity = theaterCity;
	}

	public String getTheaterArea() {
		return theaterArea;
	}

	public void setTheaterArea(String theaterArea) {
		this.theaterArea = theaterArea;
	}
//	 public String getScreenNameForNumber(int screenNumber) {
//	        // Iterate through the set of shows to find the screen with the matching screen number
//	        for (Show show : ) {
//	            if (show.getScreen().getScreenNumber() == screenNumber) {
//	                return show.getScreen().getTheatre().getTheaterName(); // Return the theatre's name containing the screen name
//	            }
//	        }
//	        return null; 
//	 }
}
//"movieDetails": {
//    "surrogateKey": 0,
