package com.sunbeaminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.dao.AdminDao;
import com.sunbeaminfo.dao.TokenDao;
import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.AdminSigninResponse;
import com.sunbeaminfo.dto.Password;
import com.sunbeaminfo.dto.SigninResponse;
import com.sunbeaminfo.entities.Admin;
import com.sunbeaminfo.entities.PasswordResetToken;
import com.sunbeaminfo.entities.User;
import com.sunbeaminfo.jwt_utils.JwtUtils;
import com.sunbeaminfo.service.UserService;



@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {
	
	@Autowired
	private AdminDao adminDao;
	


	
	@Autowired
	private AuthenticationManager mgr;
	@Autowired
	private JwtUtils utils;	
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	@PostMapping("/login")
	public ResponseEntity<?> logIn(@RequestBody Password password)
	{
		System.out.println(password.getEmail()+" "+password.getPassword());
		Authentication principal = mgr
				.authenticate(new UsernamePasswordAuthenticationToken(password.getEmail(), password.getPassword()));

		String jwtToken = utils.generateJwtToken(principal);
		System.out.println("================="+jwtToken);
		return ResponseEntity.ok(new AdminSigninResponse(jwtToken, "User authentication success!!!", adminDao.validLogin(password.getEmail())));
	}
	
	
	@PostMapping("/register")
	public Admin saveUserDetails(@RequestBody Admin u) {
		
		System.out.println(u.getPassword());
		u.setPassword(passwordEncoder.encode(u.getPassword()));
		
		return adminDao.save(u);
	}
	
	
	
	
	
	
}
