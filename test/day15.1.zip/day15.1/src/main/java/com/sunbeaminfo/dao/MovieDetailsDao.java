package com.sunbeaminfo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.entities.Screen;





public interface MovieDetailsDao extends JpaRepository<MovieDetails, Long> {
	
//	@Query("select new com.sunbeaminfo.entities.MovieDetails(movie, format , language) from MovieDetails m where m.movie = ?1")
//	@Query("select m from MovieDetails m where m.movie = (select m from Movie m where m.movieId=?1)")
	@Query("select m from MovieDetails m left outer join fetch m.movie where m.movie.movieId =?1 ")
	List<MovieDetails> movieSpecificDetails(Long movieId);
	
//	@Query("insert into MovieDetails m (m.format, m.language, m.movie.movieId) values (?1,?2,?3)")
//	MovieDetails addMovieDetails(String format, String language, Long id);
	
//	@Query("insert into MovieDetails m (m.format, m.language, m.movie.movieId) values (?1, ?2, ?3)")
//	MovieDetails addMovieDetails( String format,  String language,  Long id);

//	@Query("insert into MovieDetails m (m.format, m.language, m.movie.movieId) values (?1,?2,?3)")
//	MovieDetails addMovieDetails(String format, String language, Long id);
	
}
