// // ... (imports and other code)
// import { useEffect, useState } from "react";
// import ShowContainer from "../../components/showContainer/showContainer"
// import "./Background.scss"
// import axios from "axios";
// import { useParams } from "react-router-dom";
// function ShowListPage() {
//     const [shows, setShows] = useState([]);
//     const { id } = useParams();
  
//     useEffect(() => {
//       const url = `http://localhost:7070/show/moive/${id}`;
//       axios
//         .get(url)
//         .then((response) => {
//           setShows(response.data);
//         })
//         .catch((error) => {
//           console.error('Error fetching movie details:', error);
//         });
//     }, [id]);
  
//     // Create a function to group shows by theater name
//     const groupShowsByTheater = () => {
//       const groupedShows = {};
  
//       shows.forEach((show) => {
//         if (!groupedShows[show.theatreName]) {
//           groupedShows[show.theatreName] = [];
//         }
//         groupedShows[show.theatreName].push(show.showDateTime);
//       });
  
//       return groupedShows;
//     };
  
//     return (
//       <center>
//         <div className="moviePageList" style={{ width: "90%" }}>
//           {Object.entries(groupShowsByTheater()).map(([theatreName, showTimings]) => (
//             <div
//               key={theatreName}
//               style={{
//                 display: 'flex',
//                 flexWrap: 'wrap',
//                 width: 900,
//                 height: 175,
//                 borderWidth: 1,
//                 borderColor: "blue",
//                 borderStyle: "solid",
//                 borderRadius: 10,
//                 marginTop: 30,
//                 backgroundColor: "white"
//               }}
//             >
//               <div
//                 style={{
//                   width: 200,
//                   height: 140,
//                   borderWidth: 1,
//                   borderRadius: 10,
//                   marginLeft: 30,
//                   marginTop: 20,
//                   backgroundColor: "white"
//                 }}
//               >
//                 <div style={{ fontSize: 40 }}>
//                   <center style={{ marginTop: 20 }}>{theatreName}</center>
//                 </div>
//               </div>
//               <div
//                 style={{
//                   display: 'flex',
//                   flexWrap: 'wrap',
//                   width: 570,
//                   height: 140,
//                   borderRadius: 10,
//                   marginLeft: 40,
//                   marginTop: 15,
//                   backgroundColor: "white"
//                 }}
//               >
//                 {showTimings.map((dateTime) => (
//                   <ShowContainer key={dateTime} show={dateTime} />
//                 ))}
//               </div>
//             </div>
//           ))}
//         </div>
//       </center>
//     );
//   }
  
//   export default ShowListPage;
  

import React, { useEffect, useState } from "react";
import ShowContainer from "../../components/showContainer/showContainer";
import axios from "axios";
import { useParams } from "react-router-dom";

const containerStyle = {
  display: "flex",
  justifyContent: "center",
  marginTop: "30px",
};

function ShowListPage() {
  const [shows, setShows] = useState([]);
  const { id } = useParams();

  useEffect(() => {
    const url = `http://localhost:7070/show/moive/${id}`;
    axios
      .get(url)
      .then((response) => {
        setShows(response.data);
      })
      .catch((error) => {
        console.error("Error fetching movie details:", error);
      });
  }, [id]);

  const groupShowsByTheater = () => {
    const groupedShows = {};

    shows.forEach((show) => {
      if (!groupedShows[show.theatreName]) {
        groupedShows[show.theatreName] = [];
      }
      groupedShows[show.theatreName].push(show.showDateTime);
    });

    return groupedShows;
  };

  return (
    <div style={containerStyle}>
      <div style={{ width: "900px" }}>
        {Object.entries(groupShowsByTheater()).map(
          ([theatreName, showTimings]) => (
            <div
              key={theatreName}
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "20px",
              }}
            >
              <div
                style={{
                  width: "180px",
                  backgroundColor: "#007bff",
                  color: "white",
                  textAlign: "center",
                  padding: "10px",
                  borderRadius: "8px",
                  marginRight: "20px",
                }}
              >
                {theatreName}
              </div>
              <div style={{ display: "flex", flexWrap: "wrap" }}>
                {shows.map((show) => (
                  <a href=""><ShowContainer key={show} show={show} /></a>
                ))}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}

export default ShowListPage;