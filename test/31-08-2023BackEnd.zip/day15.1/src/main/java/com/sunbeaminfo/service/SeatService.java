package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.SeatDTO;
import com.sunbeaminfo.entities.BookingSeat;
import com.sunbeaminfo.entities.Seat;
import com.sunbeaminfo.entities.Show;



public interface SeatService {
	
	List<Seat> getAllSeats();
	
//	List<Seat> getScreenSeats(Long ScreenId);

	ApiResponse deleteSeat(Long id);

	Seat getSeatDetails(Long SeatId);

//	Seat addSeatDetails(SeatDTO m);
	
	List<BookingSeat> showSeatsList(Long showId);
	

 }
