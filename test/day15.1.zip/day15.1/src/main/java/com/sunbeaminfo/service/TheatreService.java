package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.Theatre;
import com.sunbeaminfo.entities.User;



public interface TheatreService {
	
	List<com.sunbeaminfo.entities.Theatre> getAllTheatres();
	
	Theatre addTheatre(Theatre m);
	
	Theatre getTheatre(Long id);

	ApiResponse deleteTheatre(Long id);
}
