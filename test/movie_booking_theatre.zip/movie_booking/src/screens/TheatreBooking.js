import { useHistory } from "react-router-dom";
import "../../node_modules/bootstrap/dist/css/bootstrap.css";
import "./theatre.css";

function TheatreBooking() {
  console.log("theatre Booking");
  const history = useHistory();
  var bookMovie = window.sessionStorage.getItem("MovieToBEBook");
  var SelectShow = () => {
    history.push("/SeatBooking");
  };

  return (
    <>
   <div>
  <div className="custom-div dark-bg">
    <h3 className="name-header">Movie Name</h3>
    <br />
    <div className="info-header badge bg-secondary">UA</div>
    <div className="info-header badge bg-secondary">Comedy</div>
    <div className="info-header badge bg-secondary">Love</div>
  </div>
</div>
    
<div className="date-options-container">
  <div className="date-options">
  <div style={{ paddingRight: '20px' }}>
  Choose the Date:
</div>
{/* <div className="date-selected-box">
    <div className="date-option">July 1</div>
    <div className="date-option">July 2</div>
    <div className="date-option">July 3</div>
    <div className="date-option">July 4</div>
  </div> */}
<div class="container">
  <div class="row">
    <div class="col-sm-2 text-center">
      <a class="left carousel-control" href="#dateCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
    </div>

    <div class="col-sm-4">
      <div id="dateCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
          <div class="item active">
            <div class="row">
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 4</h4></a>
              </div>
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 5</h4></a>
              </div>
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 6</h4></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="row">
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 7</h4></a>
              </div>
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 8</h4></a>
              </div>
              <div class="col-xs-3">
                <a onClick={SelectShow}><h4>July 9</h4></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-1 text-center arrow-container">
      <a class="right carousel-control" href="#dateCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
</div>


  
  </div>
</div>








<div className="theatre-list-container">

    <div className="container">
    <div className="card mb-3">
  <div className="card-body">
    <div className="d-flex flex-column flex-lg-row">
      {/* <span className="avatar avatar-text rounded-3 me-4 mb-2">FD</span> */}
      <div className="row flex-fill">
        <div className="col-sm-5">
          <h4 className="theatre-name">Inox Cinema</h4>
          <span className="badge badge-primary">3D available</span>{" "}
          <span className="badge badge-success">Food and Beverages</span>
        </div>
        <div className="col-sm-5 py-2">
        <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:10">7:30</a>


        <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:5">7:30</a>
        <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:50">7:30</a>
        <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:40">7:30</a>
        <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:30">7:30</a>

        </div>
      </div>
    </div>
  </div>
</div>

             
       
      <div className="card mb-3">
        <div className="card-body">
          <div className="d-flex flex-column flex-lg-row">
            {/* <span className="avatar avatar-text rounded-3 me-4 mb-2">FD</span> */}
            <div className="row flex-fill">
              <div className="col-sm-5">
                <h4 className="theatre-name">Gold Big Cinemas</h4>
                <span className="badge badge-primary">3D available</span>{" "}
                <span className="badge badge-success">Food and Beverages</span>
              </div>
              <div className="col-sm-5 py-2">
              <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:10">7:30</a>


<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:5">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:50">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:40">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:30">7:30</a>
</div>
             
            </div>
          </div>
        </div>
      </div>
       
      <div className="card mb-3">
        <div className="card-body">
          <div className="d-flex flex-column flex-lg-row">
            {/* <span className="avatar avatar-text rounded-3 me-4 mb-2">FD</span> */}
            <div className="row flex-fill">
              <div className="col-sm-5">
                <h4 className="theatre-name">City Pride R Deccan Multiplex</h4>
                <span className="badge badge-primary">3D available</span>{" "}
                <span className="badge badge-success">Food and Beverages</span>
              </div>
              <div className="col-sm-5 py-2">
              <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:10">7:30</a>


<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:5">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:50">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:40">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:30">7:30</a>
</div>
             
            </div>
          </div>
        </div>
      </div>
       
      <div className="card mb-3">
        <div className="card-body">
          <div className="d-flex flex-column flex-lg-row">
            {/* <span className="avatar avatar-text rounded-3 me-4 mb-2">FD</span> */}
            <div className="row flex-fill">
              <div className="col-sm-5">
                <h4 className="theatre-name">Big Cinemas</h4>
                <span className="badge badge-primary">3D available</span>{" "}
                <span className="badge badge-success">Food and Beverages</span>
              </div>
              <div className="col-sm-5 py-2">
              <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:10">7:30</a>


<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:5">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:50">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:40">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:30">7:30</a>
</div>
             
            </div>
          </div>
        </div>
      </div>
       
      <div className="card mb-3">
        <div className="card-body">
          <div className="d-flex flex-column flex-lg-row">
            {/* <span className="avatar avatar-text rounded-3 me-4 mb-2">FD</span> */}
            <div className="row flex-fill">
              <div className="col-sm-5">
                <h4 className="theatre-name">Prabhat Cinema</h4>
                <span className="badge badge-primary">3D available</span>{" "}
                <span className="badge badge-success">Food and Beverages</span>
              </div>
              <div className="col-sm-5 py-2">
              <a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:10">7:30</a>


<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:5">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:50">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:40">7:30</a>
<a onClick={SelectShow} className="badge link-badge timing-badge-1" data-total-seats="Total-seats:200" data-seats-left="Seats-Left:30">7:30</a>
</div>
             
            </div>
          </div>
        </div>
      </div>


     


      

    </div>
    </div>
    </>
  );
}

export default TheatreBooking;
