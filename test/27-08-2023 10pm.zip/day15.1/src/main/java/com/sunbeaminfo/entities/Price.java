package com.sunbeaminfo.entities;


import java.util.Objects;

import javax.persistence.*;

import com.sunbeaminfo.emuns.Category;


@Entity
@Table(name = "price_tbl") 	// Define the table name in the database
public class Price {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)	// Generate unique price IDs
	@Column(name = "price_id")
	private Long priceId;
	
	@ManyToOne
	@JoinColumn(name = "show_id")	 // Establish Many-to-One relationship with Show entity
	private Show show;
	
	@Enumerated
	@Column(name = "category")	// Use EnumType.STRING for enum values in the database
	private Category category;
	
	@Column(name = "price")
	private double price;


	// Default constructor
	public Price() {
		super();
	}

	// Constructor with all fields
	public Price(Long priceId, Show show, Category category, double price) {
		super();
		this.priceId = priceId;
		this.show = show;
		this.category = category;
		this.price = price;
	}


	// Constructor without priceId
	public Price(Show show, Category category, double price) {
		super();
		this.show = show;
		this.category = category;
		this.price = price;
	}


	// Constructor with only priceId
	public Price(Long priceId) {
		super();
		this.priceId = priceId;
	}


	// Getters and Setters for all fields
	public Long getPriceId() {
		return priceId;
	}

	public void setPriceId(Long priceId) {
		this.priceId = priceId;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	// Override hashCode to use priceId for hashing
	@Override
	public int hashCode() {
		return Objects.hash(priceId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Price other = (Price) obj;
		return Objects.equals(priceId, other.priceId);
	}

	

	
}
