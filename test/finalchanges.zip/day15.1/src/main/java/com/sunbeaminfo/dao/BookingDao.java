package com.sunbeaminfo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.entities.Movie;





public interface BookingDao extends JpaRepository<Booking, Long> {

	@Query(value="select max(booking_id) from booking_tbl;",nativeQuery=true)
	Long getLatestBookingID ();
	
	@Query(value="select ticket_id from booking_tbl where booking_id=?1 ;",nativeQuery=true)
	int getTicketId(int bkid);
	
}

