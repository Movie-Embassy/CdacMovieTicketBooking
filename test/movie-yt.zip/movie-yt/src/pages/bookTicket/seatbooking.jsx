import React, { useState, useEffect } from 'react';
import "./styleseat.scss";
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addSeats } from '../../slices/seatSlice';

const SeatBooking = () => {
    const [totalSeats,setTotalSeats]=useState('');
  const Navigate = useNavigate();
  const dispatch = useDispatch();
  
  // Initialize state variables
  const [ticketPrice, setTicketPrice] = useState(10);
  const [selectedSeats, setSelectedSeats] = useState([]);

  // Handle movie select change
  const handleMovieChange = (e) => {
    setTicketPrice(+e.target.value);
  };

  // Handle seat click
  const handleSeatClick = (e) => {
    if (e.target.classList.contains('seat') && !e.target.classList.contains('occupied')) {
      e.target.classList.toggle('selected');
      updateCount();
    }
  };

  // Update count and total
  const updateCount = () => {
    const selectedSeats = document.querySelectorAll('.row .seat.selected');
    
      setTotalSeats(selectedSeats.length);

    setSelectedSeats(selectedSeats);
    dispatch(addSeats(totalSeats));

    // Calculate and update total price
    const totalPrice = totalSeats * ticketPrice;
    document.getElementById('count').innerText = totalSeats;
    document.getElementById('total').innerText = totalPrice;
  };

  useEffect(() => {
    // Set up event listeners when the component mounts
    const container = document.querySelector('.container');
    const movieSelect = document.getElementById('movie');

    movieSelect.addEventListener('change', handleMovieChange);
    container.addEventListener('click', handleSeatClick);

    // Clean up the event listeners when the component unmounts
    return () => {
      movieSelect.removeEventListener('change', handleMovieChange);
      container.removeEventListener('click', handleSeatClick);
    };
  }, [ticketPrice]);
  return (
    <div className="seatbody">
      <div className="movie-container">
        <label>Pick a movie:</label>
        <select id="movie">
          <option value="10">Avengers: Endgame ($10)</option>
          <option value="12">Joker ($12)</option>
          <option value="8">Toy Story 4 ($8)</option>
          <option value="9">The Lion King ($9)</option>
        </select>
      </div>


    <ul class="showcase">
      <li>
        <div class="seat"></div>
        <small>N/A</small>
      </li>

      <li>
        <div class="seat selected"></div>
        <small>Selected</small>
      </li>

      <li>
        <div class="seat occupied"></div>
        <small>Occupied</small>
      </li>
    </ul>

    <div class="container" >
      <div class="screen"></div>
        <div style={{paddingLeft:'465px'}}>
        <center>
        <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
      </div>
      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat occupied"></div>
        <div class="seat occupied"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
      </div>

      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat occupied"></div>
        <div class="seat occupied"></div>
      </div>

      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
      </div>

      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat occupied"></div>
        <div class="seat occupied"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
      </div>

      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat"></div>
        <div class="seat occupied"></div>
        <div class="seat occupied"></div>
        <div class="seat occupied"></div>
        <div class="seat"></div>
      </div>
        </center>
        </div>
    </div>

    <p class="text">
      You have selected <span id="count">{totalSeats}</span> seats for a price of $<span id="total">0</span>
    </p>
    <div>
        <button className='btn-success' onClick={(e)=>{
            Navigate(`/ordersummary/${totalSeats}`)
        }}>Click Here to Book tickets</button>
    </div>

    </div>


  );
}

export default SeatBooking;