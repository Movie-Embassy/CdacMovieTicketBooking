package com.sunbeaminfo.entities;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="book_tbl")
public class Booking {
	
	private Long bookingId;
	
	
	private Show show;
	
	
//	private 
	

}
