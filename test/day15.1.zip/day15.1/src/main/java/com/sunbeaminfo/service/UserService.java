package com.sunbeaminfo.service;

import java.util.List;
import java.util.Optional;

import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.User;



public interface UserService {
	
	List<com.sunbeaminfo.entities.User> getAllUsers();
	
	User addUser(User u);
	
	User getUser(Long id);
	
	Optional<User> findByEmailandPassword(String e,String p);
	
	ApiResponse deleteUser(Long id);
	
	

}
