package com.sunbeaminfo.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;

import com.sunbeaminfo.enums.Certificate;

@Entity
@Table(name="movie_tbl")
public class Movie {

	// Primary Key
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="movie_id")
	private Long movieId;
	
	// Movie Name
	@Column(name="movie_name")
	private String movieName;
	
	// Release Date
	@Column(name="release_date")
	private LocalDate releaseDate;
	
	
	// Run Time
	@Column(name="run_time" )
	private int runTime ;
	
	
	// Description
	@Column(name="description", length = 500, columnDefinition ="TEXT")// CHECK THIS
	private String description;
	
	// Movie Tile Image (Binary Data)
	@Lob
	@Column(name="movie_tile")
	private byte[] movieTile;
	
	// Movie Background Image (Binary Data)
	@Lob
	@Column(name="movie_Bg_Image")
	private byte[] movieBgImage;
	
	// Trailer URL
	@Column(name="trailer_url", length =500)
	private String trailerUrl;
	
	// Certificate Enum (e.g., U, UA, A, etc.)
	@Enumerated(EnumType.STRING)
	@Column(name="certificate")
	private Certificate certificate;

	// Film Industry
	@Column(name = "film_industry")
	private String filmIndustry;
	
	
	
	
	
	//Collection Of Movie Related Info
	
	// Set of MovieCast (Actors and Roles)
	@OneToMany(mappedBy = "movie")
	private Set<MovieCast> movieCast = new HashSet<MovieCast>();
	
	
    // Set of MovieDetails (Format and Language)
	@OneToMany(mappedBy = "movie")
	private Set<MovieDetails> movieDetails = new HashSet<MovieDetails>();


    // List of MovieGenre (Genres)
	@OneToMany(mappedBy = "movie")
	private List<MovieGenre> movieGenres = new  ArrayList<MovieGenre>();	

    // Set of MovieReview (User Reviews)
	@OneToMany(mappedBy = "movie")
	private Set<MovieReview> movieReviews = new HashSet<MovieReview>();	
	
	// Getters and Setters for Movie's Collections
	public Set<MovieCast> getMovieCast() {
		return movieCast;
	}
	
	public void setMovieCast(Set<MovieCast> movieCast) {
		this.movieCast = movieCast;
	}

	public Set<MovieDetails> getMovieDetails() {
		return movieDetails;
	}

	public void setMovieDetails(Set<MovieDetails> movieDetails) {
		this.movieDetails = movieDetails;
	}

	public List<MovieGenre> getMovieGenres() {
		return movieGenres;
	}

	public void setMovieGenres(List<MovieGenre> movieGenres) {
		this.movieGenres = movieGenres;
	}

	public Set<MovieReview> getMovieReviews() {
		return movieReviews;
	}

	public void setMovieReviews(Set<MovieReview> movieReviews) {
		this.movieReviews = movieReviews;
	}


	 // Constructors
	

    // Default Constructor
	public Movie() {
		super();
	}
	

    // Constructor with all fields
	public Movie(Long movieId, String movieName, LocalDate releaseDate, int runTime, String description, byte[] movieTile,
		byte[] movieBgImage, String trailerUrl, Certificate certificate, String filmIndustry) {
	super();
	this.movieId = movieId;
	this.movieName = movieName;
	this.releaseDate = releaseDate;
	this.runTime = runTime;
	this.description = description;
	this.movieTile = movieTile;
	this.movieBgImage = movieBgImage;
	this.trailerUrl = trailerUrl;
	this.certificate = certificate;
	this.filmIndustry = filmIndustry;
	}

    // Constructor without movieId
	public Movie(String movieName, LocalDate releaseDate, int runTime, String description, byte[] movieTile,
			byte[] movieBgImage, String trailerUrl, Certificate certificate, String filmIndustry) {
		super();
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.runTime = runTime;
		this.description = description;
		this.movieTile = movieTile;
		this.movieBgImage = movieBgImage;
		this.trailerUrl = trailerUrl;
		this.certificate = certificate;
		this.filmIndustry = filmIndustry;
	}
	
	

    // Constructor with only movieId ***USERD IN DTO TO CRATE OBJECT WITH ONLY ID
	public Movie(Long movieId) {
		super();
		this.movieId = movieId;
	}

	
	
	// Getters and Setters for all fields
	public Long getMovieId() {
		return movieId;
	}


	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}


	public String getMovieName() {
		return movieName;
	}


	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}


	public LocalDate getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}


	public int getRunTime() {
		return runTime;
	}


	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public byte[] getMovieTile() {
		return movieTile;
	}


	public void setMovieTile(byte[] movieTile) {
		this.movieTile = movieTile;
	}


	public byte[] getMovieBgImage() {
		return movieBgImage;
	}


	public void setMovieBgImage(byte[] movieBgImage) {
		this.movieBgImage = movieBgImage;
	}


	public String getTrailerUrl() {
		return trailerUrl;
	}


	public void setTrailerUrl(String trailerUrl) {
		this.trailerUrl = trailerUrl;
	}


	public Certificate getCertificate() {
		return certificate;
	}


	public void setCertificate(Certificate certificate) {
		this.certificate = certificate;
	}


	public String getFilmIndustry() {
		return filmIndustry;
	}


	public void setFilmIndustry(String filmIndustry) {
		this.filmIndustry = filmIndustry;
	}

	
	
	

    // hashCode and equals methods for comparison ***NEEDED FOR HASHSET
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((movieId == null) ? 0 : movieId.hashCode());
		return result;
	}

	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (movieId == null) {
			if (other.movieId != null)
				return false;
		} else if (!movieId.equals(other.movieId))
			return false;
		return true;
	}
	
	

	
	

		
}
