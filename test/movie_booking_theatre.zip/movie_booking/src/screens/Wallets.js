import { useHistory } from "react-router-dom/cjs/react-router-dom.min";

function Wallets() {
    const history = useHistory();
    
    const success=()=>{
        history.push('./Success')
    }


    return ( <>
        <div className="input-group">
   
   <div className="input-group-prepend" style={{flexWrap:"wrap",display:"flex"}}>


         <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:20}}>
            <input type="radio" name="same" value ="value1" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/mobikwik.jpg" alt="mobikwik" style={{position:"relative",left:20,width:120,height:60}}/>     
        </div>  

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:20}}>
            <input type="radio" name="same" value ="value2" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/payzapp.jpg" alt="payzapp" style={{position:"relative",left:20,width:120,height:60}}/>     
        </div> 

        <div className="input-group-text" style={{backgroundColor:"aliceblue",borderRadius:10,position:"relative",left:10,width:200,margin:20}}>
            <input type="radio" name="same" value ="value3" aria-label="Radio button for following text input" style={{position:"relative",left:10}}/>
            <img src="/images/Amazonpay.jpg" alt="amazonpay" style={{position:"relative",left:20,width:60,height:60}}/>     
        </div> 





   </div>
   
</div>
<center>
                        <input onClick={success} type="button" name="proceed" value ="Proceed" className="btn btn-info"/>    
                    </center>
    
    </> );
}

export default Wallets;