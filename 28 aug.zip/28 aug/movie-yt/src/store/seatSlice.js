import { createSlice } from "@reduxjs/toolkit";

 const seatSlice = createSlice({
    name : 'seat',
    initialState : {
        totalNoOfSeats : 0

    },
    reducers : {
        addSeats : (state, action) =>{
            state.totalNoOfSeats = action.payload;
        },
    },
});

export const { addSeats } = seatSlice.actions;

export default seatSlice.reducer;