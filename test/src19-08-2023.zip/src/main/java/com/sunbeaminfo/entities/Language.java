package com.sunbeaminfo.entities;

public enum Language {
ENGLISH,HINDI,MARATHI,TELUGU,TAMIL,KANNADA
}
