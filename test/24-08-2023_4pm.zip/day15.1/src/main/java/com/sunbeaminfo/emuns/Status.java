package com.sunbeaminfo.emuns;

public enum Status {

	BOOKED,AVAILABLE,BLOCKED
}
