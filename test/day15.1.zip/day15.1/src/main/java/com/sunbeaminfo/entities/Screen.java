package com.sunbeaminfo.entities;

import java.time.LocalDate;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="screen_tbl")

@NoArgsConstructor
@AllArgsConstructor
//@Getter
//@Setter
public class Screen {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="screen_id", nullable = false, unique = true)
	private Long screenId;
	
	@Column(name="screen_number" , nullable = false)
	private int screenNumber;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="theatre_id", nullable = false)
	@JsonProperty("theaterId")
	private Theatre theatre;
//	
	
	
//	@Transient
//	private int SIZE;
	
//	@OneToMany
//	@Embedded
//	@ElementCollection
//	@CollectionTable(name ="seats_tbl",
//	joinColumns=@JoinColumn(name="seat_id"))
//	private Seat[] totalSeats = new Seat[SIZE];
	
	public void setScreenId(Long screenId) {
		this.screenId = screenId;
	}

	public Screen() {
	super();
}

	public Screen(int screenNumber, Theatre theatre) {
		super();
		this.screenNumber = screenNumber;
		this.theatre = theatre;
	}

	public void setScreenNumber(int screenNumber) {
		this.screenNumber = screenNumber;
	}

	public Long getScreenId() {
		return screenId;
	}

	public int getScreenNumber() {
		return screenNumber;
	}

	public Theatre getTheatre() {
		return theatre;
	}
	
	@JsonProperty("theaterId")
	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	} 
	
}
