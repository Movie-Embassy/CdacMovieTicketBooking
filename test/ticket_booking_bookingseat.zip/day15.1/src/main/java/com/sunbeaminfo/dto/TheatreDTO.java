package com.sunbeaminfo.dto;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.sunbeaminfo.entities.Movie;
import com.sunbeaminfo.entities.MovieDetails;
import com.sunbeaminfo.entities.Screen;
import com.sunbeaminfo.entities.Theatre;

public class TheatreDTO {
	
	private Long theaterId;

	private String theaterName;
	
	private String theaterBankAcNo;
	
	private String bankIFSC;
	
	private String bankAcOwnerName;
	
	private String theaterContactNo;
	
	private String theaterEmail;
	
	private String theaterCity;
	
	private String theaterArea;

	public TheatreDTO() {
		super();
	}

	public TheatreDTO(Long theaterId, String theaterName, String theaterBankAcNo, String bankIFSC,
			String bankAcOwnerName, String theaterContactNo, String theaterEmail, String theaterCity,
			String theaterArea) {
		super();
		this.theaterId = theaterId;
		this.theaterName = theaterName;
		this.theaterBankAcNo = theaterBankAcNo;
		this.bankIFSC = bankIFSC;
		this.bankAcOwnerName = bankAcOwnerName;
		this.theaterContactNo = theaterContactNo;
		this.theaterEmail = theaterEmail;
		this.theaterCity = theaterCity;
		this.theaterArea = theaterArea;
	}

	public TheatreDTO(String theaterName, String theaterBankAcNo, String bankIFSC, String bankAcOwnerName,
			String theaterContactNo, String theaterEmail, String theaterCity, String theaterArea) {
		super();
		this.theaterName = theaterName;
		this.theaterBankAcNo = theaterBankAcNo;
		this.bankIFSC = bankIFSC;
		this.bankAcOwnerName = bankAcOwnerName;
		this.theaterContactNo = theaterContactNo;
		this.theaterEmail = theaterEmail;
		this.theaterCity = theaterCity;
		this.theaterArea = theaterArea;
	}

	public Long getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(Long theaterId) {
		this.theaterId = theaterId;
	}

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getTheaterBankAcNo() {
		return theaterBankAcNo;
	}

	public void setTheaterBankAcNo(String theaterBankAcNo) {
		this.theaterBankAcNo = theaterBankAcNo;
	}

	public String getBankIFSC() {
		return bankIFSC;
	}

	public void setBankIFSC(String bankIFSC) {
		this.bankIFSC = bankIFSC;
	}

	public String getBankAcOwnerName() {
		return bankAcOwnerName;
	}

	public void setBankAcOwnerName(String bankAcOwnerName) {
		this.bankAcOwnerName = bankAcOwnerName;
	}

	public String getTheaterContactNo() {
		return theaterContactNo;
	}

	public void setTheaterContactNo(String theaterContactNo) {
		this.theaterContactNo = theaterContactNo;
	}

	public String getTheaterEmail() {
		return theaterEmail;
	}

	public void setTheaterEmail(String theaterEmail) {
		this.theaterEmail = theaterEmail;
	}

	public String getTheaterCity() {
		return theaterCity;
	}

	public void setTheaterCity(String theaterCity) {
		this.theaterCity = theaterCity;
	}

	public String getTheaterArea() {
		return theaterArea;
	}

	public void setTheaterArea(String theaterArea) {
		this.theaterArea = theaterArea;
	}
	
	
	
	
	
	
	
	
	
}
