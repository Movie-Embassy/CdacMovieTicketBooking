package com.sunbeaminfo.service;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.dao.BookingDao;
import com.sunbeaminfo.dao.ShowDao;
import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.BookingDTO;
import com.sunbeaminfo.entities.Booking;
import com.sunbeaminfo.entities.Show;
import com.sunbeaminfo.entities.User;


@Transactional
@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingDao bookingDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private ShowDao showDao;
	
	
	@Override
	public Booking addNewBooing(BookingDTO bookingDto) {
		
		User user = userDao.findById(bookingDto.getUserId()).get();
		
		Show show = showDao.findById(bookingDto.getShowId()).get();
		
		Booking booking = new Booking(user, show, null, LocalDateTime.now());
		return bookingDao.save(booking);
	}


	@Override
	public List<Booking> getAllBooking() {
		
		return bookingDao.findAll();
	}

	
	
	

}


