package com.sunbeaminfo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.SeatDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.dto.SeatDTO;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class SeatServiceImpl implements SeatService {

	@Autowired
	private SeatDao SeatDao;
	
	
	
	@Override
	public List<Seat> getAllSeats() {
		return SeatDao.findAll();
	}

	@Override
	public List<Seat> getScreenSeats(Long ScreenId) {
		
		return SeatDao.allSeatsOfScreen(ScreenId);
	}
	
	
	
	@Override
	public ApiResponse deleteSeat(Long id) {
		SeatDao.deleteById(id);
		
		return new ApiResponse("Seat is deleted");
	}
	
	@Override
	public Seat addSeatDetails(SeatDTO s) {	
		
		Seat seat = new Seat(s.getSeatNumber(), new Screen(s.getScreenId()), s.getCategory());
		
		return SeatDao.save(seat);
	}
	
	
	@Override
	public Seat getSeatDetails(Long SeatId) {
	
		return SeatDao.findById(SeatId).orElseThrow(() -> new ResourceNotFoundException("Seat id invalid !!!!!"));
	}
	
	
}
