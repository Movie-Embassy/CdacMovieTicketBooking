package com.sunbeaminfo.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.sunbeaminfo.custom_exceptions.ResourceNotFoundException;
import com.sunbeaminfo.dao.TokenDao;
import com.sunbeaminfo.dao.UserDao;
import com.sunbeaminfo.dto.ApiResponse;
import com.sunbeaminfo.entities.*;
@Transactional
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired
	private TokenDao tokenDao;
	
	@Override
	public List<User> getAllUsers() {
		System.out.println("11111111");
		return userDao.findAll();
	}

	@Override
	public User addUser(User u) {
		System.out.println(u.getPassword());
		u.setPassword(passwordEncoder.encode(u.getPassword()));
		return userDao.save(u);
	}

	@Override
	public User getUser(Long id) {
		
		return null;
	}

	@Override
	public Optional<User> findByEmailandPassword(String e, String p) {
		
		return userDao.findByUserEmailAndPassword(e, p);
	}

	@Override
	public ApiResponse deleteUser(Long id) {
		userDao.deleteById(id);
		
		return new ApiResponse("User is deleted");
	}

	

	@Override
	public User getuserDetails(Long userId) {
		// TODO Auto-generated method stub
		return userDao.findById(userId).orElseThrow(() -> new ResourceNotFoundException("user id invalid !!!!!"));
	}

	@Override
	public String sendEmail(User user) {
		
		try {
			String resetLink= generateRestToken(user);
			SimpleMailMessage msg = new SimpleMailMessage();
			msg.setTo(user.getUserEmail());
			msg.setSubject("Link to reset password");
			msg.setText("Hello \n\n" + "Please click on this link to Reset your Password :" + resetLink + ". \n\n"
					+ "Regards \n" + "ABC");
			javaMailSender.send(msg);
			
			return "success";
		}catch (Exception e) {
			e.printStackTrace();
			return "error";
		}

	}

	private String generateRestToken(User user) {
		UUID uuid = UUID.randomUUID();
		LocalDateTime currentDateTime = LocalDateTime.now();
		LocalDateTime expiryDateTime = currentDateTime.plusMinutes(30);
		PasswordResetToken resetToken = new PasswordResetToken();
		resetToken.setUser(user);
		resetToken.setToken(uuid.toString());
		resetToken.setExpiryDateTime(expiryDateTime);
		PasswordResetToken token = tokenDao.save(resetToken);
		if (token != null) {
			String endpointUrl = "http://localhost:7070/resetPassword";
			return endpointUrl + "/" + resetToken.getToken();
		}
		return "";
	}

	@Override
	public User updateUser(User u) {
	
	User user = userDao.findById(u.getId()).get();
	u.setPassword(user.getPassword());
		return userDao.save(u);
	}
	
	@Override
	public boolean hasExipred(LocalDateTime expiryDateTime) {
		LocalDateTime currentDateTime = LocalDateTime.now();
		return expiryDateTime.isAfter(currentDateTime);
	}
	
	
	
	

}
