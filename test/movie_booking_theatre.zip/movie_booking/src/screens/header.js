import React from 'react';
import './header.css';

const Header = () => {
  return (
    <div>
      <header className="header-area overlay">
        <nav className="navbar navbar-default navbar-fixed-top">
          <div className="container">
            <div className="navbar-header">
              <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-nav">
                <span className="sr-only">Toggle navigation</span>
                <span className="icon-bar"></span>
                <span className="icon-bar"></span>
                <span className="icon-bar"></span>
              </button>
              <a href="#" className="navbar-brand">BookMovie.com</a>
            </div>
            
            <div id="main-nav" className="collapse navbar-collapse">
              <ul className="nav navbar-nav navbar-right">
                <li className="active"><a href="#" className="nav-item nav-link">Home</a></li>
                <li><a href="#" className="nav-item nav-link">About Us</a></li>
                {/* <li className="dropdown">
                  <a href="#" className="nav-item nav-link dropdown-toggle" data-toggle="dropdown">Services <span className="caret"></span></a>
                  <ul className="dropdown-menu">
                    <li><a href="#" className="dropdown-item">Dropdown Item 1</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 2</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 3</a></li>
                  </ul>
                </li> */}
                {/* <li className="dropdown">
                  <a href="#" className="nav-item nav-link dropdown-toggle" data-toggle="dropdown">Portfolio <span className="caret"></span></a>
                  <ul className="dropdown-menu">
                    <li><a href="#" className="dropdown-item">Dropdown Item 1</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 2</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 3</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 4</a></li>
                    <li><a href="#" className="dropdown-item">Dropdown Item 5</a></li>
                  </ul>
                </li> */}
                <li><a href="#" className="nav-item nav-link">Contact</a></li>
                <li>
                  <form className="navbar-form navbar-right">
                    <div className="form-group">
                      <input type="text" className="form-control" placeholder="Search" />
                    </div>
                    <button type="submit" className="btn btn-default">Search</button>
                  </form>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
    </div>
  );
}

export default Header;
