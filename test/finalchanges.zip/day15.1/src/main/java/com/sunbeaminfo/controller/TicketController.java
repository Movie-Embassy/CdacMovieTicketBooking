package com.sunbeaminfo.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeaminfo.entities.Ticket;
import com.sunbeaminfo.service.TicketService;

@RestController
@RequestMapping("/Ticket")
@CrossOrigin(origins = "*")
public class TicketController
{

	
	@Autowired
	private TicketService ticketService;
	
	public TicketController() {
		System.out.println("in ctor of " + getClass());
	}
	
	
	@GetMapping("/all")
	public List<Ticket> getAllTickets(){
		return ticketService.getAllTickets();
	}
	
	@GetMapping("/byticketid")
	public Ticket getTicketById(@RequestParam Long id){
		return ticketService.getTicketsById(id);
	}
	
	
	@GetMapping("/byuserid")
	public List<Ticket> getAllTicketByUser(@RequestParam Long id){
		return ticketService.getAllTicketsByUser(id);
	}
	
	
	

	
	
}


